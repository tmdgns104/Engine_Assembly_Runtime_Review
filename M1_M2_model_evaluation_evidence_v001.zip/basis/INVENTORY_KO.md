# 현재 운영본 평가 제출용 기존 자산 목록

조사일: 2026-10-19 KST. Jetson 읽기 관측 시각(UTC): `2026-10-19T05:20:11.909981+00:00`.

이번 조사에서는 파일·메타데이터·기존 결과만 읽었다. 새 학습, 추론·평가 재실행, 배포, 촬영, 서비스 변경, PLC 운전을 하지 않았다. 파일 보유 확인은 성능 검증이나 제출 승인과 다르다.

## 1. 기준 운영본과 판정 범위

- 장치: `jetson-07`, Tailscale `100.119.148.89`. 유선 `192.168.50.2`는 시간 초과였으나 Tailscale 읽기 접속에 성공했다.
- 장치의 `/home/jetson/oned_device_bench/current/release.json`에서 **`engine-integrated-32c484ac6aeb07f1`** 확인.
- 실제 설치된 TensorRT 두 파일 및 참고용 PT 다섯 파일의 SHA-256을 읽어 로컬 운영 패키지·출처와 대조했다. 두 검출 모델의 학습 원본 PT/ONNX/annotation 해시도 일치한다.
- 최종 미결합 판정: M1 부품 검출 + M2 엔진 전체/자세 검출. M3–M6는 오조립 **참고 전용**이다. M2 PT가 참고 경로에도 사용되므로 장치 모델 파일은 7개(2 TRT + 5 PT)지만 서로 다른 학습 모델은 6개다.
- 이 목록은 프로젝트의 이어폰 Baseline/COCO smoke/폐기된 envelope_v001을 현재 엔진 모델 증거로 섞지 않는다.

## 2. 보유 상태 요약

**보유 확인**: 지정 경로 실파일·수량/크기를 확인. **일부 확보**: 파일/기록은 있으나 제출에 필요한 범위·독립성·완전성에 제한. **보유 미확인**: 아래 검색 범위에서 해당 완성 자료를 확인하지 못함(전 세계/모든 디스크에 없다는 뜻 아님).
| 항목 | 상태 | 확인된 범위 / 제한 |
| --- | --- | --- |
| 현재 모델에 연결된 train/val 이미지·라벨 | 보유 확인 | M1·M2 각각 train144/val72. 동일 원본216장을 두 작업이 공유하며 라벨은 별도. 이미지 해시432개 대조, train/val 동일해시 중복0. |
| train/val 분리·원본 연결 목록 | 보유 확인 | M1 lineage.json + M2 dataset_pose_audit_v004.json + 각 data.yaml. 본 목록 CSV는 기존 목록을 정리한 것이며 재분리하지 않음. |
| 독립 final test 목록·원본 | 일부 확보 | source_audit에 E04 예약72장 기록. 현재 학습 디렉터리는 train/val만 있음. 보호된 원본/정답을 열거나 독립 시험 완료로 취급하지 않음. |
| 원본 PT / ONNX / TensorRT | 보유 확인 | 검출용 PT2·ONNX2·TRT2 및 참고 분류 PT4, 해시로 운영본 연결. |
| 학습 설정·학습 로그 | 보유 확인 | 6개 학습의 args.yaml, results.csv, best/last.pt 및 출처 코드. max epoch와 실제 epoch 구분. |
| 오조립 참고 모델의 학습 이미지·라벨 | 보유 확인 | 원본 후보 train694/val155 모두 존재; 실제 유효 crop train2597/val545(4모델 합계)·3142 SHA 일치. 사람 독립 검토 라벨은 아님. |
| 개발 검증·변환·기존 실물 평가 | 보유 확인 | E03 지표, TRT 빌드/부품 parity, 참고 STATIC300, 실물7건 기록 존재. 범위가 서로 다름. |
| 현재 최종 운영본의 독립 종합 성능 평가 | 일부 확보 | 실물7은 4c4 운영본; 32c4는 UI만 추가 수정 후 재부팅 확인. 최종 holdout/장시간 인증은 확인되지 않음. |
| Jetson 검사 DB·원본 이미지 | 보유 확인 | DB 392건 / raw1113장·overlay371장, 전부 존재·크기 일치. 전체 원본 SHA 재계산은 하지 않음. |
| Windows/GitHub 보존 DB와 전체 사진 묶음 | 일부 확보 | 10/18 snapshot368건. Windows 원본432장+표시135장만 기존 DB SHA와 직접 일치 확인; 전체 사진 미러 아님. |
| 연속 프레임 진단 녹화 | 보유 확인 | Jetson 15개 기록 폴더, PNG 769장. 이 중 2개 RUN 기록은 원본0장이라 유효 녹화에서 제외. |
| 엔진 진입→정지→검사→배출 전체 운전 영상 | 일부 확보 | RUN220장의 PNG·시간/단계 기록 존재. 기존 검토상 빈 벨트이므로 엔진 전체 운전 구간 확보 아님. |
| MP4/AVI/MKV 등 인코딩 동영상 | 보유 미확인 | 아래 Windows·Jetson 검색 경로에서 0개. PNG 시퀀스는 동영상 파일과 구분. |
| 독립 final test 평가 결과 | 보유 미확인 | 현재 연결된 run/dataset/평가 경로에서 확인되지 않음. E03 및 STATIC300을 최종 시험으로 표시하지 않음. |

## 3. 원본 모델과 변환 파일

모델 이름·용량뿐 아니라 학습 출력→변환 metadata→운영 패키지→실제 Jetson 파일의 SHA로 연결했다. 아래 SHA는 이번 조사에서 파일을 직접 읽어 계산했다.

### M1 — dynamic_parts_005 / CFA8507_original_PT_fp16_head32
| 파일 | 실제 Windows 경로 | 용량 | SHA-256 | 확인 방법 |
| --- | --- | --- | --- | --- |
| 학습 원본 PT | [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/models/engine_parts_best.pt](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/models/engine_parts_best.pt>) | 5,456,154 B (5.20 MiB) | 42db183006ad2a4f61dc9c22e7a61a5b506cdacb5099004fc7c3b73b74bf5259 | 출처 기대 SHA 일치 |
| ONNX | [D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/engine_parts.onnx](<D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/engine_parts.onnx>) | 10,566,638 B (10.08 MiB) | 433b16fd1e802bdf2cb0afba6bb6487a839d94b5adc286185b93fd3953b9c296 | 출처 기대 SHA 일치 |
| TensorRT | [D:/OneDevice_Team_project/jetson/products/ENGINE_Z3005_5/dynamic_parts_005/model.plan](<D:/OneDevice_Team_project/jetson/products/ENGINE_Z3005_5/dynamic_parts_005/model.plan>) | 10,092,164 B (9.62 MiB) | 743ce54b4d5c7b8a36addf3dbff50fa693ec4a509b31b476f68efc69f1bf2d6c | 출처 기대 SHA 일치 |

Jetson 실파일: `/home/jetson/oned_device_bench/assets/products/ENGINE_Z3005_5/dynamic_parts_005/model.plan` — 읽기 해시 대조 일치.

패키지 출처: [D:/OneDevice_Team_project/jetson/products/ENGINE_Z3005_5/dynamic_parts_005/manifest.json](<D:/OneDevice_Team_project/jetson/products/ENGINE_Z3005_5/dynamic_parts_005/manifest.json>).

### M2 — envelope_v007_fp16 / envelope_v004_E01_E02_144
| 파일 | 실제 Windows 경로 | 용량 | SHA-256 | 확인 방법 |
| --- | --- | --- | --- | --- |
| 학습 원본 PT | [D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/training/envelope_v004/weights/best.pt](<D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/training/envelope_v004/weights/best.pt>) | 5,449,562 B (5.20 MiB) | cf117defe782e1ae8b355e0ed13c014fc6f1538aa2dcdbe0fb6cfa54200f7755 | 출처 기대 SHA 일치 |
| ONNX | [D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/envelope_export_v004/envelope_best.onnx](<D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/envelope_export_v004/envelope_best.onnx>) | 10,564,980 B (10.08 MiB) | 5cb024bb911f9357e46c12c3d2a7e4b5f19af20e5692013037c9235e0deca830 | 출처 기대 SHA 일치 |
| TensorRT | [D:/OneDevice_Team_project/jetson/products/ENGINE_Z3005_5/envelope_v007_fp16/model.plan](<D:/OneDevice_Team_project/jetson/products/ENGINE_Z3005_5/envelope_v007_fp16/model.plan>) | 13,556,092 B (12.93 MiB) | c82f2658ac20d06985a647c15e551c681e394451cfa1c53baed64f639bcebf83 | 출처 기대 SHA 일치 |

Jetson 실파일: `/home/jetson/oned_device_bench/assets/products/ENGINE_Z3005_5/envelope_v007_fp16/model.plan` — 읽기 해시 대조 일치.

패키지 출처: [D:/OneDevice_Team_project/jetson/products/ENGINE_Z3005_5/envelope_v007_fp16/manifest.json](<D:/OneDevice_Team_project/jetson/products/ENGINE_Z3005_5/envelope_v007_fp16/manifest.json>).

### M3 — pipe_left / v001_20261002T191929Z / STATIC_300 frozen
| 파일 | 실제 Windows 경로 | 용량 | SHA-256 | 확인 방법 |
| --- | --- | --- | --- | --- |
| 학습 원본 PT | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_left/weights/best.pt](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_left/weights/best.pt>) | 3,191,628 B (3.04 MiB) | 35351ea2321036f29058e231fd37c3c9dbaf13aaada42e1e1391394d44b0296c | 출처 기대 SHA 일치 |
| 운영 참고 PT 복사본 | [D:/OneDevice_Team_project/assets/misassembly_runtime/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_left/weights/best.pt](<D:/OneDevice_Team_project/assets/misassembly_runtime/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_left/weights/best.pt>) | 3,191,628 B (3.04 MiB) | 35351ea2321036f29058e231fd37c3c9dbaf13aaada42e1e1391394d44b0296c | 출처 기대 SHA 일치 |

Jetson 실파일: `/home/jetson/oned_device_bench/assets/misassembly_runtime/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_left/weights/best.pt` — 읽기 해시 대조 일치.

ONNX/TRT: 현재 참고 경로는 PT를 사용한다. 해당 full/weights·frozen bundle에서 변환 파일은 확인하지 않았으며, 미결합 판정용 TRT 누락과는 다르다.

### M4 — pipe_right / v001_20261002T191929Z / STATIC_300 frozen
| 파일 | 실제 Windows 경로 | 용량 | SHA-256 | 확인 방법 |
| --- | --- | --- | --- | --- |
| 학습 원본 PT | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_right/weights/best.pt](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_right/weights/best.pt>) | 3,191,692 B (3.04 MiB) | d74ac8deb8c1a66889e3493acb87c1c7894b39ab000182df8ba57b5d4a66c8e7 | 출처 기대 SHA 일치 |
| 운영 참고 PT 복사본 | [D:/OneDevice_Team_project/assets/misassembly_runtime/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_right/weights/best.pt](<D:/OneDevice_Team_project/assets/misassembly_runtime/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_right/weights/best.pt>) | 3,191,692 B (3.04 MiB) | d74ac8deb8c1a66889e3493acb87c1c7894b39ab000182df8ba57b5d4a66c8e7 | 출처 기대 SHA 일치 |

Jetson 실파일: `/home/jetson/oned_device_bench/assets/misassembly_runtime/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_right/weights/best.pt` — 읽기 해시 대조 일치.

ONNX/TRT: 현재 참고 경로는 PT를 사용한다. 해당 full/weights·frozen bundle에서 변환 파일은 확인하지 않았으며, 미결합 판정용 TRT 누락과는 다르다.

### M5 — exhaust / v001_20261002T191929Z / STATIC_300 frozen
| 파일 | 실제 Windows 경로 | 용량 | SHA-256 | 확인 방법 |
| --- | --- | --- | --- | --- |
| 학습 원본 PT | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/exhaust/weights/best.pt](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/exhaust/weights/best.pt>) | 3,192,524 B (3.04 MiB) | 09678d298ef59fb83acd6c5d57fe8a1bcc841ae26151f4ec700906d352bc6a17 | 출처 기대 SHA 일치 |
| 운영 참고 PT 복사본 | [D:/OneDevice_Team_project/assets/misassembly_runtime/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/exhaust/weights/best.pt](<D:/OneDevice_Team_project/assets/misassembly_runtime/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/exhaust/weights/best.pt>) | 3,192,524 B (3.04 MiB) | 09678d298ef59fb83acd6c5d57fe8a1bcc841ae26151f4ec700906d352bc6a17 | 출처 기대 SHA 일치 |

Jetson 실파일: `/home/jetson/oned_device_bench/assets/misassembly_runtime/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/exhaust/weights/best.pt` — 읽기 해시 대조 일치.

ONNX/TRT: 현재 참고 경로는 PT를 사용한다. 해당 full/weights·frozen bundle에서 변환 파일은 확인하지 않았으며, 미결합 판정용 TRT 누락과는 다르다.

### M6 — symbol / v001_20261002T191929Z / STATIC_300 frozen
| 파일 | 실제 Windows 경로 | 용량 | SHA-256 | 확인 방법 |
| --- | --- | --- | --- | --- |
| 학습 원본 PT | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/symbol/weights/best.pt](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/symbol/weights/best.pt>) | 3,188,876 B (3.04 MiB) | c0c45dcdf48d233a9d486a00d06af3ba70aa12070fd9ab73cb3861e6c278391e | 출처 기대 SHA 일치 |
| 운영 참고 PT 복사본 | [D:/OneDevice_Team_project/assets/misassembly_runtime/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/symbol/weights/best.pt](<D:/OneDevice_Team_project/assets/misassembly_runtime/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/symbol/weights/best.pt>) | 3,188,876 B (3.04 MiB) | c0c45dcdf48d233a9d486a00d06af3ba70aa12070fd9ab73cb3861e6c278391e | 출처 기대 SHA 일치 |

Jetson 실파일: `/home/jetson/oned_device_bench/assets/misassembly_runtime/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/symbol/weights/best.pt` — 읽기 해시 대조 일치.

ONNX/TRT: 현재 참고 경로는 PT를 사용한다. 해당 full/weights·frozen bundle에서 변환 파일은 확인하지 않았으며, 미결합 판정용 TRT 누락과는 다르다.

## 4. 학습 이미지·라벨·분리 목록

### 검출 모델 M1 / M2

각 train/val 디렉터리의 PNG/TXT 수·용량·이름 대응과 라벨의 정규화 좌표 형식을 확인했다. 모든 PNG를 기존 source SHA와 대조했다. 이는 라벨 경계의 사람 재검토나 재평가를 뜻하지 않는다.

**M1** — data.yaml: [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/dataset/data.yaml](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/dataset/data.yaml>)
| 분리 | 이미지 실제 경로 | 수량·용량 | 라벨 실제 경로 | 수량·용량 |
| --- | --- | --- | --- | --- |
| train | [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/dataset/images/train](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/dataset/images/train>) | 144장 / 125,313,378 B (119.51 MiB) | [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/dataset/labels/train](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/dataset/labels/train>) | 144파일 / 384box / 21,120 B (0.02 MiB) |
| val | [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/dataset/images/val](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/dataset/images/val>) | 72장 / 64,296,372 B (61.32 MiB) | [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/dataset/labels/val](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/dataset/labels/val>) | 72파일 / 192box / 10,560 B (0.01 MiB) |

**M2** — data.yaml: [D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/dataset_v004/data.yaml](<D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/dataset_v004/data.yaml>)
| 분리 | 이미지 실제 경로 | 수량·용량 | 라벨 실제 경로 | 수량·용량 |
| --- | --- | --- | --- | --- |
| train | [D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/dataset_v004/images/train](<D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/dataset_v004/images/train>) | 144장 / 125,313,378 B (119.51 MiB) | [D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/dataset_v004/labels/train](<D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/dataset_v004/labels/train>) | 144파일 / 144box / 7,920 B (0.01 MiB) |
| val | [D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/dataset_v004/images/val](<D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/dataset_v004/images/val>) | 72장 / 64,296,372 B (61.32 MiB) | [D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/dataset_v004/labels/val](<D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/dataset_v004/labels/val>) | 72파일 / 72box / 3,960 B (0.00 MiB) |

분리·승인 출처:

- M1: [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/dataset/lineage.json](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/dataset/lineage.json>) — 216항목, review ID / train-val / ZIP 원본 경로 / SHA 연결.
- M1: [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/annotations_used.json](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/annotations_used.json>) — 508,273 B (0.48 MiB) / 216장·576box. JSON 내부 초안 표시는 남아 있으나 [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/approval_provenance.json](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/approval_provenance.json>)에 **동일 annotation SHA에 대한 216장 사용자 승인**이 별도 기록되어 있다.
- M2: [D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/dataset_pose_audit_v004.json](<D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/dataset_pose_audit_v004.json>) — 279,876 B (0.27 MiB) / 216항목. 패키지 annotation SHA 일치. AI 시각 검토 기록이며 사람 승인을 주장하지 않는다.
- 원본 ZIP: [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/CFA8507BBBF384292.zip](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/CFA8507BBBF384292.zip>) — 256,641,487 B (244.75 MiB); 파일 존재·크기만 재확인. E04를 포함할 수 있어 원본 아카이브를 재추출/내용 검사하지 않음.
- test: [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/source_audit.json](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/source_audit.json>)의 기존 메타데이터에서 E04 72장 예약 확인. train/val YAML에는 test 경로가 없다. **E04 이미지·정답 비열람, 별도 final-test 목록/실평가 완료 보유 미확인.**

파일별 목록: [D:/OneDevice_Team_project/docs/evaluation_assets/20261019/detection_train_val_files.csv](<D:/OneDevice_Team_project/docs/evaluation_assets/20261019/detection_train_val_files.csv>) — 432행(M1·M2 파일 복사본을 각각 표시), 실제 경로·원본 SHA·라벨 SHA·촬영 회차 포함. 서로 다른 원본은 216장이다.

### 참고 모델 M3–M6

원본: [D:/OneDevice_Team_project/data/guided_capture_20261001](<D:/OneDevice_Team_project/data/guided_capture_20261001>)의 TRAIN/VALIDATION. 고정 학습 입력 목록은 [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/export_train_candidates.jsonl](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/export_train_candidates.jsonl>)(694행), [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/export_validation_candidates.jsonl](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/export_validation_candidates.jsonl>)(155행). 각 원본 경로 실파일 존재 확인; 원본 전체 SHA 재계산은 하지 않았다. 클래스 라벨은 JSONL의 `approved_state`와 crop 클래스 폴더이며 YOLO bbox TXT 라벨과 다르다.

각 모델의 crop 목록 파일은 전처리 실패/보류도 보존한다. 694/155가 모든 모델의 실제 유효 학습 수인 것은 아니다.
| 참고 모델 | 분리 | 수량 | 유효 crop 용량 | 실제 라벨·분리 목록 | 클래스별 수량 |
| --- | --- | --- | --- | --- | --- |
| pipe_left | train | 655유효 / 39제외 | 44,887,694 B (42.81 MiB) | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/pipe_left_train_crop_manifest.jsonl](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/pipe_left_train_crop_manifest.jsonl>) | {'CORRECT': 457, 'MISSING': 67, 'UPWARD_ROTATED': 67, 'OUTWARD_SPLAYED': 64} |
| pipe_left | validation | 132유효 / 23제외 | 9,144,770 B (8.72 MiB) | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/pipe_left_validation_crop_manifest.jsonl](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/pipe_left_validation_crop_manifest.jsonl>) | {'CORRECT': 95, 'MISSING': 20, 'UPWARD_ROTATED': 9, 'OUTWARD_SPLAYED': 8} |
| pipe_right | train | 612유효 / 82제외 | 43,983,394 B (41.95 MiB) | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/pipe_right_train_crop_manifest.jsonl](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/pipe_right_train_crop_manifest.jsonl>) | {'CORRECT': 431, 'MISSING': 62, 'UPWARD_ROTATED': 59, 'OUTWARD_SPLAYED': 60} |
| pipe_right | validation | 123유효 / 32제외 | 8,985,678 B (8.57 MiB) | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/pipe_right_validation_crop_manifest.jsonl](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/pipe_right_validation_crop_manifest.jsonl>) | {'CORRECT': 86, 'MISSING': 19, 'UPWARD_ROTATED': 9, 'OUTWARD_SPLAYED': 9} |
| exhaust | train | 665유효 / 29제외 | 40,532,413 B (38.65 MiB) | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/exhaust_train_crop_manifest.jsonl](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/exhaust_train_crop_manifest.jsonl>) | {'CORRECT': 475, 'MISSING': 69, 'REVERSED': 65, 'SIDEWAYS': 56} |
| exhaust | validation | 145유효 / 10제외 | 8,420,085 B (8.03 MiB) | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/exhaust_validation_crop_manifest.jsonl](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/exhaust_validation_crop_manifest.jsonl>) | {'CORRECT': 102, 'MISSING': 21, 'REVERSED': 11, 'SIDEWAYS': 11} |
| symbol | train | 665유효 / 29제외 | 41,109,639 B (39.21 MiB) | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/symbol_train_crop_manifest.jsonl](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/symbol_train_crop_manifest.jsonl>) | {'CORRECT': 527, 'MISSING': 70, 'UPSIDE_DOWN': 68} |
| symbol | validation | 145유효 / 10제외 | 8,284,243 B (7.90 MiB) | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/symbol_validation_crop_manifest.jsonl](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/symbol_validation_crop_manifest.jsonl>) | {'CORRECT': 112, 'MISSING': 22, 'UPSIDE_DOWN': 11} |

- crop 실제 경로: [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/crops](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/crops>) 아래 `part/train|val/클래스/촬영ID.png` (정확한 각 파일 경로는 CSV). 유효 3,142개 모두 manifest SHA와 일치.
- 라벨에는 `human_reviewed=false`, Codex 시각 검토 출처가 명시돼 있다. 독립 사람 정답 또는 final test로 과장하지 않는다.
- 기존 전처리 보정 run [D:/OneDevice_Team_project/runs/engine_preprocessing_recovery_001/v001_20261003T033452Z](<D:/OneDevice_Team_project/runs/engine_preprocessing_recovery_001/v001_20261003T033452Z>)은 별도 평가·전처리 자산이다. 이를 원 모델을 다시 학습한 기록으로 혼동하지 않는다.
- 전체 목록: [D:/OneDevice_Team_project/docs/evaluation_assets/20261019/reference_classifier_source_images.csv](<D:/OneDevice_Team_project/docs/evaluation_assets/20261019/reference_classifier_source_images.csv>) / [D:/OneDevice_Team_project/docs/evaluation_assets/20261019/reference_classifier_train_val_files.csv](<D:/OneDevice_Team_project/docs/evaluation_assets/20261019/reference_classifier_train_val_files.csv>).

## 5. 학습 설정·학습 기록

`args.yaml`의 최대 epoch와 `results.csv` 행 수로 확인한 실제 학습 epoch를 구분했다. 학습을 재실행하거나 PT를 역직렬화하지 않았다.
| 모델 | 최대/실제 epoch | imgsz / batch / seed | optimizer | 실제 설정 경로 | 실제 학습 로그 |
| --- | --- | --- | --- | --- | --- |
| M1 | 100 / 100 | 640 / 8 / 42 | auto | [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/training/engine_parts/args.yaml](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/training/engine_parts/args.yaml>) | [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/training/engine_parts/results.csv](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/training/engine_parts/results.csv>) |
| M2 | 100 / 57 | 640 / 8 / 42 | auto | [D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/training/envelope_v004/args.yaml](<D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/training/envelope_v004/args.yaml>) | [D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/training/envelope_v004/results.csv](<D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/training/envelope_v004/results.csv>) |
| M3 | 60 / 11 | 224 / 16 / 42 | AdamW | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_left/args.yaml](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_left/args.yaml>) | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_left/results.csv](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_left/results.csv>) |
| M4 | 60 / 12 | 224 / 16 / 42 | AdamW | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_right/args.yaml](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_right/args.yaml>) | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_right/results.csv](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/pipe_right/results.csv>) |
| M5 | 60 / 23 | 224 / 16 / 42 | AdamW | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/exhaust/args.yaml](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/exhaust/args.yaml>) | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/exhaust/results.csv](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/exhaust/results.csv>) |
| M6 | 60 / 11 | 224 / 16 / 42 | AdamW | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/symbol/args.yaml](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/symbol/args.yaml>) | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/symbol/results.csv](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/full/symbol/results.csv>) |

전체 augmentation/lr/amp 등 읽은 설정 값과 각 파일 크기·SHA는 [D:/OneDevice_Team_project/docs/evaluation_assets/20261019/asset_inventory.json](<D:/OneDevice_Team_project/docs/evaluation_assets/20261019/asset_inventory.json>)의 `training`에 보존했다. 모든 run의 `weights/last.pt`도 존재 여부·용량·SHA를 기록했다. M1 배포용 복사본은 [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/models/engine_parts_last.pt](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/models/engine_parts_last.pt>)에도 있다.

학습 재현 소스: [D:/OneDevice_Team_project/notebook/training/README_KO.md](<D:/OneDevice_Team_project/notebook/training/README_KO.md>) 및 [D:/OneDevice_Team_project/notebook/training/engine_detection](<D:/OneDevice_Team_project/notebook/training/engine_detection>) / [D:/OneDevice_Team_project/notebook/training/engine_baseline](<D:/OneDevice_Team_project/notebook/training/engine_baseline>). 원본 학습 출력 경로의 일부가 별도 worktree에 있어 저장소 clone만으로 모든 이미지가 생기지는 않는다.

## 6. 기존 평가 결과와 연결 범위
| 모델 | 실제 결과 경로 | 용량 | 기존 보고값 / 범위 |
| --- | --- | --- | --- |
| M1 | [D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/validation_metrics.json](<D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/validation_metrics.json>) | 277 B (0.00 MiB) | P=0.997696, R=1.000000, mAP50=0.995000, mAP50-95=0.664726 |
| M2 | [D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/training_result.json](<D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/training_result.json>) | 500 B (0.00 MiB) | P=0.960408, R=1.000000, mAP50=0.995000, mAP50-95=0.884270 |
| M3-M6 | [D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/training_metrics.json](<D:/OneDevice_Team_project/runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/training_metrics.json>) | 30,694 B (0.03 MiB) | 4개 부품별 지표·confusion·classifier-only simulation; independent final test 아님 |
| M3-M6 | [D:/OneDevice_Team_project/runs/engine_preprocessing_recovery_001/v001_20261003T033452Z/before_after_metrics.json](<D:/OneDevice_Team_project/runs/engine_preprocessing_recovery_001/v001_20261003T033452Z/before_after_metrics.json>) | 59,001 B (0.06 MiB) | 4개 부품별 지표·confusion·classifier-only simulation; independent final test 아님 |

- M1 TRT 변환 비교: [D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/parts_parity_v001.json](<D:/OneDevice_Team_project/runs/engine_dynamic_pose_002/parts_parity_v001.json>) — 72개 대표 입력 중 기존 parity PASS 72개. 전체 최종 정확도 평가가 아니다. 두 모델의 빌드 manifest·M2 export 기록은 JSON `conversion_evidence`에 실제 경로/크기/SHA 포함.
- 참고 STATIC300: [D:/OneDevice_Team_project/runs/engine_shadow_static_robustness_003/v001_20261006T082404Z/STATIC_300_RESULTS.json](<D:/OneDevice_Team_project/runs/engine_shadow_static_robustness_003/v001_20261006T082404Z/STATIC_300_RESULTS.json>) — 정지 정상 setup 300프레임, 고유 raw/시각 300, PASS_CANDIDATE300/오분류0라는 **기존 기록**. 동일 구성의 정상 정지 관찰이며 혼합 PLC 300회 시험이 아니다. [D:/OneDevice_Team_project/runs/engine_shadow_static_robustness_003/v001_20261006T082404Z/USED_MODEL_CONFIG_HASHES.json](<D:/OneDevice_Team_project/runs/engine_shadow_static_robustness_003/v001_20261006T082404Z/USED_MODEL_CONFIG_HASHES.json>)로 현재 참고 PT와 연결. 원본 evidence archive [D:/OneDevice_Team_project/runs/engine_shadow_static_robustness_003/v001_20261006T082404Z/live300_evidence.tar.gz](<D:/OneDevice_Team_project/runs/engine_shadow_static_robustness_003/v001_20261006T082404Z/live300_evidence.tar.gz>) — 641,726,654 B (612.00 MiB); 아카이브 전체 내용을 이번에 재검증하지 않음.
- 최근 혼합 실물: [D:/OneDevice_Team_project/runs/config_ui_history_20261018/field_ten/FINAL_SUMMARY.json](<D:/OneDevice_Team_project/runs/config_ui_history_20261018/field_ten/FINAL_SUMMARY.json>) — 계획10/실제7, PASS4/FAIL3, REVIEW0/ERROR0, 원본21장, PLC 완료7. 실행본 **4c4b935f8ab0404a**. 그 후 UI만 변경한 현재32c4와의 연결은 [D:/OneDevice_Team_project/docs/verification/CONFIG-UI-HISTORY-20261018.json](<D:/OneDevice_Team_project/docs/verification/CONFIG-UI-HISTORY-20261018.json>).
- 해당 7건의 통합 응답 기존 기록: 10.183–14.324초. 추론 단독 시간·현재 전체392건 성능으로 대체해서 쓰지 않는다.
- 평가 그림은 M1/M2 학습 폴더의 `results.png`, `confusion_matrix.png`, `val_batch*_pred.jpg`, M1 `val_predictions/` 등에 보관. 학습/평가용 시각화이며 모델 입력 원본과 구분한다.

## 7. 검사 DB·원본 이미지
| 항목 | 실제 경로 | 수량·용량 | 연결 / 확인 방법 |
| --- | --- | --- | --- |
| 현재 Jetson SQLite | `/home/jetson/oned_device_bench/data/engine_dynamic_pose_002/journal.sqlite3` | 392검사 / 104,394,752 B (99.56 MiB) | 읽기 전용 SQLite snapshot transaction으로 행 수 확인. 최신 완료 UTC 2026-10-19T02:10:32.466257+00:00; SQLite 파일 크기는 WAL까지 합친 백업 크기가 아님. |
| 현재 Jetson 원본 | `/home/jetson/oned_device_bench/data/engine_dynamic_pose_002/assets/<inspection_id>/<asset_id>.png` | 1,113장 / 1,376,422,573 B (1312.66 MiB) | 원장 raw 행→파일 존재·크기1113/1113. DB SHA는 기록값이며 원본 전체 SHA를 이번에 재계산하지 않음. 여러 운영 시점의 기록 포함. |
| 현재 Jetson 표시 이미지 | 동일 assets 아래 .jpg | 371장 / 92,934,733 B (88.63 MiB) | 원장 overlay 행→파일 존재·크기371/371. 원본 사진으로 세지 않음. |
| Windows/GitHub DB 사본 | [D:/OneDevice_Team_project/database/snapshots/20261018_post7/journal.sqlite3](<D:/OneDevice_Team_project/database/snapshots/20261018_post7/journal.sqlite3>) | 368검사 / 94,973,952 B (90.57 MiB) | 10/18 사본. 현재392건과 동일시하지 않음. SHA 19d18d00ed41a54aec793ed298cbca8b0a42e11880def25642ec06d8bb308c8d |
| Windows에서 실제 찾은 검사 사진 | [D:/OneDevice_Team_project/docs/evaluation_assets/20261019/inspection_assets_local_matches.csv](<D:/OneDevice_Team_project/docs/evaluation_assets/20261019/inspection_assets_local_matches.csv>) | 원본432장·표시135장, 중복 복사 제외 | 기존 snapshot의 asset ID/파일명으로 탐색 후 전체 파일 SHA 일치. DB에 경로만 있다고 실파일 보유로 세지 않음. |
| 최근 7회 원본21장 | Jetson assets 내 해당 inspection ID별 경로(목록 CSV) | Jetson21장 존재 / Windows 검색 경로에서0장 | 최근7건 요약의 ID와 원장·실파일 연결. 원본을 새로 복사하지 않았다. |

각 검사 ID·raw/overlay 구분·정확한 전체 파일 경로·크기·원장 SHA: [D:/OneDevice_Team_project/docs/evaluation_assets/20261019/inspection_original_files_remote.csv](<D:/OneDevice_Team_project/docs/evaluation_assets/20261019/inspection_original_files_remote.csv>). 로컬에서 찾은 실제 복사본의 정확한 경로: [D:/OneDevice_Team_project/docs/evaluation_assets/20261019/inspection_assets_local_matches.csv](<D:/OneDevice_Team_project/docs/evaluation_assets/20261019/inspection_assets_local_matches.csv>). 검사 원본에는 옛 엔진/개발/진단 거래도 포함될 수 있으므로 전체392건을 현재 운영본의 정답 성능 분모로 사용하지 않는다.

## 8. 녹화·진단 연속 원본

Jetson `/home/jetson/oned_device_bench/captures`에서 기록 폴더 15개, PNG 769장 / 910,165,064 B (868.00 MiB), 부가 메타데이터 등을 포함한 총 1,015,110,406 B (968.08 MiB) 확인. 아래 수량은 receipt와 실제 파일 집계를 대조한 결과다. 진단 PNG는 위 검사 원본1113장과 별도 자산이다.
| Jetson 실제 폴더(각 raw/ 및 JSONL 포함) | PNG 수 | PNG 용량 | 범위 | 확인 방법 |
| --- | --- | --- | --- | --- |
| /home/jetson/oned_device_bench/captures/20261007T023540Z_BELT_EMPTY_20261007_002_78ff6cd7 | 12 | 11,790,085 B (11.24 MiB) | 진단/정지 관찰 | 실파일 stat + receipt |
| /home/jetson/oned_device_bench/captures/20261007T023735Z_BELT_empty003_0fe1cba5 | 12 | 14,194,705 B (13.54 MiB) | 진단/정지 관찰 | 실파일 stat + receipt |
| /home/jetson/oned_device_bench/captures/20261007T024338Z_BELT_empty004_e5c9b5d4 | 60 | 71,106,965 B (67.81 MiB) | 진단/정지 관찰 | 실파일 stat + receipt |
| /home/jetson/oned_device_bench/captures/20261018T053112Z_reliability_empty_20261018_v001_40d6d6d6 | 52 | 64,131,494 B (61.16 MiB) | 진단/정지 관찰 | 실파일 stat + receipt |
| /home/jetson/oned_device_bench/captures/20261018T053728Z_reliability_normal_20261018_v001_6144d537 | 52 | 64,138,413 B (61.17 MiB) | 진단/정지 관찰 | 실파일 stat + receipt |
| /home/jetson/oned_device_bench/captures/20261018T054505Z_reliability_normal_20261018_v002_6ae86beb | 52 | 60,447,120 B (57.65 MiB) | 진단/정지 관찰 | 실파일 stat + receipt |
| /home/jetson/oned_device_bench/captures/20261018T055201Z_reliability_right_missing_20261018_v001_50e8fe3a | 52 | 61,547,279 B (58.70 MiB) | 진단/정지 관찰 | 실파일 stat + receipt |
| /home/jetson/oned_device_bench/captures/20261018T055227Z_reliability_right_missing_20261018_v002_db7b205d | 51 | 60,387,292 B (57.59 MiB) | 진단/정지 관찰 | 실파일 stat + receipt |
| /home/jetson/oned_device_bench/captures/20261018T055926Z_reliability_right_center_20261018_v001_54fb6ae4 | 52 | 62,171,491 B (59.29 MiB) | 진단/정지 관찰 | 실파일 stat + receipt |
| /home/jetson/oned_device_bench/captures/20261018T060237Z_reliability_right_rotated_20261018_v001_754c4613 | 52 | 61,354,222 B (58.51 MiB) | 진단/정지 관찰 | 실파일 stat + receipt |
| /home/jetson/oned_device_bench/captures/20261018T061013Z_reliability_right_opposite_20261018_v001_c81247bf | 51 | 60,123,280 B (57.34 MiB) | 진단/정지 관찰 | 실파일 stat + receipt |
| /home/jetson/oned_device_bench/captures/20261018T061333Z_reliability_right_other_tilt_20261018_v001_58fe29e9 | 51 | 60,978,125 B (58.15 MiB) | 진단/정지 관찰 | 실파일 stat + receipt |
| /home/jetson/oned_device_bench/captures/20261018T072547Z_reliability_operating_normal_20261018_v001_a886215b | 0 | 0 B (0.00 MiB) | RUN_DIAGNOSTIC | 원본0장 — 유효 녹화 아님 |
| /home/jetson/oned_device_bench/captures/20261018T074138Z_reliability_operating_normal_20261018_v002_290fa16c | 220 | 257,794,593 B (245.85 MiB) | RUN_DIAGNOSTIC | 실파일 stat + receipt |
| /home/jetson/oned_device_bench/captures/20261018T080148Z_reliability_operating_normal_20261018_v003_0f5e34fc | 0 | 0 B (0.00 MiB) | RUN_DIAGNOSTIC | 원본0장 — 유효 녹화 아님 |

Windows에도 보관된 STOP 진단 원본:
| 실제 폴더 | PNG 수 | 용량 | 확인 방법 |
| --- | --- | --- | --- |
| [D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T053112Z_reliability_empty_20261018_v001_40d6d6d6](<D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T053112Z_reliability_empty_20261018_v001_40d6d6d6>) | 52 | 64,131,494 B (61.16 MiB) | raw/*.png 집계 + receipt 저장 수 일치 |
| [D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T053728Z_reliability_normal_20261018_v001_6144d537](<D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T053728Z_reliability_normal_20261018_v001_6144d537>) | 52 | 64,138,413 B (61.17 MiB) | raw/*.png 집계 + receipt 저장 수 일치 |
| [D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T054505Z_reliability_normal_20261018_v002_6ae86beb](<D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T054505Z_reliability_normal_20261018_v002_6ae86beb>) | 52 | 60,447,120 B (57.65 MiB) | raw/*.png 집계 + receipt 저장 수 일치 |
| [D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T055227Z_reliability_right_missing_20261018_v002_db7b205d](<D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T055227Z_reliability_right_missing_20261018_v002_db7b205d>) | 51 | 60,387,292 B (57.59 MiB) | raw/*.png 집계 + receipt 저장 수 일치 |
| [D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T055926Z_reliability_right_center_20261018_v001_54fb6ae4](<D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T055926Z_reliability_right_center_20261018_v001_54fb6ae4>) | 52 | 62,171,491 B (59.29 MiB) | raw/*.png 집계 + receipt 저장 수 일치 |
| [D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T060237Z_reliability_right_rotated_20261018_v001_754c4613](<D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T060237Z_reliability_right_rotated_20261018_v001_754c4613>) | 52 | 61,354,222 B (58.51 MiB) | raw/*.png 집계 + receipt 저장 수 일치 |
| [D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T061013Z_reliability_right_opposite_20261018_v001_c81247bf](<D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T061013Z_reliability_right_opposite_20261018_v001_c81247bf>) | 51 | 60,123,280 B (57.34 MiB) | raw/*.png 집계 + receipt 저장 수 일치 |
| [D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T061333Z_reliability_right_other_tilt_20261018_v001_58fe29e9](<D:/OneDevice_Team_project/runs/inspection_reliability_20261018/diagnostic_raw/20261018T061333Z_reliability_right_other_tilt_20261018_v001_58fe29e9>) | 51 | 60,978,125 B (58.15 MiB) | raw/*.png 집계 + receipt 저장 수 일치 |

- 각 폴더의 `capture_index.jsonl` 또는 `frames.jsonl`, `runtime.jsonl`, `receipt.json`에 frame ID·시각·검출/상태가 연결된다. 이번 조사에서 진단을 새로 촬영하거나 이미지를 동영상으로 변환하지 않았다.
- `reliability_normal_..._v001`은 이름과 달리 기존 검토상 빈 벨트다. 정상 진단 자료는 v002와 구분해야 한다. `right_missing_v001`도 v002 재촬영과 중복해서 독립 사례로 세지 않는다.
- RUN v002 **220장 / 19.864초**는 실제 존재하지만, [D:/OneDevice_Team_project/runs/inspection_reliability_20261018/run_capture_polarity_transition/FIELD_v002_FINDINGS.md](<D:/OneDevice_Team_project/runs/inspection_reliability_20261018/run_capture_polarity_transition/FIELD_v002_FINDINGS.md>)에 따르면 빈 벨트·요청0/IDLE이다. 실제 PASS 검사는 녹화 종료 약14초 뒤에 있었으므로 이 클립을 검사 전 과정으로 제출하면 안 된다.
- RUN v001/v003은 receipt가 SAVED여도 실제0장이다. 실제 검사 성공 여부와 진단 녹화 성공 여부는 별개다.
- 정지 참고300의 원본 archive는 위 평가 절에 별도 기재했다. 그것을 실제 컨베이어 이동 영상으로 설명하지 않는다.

## 9. 미확인 항목과 검색 범위

**Independent final test split/files/results for current model — 보유 미확인**

Both detector datasets contain train/val only. E04 72 frames reserved per prior source_audit metadata; holdout contents not opened. No completed independent final test evidence verified.

검색/대조 위치:
- `D:\OneDevice_Worktrees\jetson-p0-004c0\runs\manual_tracking_dev\engine_parts_CFA8507_v001\outputs\run_20260921T082749Z_709634\dataset`
- `D:\OneDevice_Team_project\runs\engine_dynamic_pose_002\dataset_v004`
- `D:\OneDevice_Worktrees\jetson-p0-004c0\runs\manual_tracking_dev\engine_parts_CFA8507_v001\source_audit.json`
- `D:\OneDevice_Team_project\runs\engine_misassembly_baseline_training_001\v001_20261002T191929Z`

**Encoded operating video (MP4/AVI/MKV/MOV/WebM/H264/MJPEG) — 보유 미확인**

No such files in enumerated unpacked roots. PNG sequences+timestamps exist. Archives beyond named backup were not exhaustively scanned.

검색/대조 위치:
- `D:\OneDevice_Team_project\runs`
- `D:\OneDevice_Team_project\data`
- `D:\OneDevice_Team_project\assets`
- `D:\OneDevice_Team_project\output`
- `D:\OneDevice_Team_project\releases`
- `D:\OneDevice_Team_project\.scratch`
- `/home/jetson/oned_device_bench/captures`
- `/home/jetson/oned_device_bench/data/engine_dynamic_pose_002`

**Full operating segment entering→stop→3-frame inspection→exit — 일부 확보**

220 PNG run clip physically exists; prior scene review says empty belt, not a complete engine transaction. Two other RUN clips have zero raw frames; not valid recordings.

검색/대조 위치:
- `D:\OneDevice_Team_project\runs\inspection_reliability_20261018\run_capture_polarity_transition\field_v002`
- `/home/jetson/oned_device_bench/captures`

공통 제한: 원본 데이터 디렉터리는 읽기 조사했으며, 보호된 E04/B04 내용과 아카이브 내부의 test 이미지는 열지 않았다. Windows 파일명 검색은 지정 프로젝트의 runs/data/assets/output/releases/.scratch에 한정했다. 원본 worktree는 현재 모델 출처의 train/val run만 조사했다. 각 archive 전체와 다른 디스크·개인 영상 폴더를 전수 검색한 것은 아니다.

## 10. 제출 준비 시 구분해야 할 부분

1. 즉시 제시 가능한 것은 운영본 해시 연결, train/val 원본·라벨·목록, 원본/변환 모델, 학습 설정·개발 평가, 실제 Jetson 검사 사진과 DB, 기존 진단 프레임이다.
2. 별도 최종 시험 성적표와 엔진 이동→검사→배출을 온전히 보여주는 제출용 영상은 확보됐다고 표시할 수 없다. 새로운 촬영/평가는 이번 범위에서 하지 않았다.
3. 원본 PT·학습 이미지의 일부는 외부 worktree, 검사 원본 대부분은 Jetson에 있다. GitHub에 모든 자료가 들어 있다고 해석하지 않는다.
4. 현 운영본의 알려진 USB 복구·위치 편차·응답 지연 한계는 기존 기록 그대로 남는다. 보유 자산 조사 완료를 그 문제 해결 완료로 사용하지 않는다.

기계 판독 목록: [D:/OneDevice_Team_project/docs/evaluation_assets/20261019/asset_inventory.json](<D:/OneDevice_Team_project/docs/evaluation_assets/20261019/asset_inventory.json>); 조사 원시 evidence: [D:/OneDevice_Team_project/runs/evaluation_asset_inventory_20261019/remote_inventory.json](<D:/OneDevice_Team_project/runs/evaluation_asset_inventory_20261019/remote_inventory.json>) / [D:/OneDevice_Team_project/runs/evaluation_asset_inventory_20261019/remote_model_detail.json](<D:/OneDevice_Team_project/runs/evaluation_asset_inventory_20261019/remote_model_detail.json>) / [D:/OneDevice_Team_project/runs/evaluation_asset_inventory_20261019/media_search.json](<D:/OneDevice_Team_project/runs/evaluation_asset_inventory_20261019/media_search.json>).
