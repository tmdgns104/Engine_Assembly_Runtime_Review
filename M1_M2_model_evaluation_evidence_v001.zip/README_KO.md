# 모델 학습·평가 보고서 작성용 기존 증빙 묶음

작성일: 2026-10-19. 묶음: `M1_M2_model_evaluation_evidence_v001`.

**이 ZIP은 기존 학습·평가 결과를 모은 증빙이다. 이번 작업에서 새 학습·추론·평가·모델 변환·장치 접속·운영 변경을 하지 않았다.** E04/B04 최종시험 이미지·정답, 모델 바이너리, 전체 데이터셋, STATIC300 아카이브, 검사 DB는 포함하지 않았다.

기준은 기존 자산 인벤토리와 `M1_M2_dataset_evidence_v001`이다. 같은 원본·분할·모델 해시를 사용한다. M1/M2는 각각 train 144장(E01+E02), val 72장(E03)을 사용하며 두 모델이 동일한 원본 216장을 공유한다. 클래스 라벨은 다르다. **E03은 개발 검증이며 독립 최종시험이 아니다.** 조명 수치·거리·실측 각도 등 미기록 조건을 보충하지 않았다.

## 보고서 작성에 사용할 파일

- 학습 곡선: [M1 results.png](M1/training/results.png), [M2 results.png](M2/training/results.png). 각 `training/results.csv`는 전체 행을 보존한다.
- 검증 지표 원문: [M1 JSON](M1/validation_metrics.json), [M2 JSON](M2/training_result.json), 편의 표 [validation_metrics.csv](tables/validation_metrics.csv).
- 그림 전체 위치·범위: [figures.csv](tables/figures.csv). 기존 그림 **61개**와 선정 사례의 기존 예측 사진 **20개**를 포함한다.
- 사례: [examples.csv](examples.csv), [사례 사진 모음](EXAMPLES_KO.md). 원본 10장, M1/M2 정답 TXT 각 10개, 예측 사진 각 10개. CSV 한 행이 하나의 이미지 ID다.
- 모델 연결: [model_hash_chain.json](verification/model_hash_chain.json), 각 모델의 `conversion/`·`deployment/`, `runtime/`.
- 모든 원본의 실제 경로·복사본 크기·SHA: [bundle_manifest.json](bundle_manifest.json). 각 파일은 원문 복사 또는 새 집계/설명인지 구분된다. 압축본의 SHA·CRC·파일별 대조 결과는 ZIP 옆 검증 JSON에 별도로 기록한다.

`data.yaml`은 **학습 당시 절대경로 원문**이다. 이 ZIP만으로 재학습하는 설치 패키지가 아니므로 경로를 수정하지 않았다. 복사한 Python은 호출 조건을 설명하는 증빙이며 실행할 필요가 없다.

## 1. 모델별 학습 설정과 기존 검증 지표

| 항목 | M1 부품 검출 | M2 엔진 전체 검출 |
|---|---|---|
| 운영 패키지 / 모델 버전 | dynamic_parts_005 / CFA8507_original_PT_fp16_head32 | envelope_v007_fp16 / envelope_v004_E01_E02_144 |
| 학습 구조 | YOLO11n, 검출 3클래스 | YOLO11n, 검출 1클래스 |
| 클래스 | 0 gray_pipe, 1 exhaust_top, 2 symbol_module | 0 product_envelope |
| 파이프 좌우 의미 | 두 파이프 모두 gray_pipe; 좌우 결품은 촬영 출처/검사 자리로 구분 | 회전각 회귀 모델이 아님 |
| train / val | 144 / 72장, 정답 box 384 / 192개 | 144 / 72장, 정답 box 144 / 72개 |
| 입력 / batch / seed / workers | 640 / 8 / 42 / 0 | 640 / 8 / 42 / 0 |
| 최대 epoch / 실제 수행 | 100 / 100 | 100 / 57 |
| best.pt 선택 epoch | **기존 자료 미확인**. CSV 최고를 선택 epoch로 단정하지 않음 | **37**, EarlyStopping 로그에서 명시 |
| CSV mAP50–95 최고 epoch | 96, 0.66462 | 37, 0.88428 |
| 종료 근거 | 100 epochs completed 로그 | 20 epoch 개선 없음, patience=20; 57에서 조기 종료 로그 |
| optimizer 설정 → 실제 로그 | auto → AdamW(lr=0.001429, momentum=0.9) | auto → AdamW(lr=0.002, momentum=0.9) |
| AMP | false | false |
| CSV 마지막 시간 | 650.589초 | 889.763초 |
| 콘솔 학습 시간 | 0.181시간 | 0.247시간 |
| 추가 시간 기록 | 전체 작업 소요시간 미확인 | training_result 949.703388초: 코드상 train+별도 val+72장 예측/저장 포함 구간 |
| 당시 GPU | NVIDIA GeForce RTX 5070 Laptop GPU, CUDA:0, 로그 8151MiB | 동일 |
| 당시 학습 환경 | Python 3.13.5 / torch 2.10.0+cu128 / Ultralytics 8.3.253 | 동일, train_console_v004.log에서 확인 |

학습·검증 당시 환경과 export 환경은 다르다. export 기록의 torch 2.11.0+cu128 / Ultralytics 8.4.146 / ONNX 1.22.0을 학습 버전으로 적지 않는다. 현재 PC 패키지 버전은 이 표의 근거로 사용하지 않았다.

증강은 원문 설정과 실행 호출을 함께 본다. M1 호출에서 degrees=0, fliplr=0, flipud=0, mosaic=0을 지정한다. M1 args에는 translate=0.1, scale=0.5, hsv_h/s/v=0.015/0.7/0.4도 기록돼 있다. M2 호출은 degrees=180, translate=0.2, scale=0.25, mosaic=0.5, flipud/fliplr=0, close_mosaic=10을 지정한다. 각 샘플에 실제 적용된 난수 변환 내역은 저장돼 있지 않다. 공통 args의 `auto_augment`, `erasing`, `copy_paste` 등을 모두 실제 검출 학습 증강으로 설명하지 않는다. 설정상 close_mosaic=10과 **조기 종료된 마지막 10 epoch에 실제 mosaic가 꺼졌다는 주장도 구분**한다.

| 모델 | Precision | Recall | mAP50 | mAP50–95 |
|---|---:|---:|---:|---:|
| M1 | 0.99769565 | 1.00000000 | 0.99500000 | 0.66472551 |
| M2 | 0.96040778 | 1.00000000 | 0.99500000 | 0.88426952 |

수치는 best.pt를 다시 불러 실행한 **기존 Windows PT E03 검증**이다. 전체 정밀값은 원문 JSON에 있다. CSV epoch 행과 별도 val 수치는 약간 다르므로 서로 덮어쓰지 않았다. 집계 P/R에서 TP·FP·FN 수를 역산하지 않았다. 현재 Jetson TensorRT의 실측 mAP 또는 설비 PASS/FAIL 정확도로 표기하면 안 된다. M2 AP는 엔진 박스 검출 지표이며 회전각·자세 정확도가 아니다.

## 2. 지표·그림의 출처와 적용 범위

| 증빙 | 생성 근거 | 보고서에 적용할 범위 / 제한 |
|---|---|---|
| M1 training/results.csv·results.png | 해당 run의 model.train, 100행/완료 로그 | epoch별 학습·개발 검증 변화. 한 checkpoint의 결과와 구분 |
| M2 training/results.csv·results.png | train_envelope.py의 envelope_v004, 57행/조기 종료 로그 | 최대100과 실제57 구분 |
| 모델별 training의 confusion/PR/F1/P/R/val_batch | 해당 학습 출력 폴더; 마지막 best.pt 검증 로그도 존재 | 개별 그림에 checkpoint SHA가 내장돼 있지 않아 폴더만으로 생성 시점을 단정하지 않음 |
| M1 validation/* | train_engine_parts.py에서 best.pt reload 후 val, 로그의 저장 경로 일치 | 보고서 검증 그림은 이 별도 val 폴더를 우선 사용 |
| M2 validation/* | train_envelope.py에서 best.pt reload 후 val, validation/e03 로그 | 별도 PT E03 검증 그림; 임의 그림 재생성 없음 |
| M1 기존 예측 사진·JSONL | 같은 코드에서 best.pt reload 후 model.predict, conf=0.25 | 원본 72장 중 설명용 10ID 선정. 학습 자동 val 그림과 다른 예측 호출 |
| M2 기존 *_pred.jpg·JSON | 같은 코드의 best.pt trained.predict, conf=0.05, iou=0.45, rect=False | M2 그림의 후보 점수 조건은 운영 conf=0.25와 다름 |
| M1 prediction_diagnostics.json | 기존 저장 예측을 정답에 대조한 사후 기록 | conf0.25 / 정답 매칭 IoU≥0.50, 클래스별 confidence 내림차순 일대일 매칭; TP192 FP0 FN0 원문 보존 |
| M1 parts_parity_v001.json | 기존 Jetson PT reference↔TRT 72장 수치 대조 | 모델 변환 차이; 정답 AP 평가가 아니며 현재 운영 후처리 전체 재평가도 아님 |

`val_batch*_labels.jpg`와 `val_batch*_pred.jpg`는 원래 합성 배치 그림 그대로 보관한다. 사례 ID 연결에는 파일명이 명확한 개별 Dxxx 예측을 사용했으며, 합성 그림의 타일 순서로 ID를 추정하지 않았다. 원본 수치형 framework 혼동행렬 CSV/JSON은 지정 학습·validation 폴더와 지표 JSON에서 **기존 자료 미확인**이다. 참고 분류 부록의 수치 혼동행렬을 M1/M2 검출 혼동행렬로 사용하지 않는다.

### 평가 confidence / NMS / 정답 매칭을 구분

| 절차 | confidence | NMS IoU | 정답 또는 모델 간 매칭 |
|---|---|---|---|
| M1/M2 별도 framework val | 호출에서 미지정, effective 값 기록 미확인 | 호출에서 미지정; train args의 iou=0.7은 남아 있으나 별도 val 실효값 영수증 없음 | mAP50·mAP50–95 결과 명칭과 framework 버전 보존; matching 구현의 당시 snapshot 미확인 |
| M1 설명용 저장 predict | 명시 0.25 | 호출에서 미지정; 실행 effective 값 별도 미확인 | 사진 생성 자체는 GT 매칭 없음 |
| M2 설명용 저장 predict | 명시 0.05 | 명시 0.45 | 사진 생성 자체는 GT 매칭 없음 |
| M1 기존 사후 진단 | 0.25 | 이미 저장된 predict 사용 | GT IoU≥0.50; 기존 TP/FP/FN 기록 |
| M1 parity 보존 정책 | 0.25 | **0.70**, class-aware | PT/TRT 같은 클래스·개수, bbox IoU≥0.98 및 점수 절대차≤0.02 |
| 관측 운영 패키지 | 0.25 | **0.45** | 운영 후처리 설정이며 PT 검증·parity 당시 조건의 대체값이 아님 |

기존 parity의 NMS 0.70과 현재 운영 NMS 0.45가 다르므로, 동일 가중치 해시만으로 현재 운전 설정에서 72/72 parity를 다시 확인했다고 쓰지 않는다. 원래 M1 predict는 `rect`를 명시하지 않았고, parity는 직접 고정 정사각 전처리한다. 둘 다 imgsz640이어도 입력 텐서가 같다고 간주하지 않는다.

## 3. 운영 모델까지의 SHA-256 연결

기준 운영본은 기존 관측 **engine-integrated-32c484ac6aeb07f1**, 호스트 jetson-07, 관측 시각 **2026-10-19T05:20:11.909981+00:00**이다. 이번에 장치에 새 접속하거나 다시 실행한 증거는 아니다.

| 모델 | 단계 | 실제 보관 파일 SHA-256 |
|---|---|---|
| M1 | PT | `42db183006ad2a4f61dc9c22e7a61a5b506cdacb5099004fc7c3b73b74bf5259` |
| M1 | ONNX | `433b16fd1e802bdf2cb0afba6bb6487a839d94b5adc286185b93fd3953b9c296` |
| M1 | TensorRT | `743ce54b4d5c7b8a36addf3dbff50fa693ec4a509b31b476f68efc69f1bf2d6c` |
| M2 | PT | `cf117defe782e1ae8b355e0ed13c014fc6f1538aa2dcdbe0fb6cfa54200f7755` |
| M2 | ONNX | `5cb024bb911f9357e46c12c3d2a7e4b5f19af20e5692013037c9235e0deca830` |
| M2 | TensorRT | `c82f2658ac20d06985a647c15e551c681e394451cfa1c53baed64f639bcebf83` |

| 모델 | 확인한 연결 | 결과 |
|---|---|---|
| M1 | models/engine_parts_best.pt = training/engine_parts/weights/best.pt → controlled_export source_pt/onnx → build_manifest ONNX/PLAN → 제품 manifest → 32c4 release 파일 목록 → 기존 Jetson 실파일 해시 | **모든 해시 일치** |
| M2 | training/envelope_v004/weights/best.pt = envelope_export_v004/envelope_best.pt → envelope_export.json pt_sha256/source_onnx.sha256 → v007 build_manifest → 제품 manifest → 32c4 → 기존 Jetson 해시 | **모든 해시 일치** |

특히 이름에 v004가 없는 `envelope_export.json`도 원문의 PT SHA와 `source_onnx.sha256`, `onnx_path`가 **현재 보관 envelope_export_v004**와 일치한다. 해당 export log 역시 v004 경로를 명시한다. 이 연결은 파일명 추정이 아닌 실제 바이트 해시 대조다.

`runtime/remote_release_observation_excerpt.json`은 기존 remote_inventory.json의 release·관측 시각 부분을 뽑은 **발췌**다. 원문 경로·원문 SHA·JSON pointer를 남겼으며 원래 release 파일 바이트를 새로 관측했다고 주장하지 않는다. DB 행·전체 원본 목록을 피하기 위해 원격 인벤토리 전체를 복제하지 않았다. `runtime/RELEASE_MANIFEST.json`과 `remote_model_detail.json`은 원문 그대로다.

### M1 parity 72/72의 확인 범위

- 기존 결과 72/72 PASS, 모델 PT/ONNX/PLAN SHA가 위 M1과 일치하고 TRT 실행 메타데이터에도 실제 engine SHA·execute_count=72가 있다.
- D145–D216 72개 입력의 reference SHA를 보관 E03 원본과 다시 대조했다. `pt_reference.json`과 보존 `parity_pt_training/results.json` 내용도 일치한다.
- 원본 1280×720 BGR → linear resize, 중앙 padding114 letterbox → RGB/255, float32 NCHW `[1,3,640,640]`. 출력 raw head `[1,7,8400]`, objectness 없음. 외부 class-aware NMS 후 padding/gain 역변환. ONNX nms=false이므로 NMS 중복 적용 경로로 기록돼 있지 않다.
- 보존 정책/비교 코드 조건: 같은 클래스와 개수, bbox IoU≥0.98, confidence 절대차≤0.02. 좌표 절대차는 진단 값이며 별도 gate가 아니다. 저장된 192개 쌍의 최소 IoU 0.99517267, 최대 confidence 차 0.01304412를 기존 수치에서 집계했다. 새 예측/GT 매칭은 하지 않았다.
- **남은 출처 한계:** check_parts_jetson.py의 옛 원격 import 경로 `engine_parts_pkg_candidate_001_20260922`는 현재 로컬에 없고, 대응 코드·PT reference는 `engine_package_integration_001`에서 확보했다. 72/72 JSON에 당시 import된 helper/reference 파일 자체의 SHA는 없다. 따라서 현재 보관 코드와 당시 실행 코드 바이트의 완전 동일성까지 인증하지 않는다. 이 한계와 운영 NMS 차이는 `verification/parity_record_audit.json`에 보존했다.

### 지연시간은 장치와 측정 구간별로 읽기

| 기존 자료 | 장치 / 범위 | 기록 값 |
|---|---|---|
| M1 학습 run 별도 val 콘솔 | Windows RTX5070 Laptop / framework batch 검증의 per-image 항목 | preprocess 0.8ms, inference 6.0ms, postprocess 0.7ms |
| M2 별도 val 콘솔 | Windows RTX5070 Laptop / batch8 검증 per-image 항목 | preprocess 0.4ms, inference 4.3ms, postprocess 1.1ms |
| M1 parts_parity_v001 | Jetson native TRT 10.3 / CUDA12.6·SM8.7 / 저장 E03, detect 호출 전후 host timing | 첫 호출 107.166ms, 이후71건 p50 30.055ms, p95 31.519ms |

Jetson detect 시간은 host 전처리+실행 완료+후처리를 포함한다. 순수 GPU kernel 시간, 카메라 FPS, 프로세스 시작/모델 로드 시간, PLC 요청→Result/Done 전체 응답시간이 아니다. 현재 운영 M2의 독립적인 latency benchmark를 이 표에 추가하지 않았다. 표의 서로 다른 batch/호스트/입력 경로를 직접 속도 배수로 비교하지 않는다.

## 4. 확보한 실제 사례와 알려진 한계

모든 사례는 설명용 E03이며 새 평가셋이 아니다. 파일명 상태를 추측하지 않고 source_index의 `scenario_capture_truth`와 실제 대응 라벨을 사용했다. 원본은 두 데이터셋 SHA가 동일한 것을 확인하여 한 번만 넣었다. M1/M2 TXT는 각 데이터셋에서 그대로 복사했다.

| 이미지 ID | 촬영 상태 | 선정 이유 |
|---|---|---|
| D145 | NORMAL | 정상 기본 사례; 두 파이프·배기·문양 및 M2 전체 박스 |
| D151 | NORMAL | 정상; 기존 검토에서 배기 confidence 최저 0.6512 사례 |
| D156 | NORMAL | 정상; 기존 검토의 배기 박스 경계 차이 IoU 0.6372 |
| D159 | MISSING_PIPE_LEFT | 왼쪽 파이프 결품; 남은 파이프와 다른 클래스 비교 |
| D172 | MISSING_PIPE_RIGHT | 오른쪽 파이프 결품; 기존 검토의 배기/파이프 박스 위치 차이 |
| D180 | MISSING_PIPE_RIGHT | 오른쪽 파이프 결품; 다른 목표 회전 구도의 설명용 사례 |
| D187 | MISSING_EXHAUST_TOP | 배기 부품 결품; 다른 부품은 존재 |
| D201 | MISSING_SYMBOL_MODULE | 문양 부품 결품; 다른 부품은 존재 |
| D205 | MISSING_ALL_TARGETS | 전체 대상 부품 결품; M1 빈 라벨·빈 예측이나 M2 엔진 존재 |
| D215 | MISSING_ALL_TARGETS | 전체 대상 부품 결품; 다른 구도에서도 빈 벨트와 구분 |

기존 M1 리뷰는 AI 보조 검토이며 새로운 사람 승인이 아니다. **D156 배기 IoU 0.6372, D172 배기 0.6672/파이프 0.6835**는 기존 prediction_diagnostics와 RESULT_KO의 박스 위치 사례다. D151의 배기 confidence 0.6512 역시 기존 저장 수치이며 밝은 표면의 반사가 원인이라고 확정하지 않는다. 기존 conf0.25/GT IoU0.50 범위의 M1 FP/FN은 0이지만 박스 경계 오차는 남는다. M2의 별도 GT 매칭 오류 목록은 기존 자료 미확인이다.

전체 대상 결품은 네 필수 부품이 없고 **엔진 몸체는 존재**한다. M1 빈 라벨/빈 예측과 M2 product_envelope 검출은 서로 모순이 아니다. 이를 빈 벨트 또는 정상 PASS 사례로 설명하지 않는다. 좌우 결품은 원 촬영 기준 이름이며, 회전한 사진의 화면 좌우로 이름을 바꾸지 않았다.

## 5. 미확인 자료와 검색 범위

| 항목 | 확인 결과 / 이유 |
|---|---|
| M1 best.pt 선택 epoch | 기존 자료 미확인; CSV mAP50-95 최고 epoch96만 확인. PT를 로드해 추정하지 않음 |
| M1/M2 수치형 원본 혼동행렬 | 기존 자료 미확인; PNG는 있음. M1 기존 TP/FP/FN 진단은 별도 조건이며 framework 혼동행렬 대체 불가 |
| 별도 framework val의 최종 effective conf/NMS/GT matching 전체 설정 | 호출 코드·버전·train args 확보. 별도 val에서 conf/iou 미지정 및 effective args snapshot 없음; 운영 threshold로 보충하지 않음 |
| M1 72/72 parity 당시 import helper/PT reference 파일 SHA | 모델 SHA·72 ID·입력 SHA·reference 코드/정책 확보. 옛 remote path의 exact helper/ref 파일 해시 영수증은 기존 자료 미확인 |
| M2 정답 매칭 FP/FN·위치 오류의 개별 사례 목록 | 저장된 예측·그림 확보. 별도 객체 검출 FP/FN 목록은 기존 자료 미확인; P/R에서 역산하거나 새 매칭 평가하지 않음 |
| 현재 TensorRT의 독립 최종시험 mAP | 기존 자료 미확인; PT E03 지표와 수치 parity는 독립 final-test mAP가 아님. 보호 E04/B04 열람 없음 |

정확한 검색 경로는 [missing_evidence_search.json](verification/missing_evidence_search.json)에 있다. 자료 미확인은 검색한 경로에서 근거를 확보하지 못했다는 뜻이며, 모든 장치에 존재하지 않는다는 뜻이 아니다. 현재 값이나 runtime threshold로 빈칸을 채우지 않았다.

## 부록 — M3–M6 오조립 참고 모델

원문 두 개만 `appendix_reference_only/`에 포함한다: training_metrics.json, before_after_metrics.json. 미결합 최종 PASS/FAIL 지표에 섞지 않는다. 기존 Codex 검토·human_reviewed=false 개발 라벨의 참고 분류 자료이며 독립 최종시험 성능이 아니다.

| 자료 | 부품 | 후보 crop | 처리 성공 | 제외 | 성공분 accuracy / macro-F1 |
|---|---|---:|---:|---:|---:|
| 원래 crop | pipe_left | 155 | 132 | 23 | 1.0000 / 1.0000 |
| 원래 crop | pipe_right | 155 | 123 | 32 | 1.0000 / 1.0000 |
| 원래 crop | exhaust | 155 | 145 | 10 | 1.0000 / 1.0000 |
| 원래 crop | symbol | 155 | 145 | 10 | 1.0000 / 1.0000 |
| 전처리 복구 후 | pipe_left | 155 | 151 | 4 | 1.0000 / 1.0000 |
| 전처리 복구 후 | pipe_right | 155 | 151 | 4 | 1.0000 / 1.0000 |
| 전처리 복구 후 | exhaust | 155 | 151 | 4 | 1.0000 / 1.0000 |
| 전처리 복구 후 | symbol | 155 | 151 | 4 | 1.0000 / 1.0000 |

원래 후보는 클래스별 val155개이고 처리 실패는 정상으로 집계하지 않았다. 전처리 복구 후 네 모델 모두151/155 성공, 4개 제외이다. 사례 단위의 전체 crop 유효성은 원문에서 TRAIN 602 VALID+63 PARTIAL+29 FAILED → 686 VALID+8 FAILED, VALIDATION 110 VALID+35 PARTIAL+10 FAILED → 151 VALID+4 FAILED로 기록한다. 개별 crop 분모와 4개 부품이 모두 처리된 사례 분모를 혼동하지 않는다. 분류 지표 1.0은 처리 성공분에서의 값이다.

## 무결성과 실행 기록

복사본은 원본과 SHA-256을 대조하고, examples/figures/metric/log CSV의 묶음 내부 참조 경로를 검증한다. 선정 ID의 출처·원본 해시, M1/M2 라벨 대응, 예측 JSON의 ID, E03/보호시험 제외를 확인한다. PNG/JPG는 손상 여부를 확인하되 새 이미지나 정답·예측 그림을 합성하지 않는다.

`bundle_manifest.json`에는 원문 복사 파일의 실제 original_path와 파일 크기·SHA, 생성 문서에는 generated 표시 및 근거 경로를 넣는다. 자기 자신의 SHA를 자기 안에 넣을 수 없으므로 manifest 자체만 자기 목록에서 제외하고 ZIP 옆 검증 결과에 manifest SHA를 기록한다. ZIP은 CRC·파일 집합·각 파일 SHA를 다시 대조한다. 실행한 도구는 기존 자료 읽기/복사/집계/검증/압축만 수행하며 Python 도구 원문도 `tools/`에 포함한다.
