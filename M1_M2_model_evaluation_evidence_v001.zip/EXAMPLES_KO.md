# 설명용 실제 이미지 10개

원본과 기존 예측을 그대로 보여준다. GT는 실제 YOLO TXT와 기존 val_batch labels 그림을 사용한다. 아래 사진을 새로운 평가 결과나 운영 TRT 예측으로 해석하지 않는다. M1/M2 좌표·confidence 전체 원문은 examples.csv에 연결돼 있다.

## D145 — NORMAL

정상 기본 사례; 두 파이프·배기·문양 및 M2 전체 박스

| 원본 | M1 기존 PT 예측 | M2 기존 PT 예측 |
|---|---|---|
| ![원본](examples/D145/original/D145.png) | ![M1](examples/D145/predictions/M1/D145.jpg) | ![M2](examples/D145/predictions/M2/D145_pred.jpg) |

정답: [M1 TXT](examples/D145/labels/M1/D145.txt) · [M2 TXT](examples/D145/labels/M2/D145.txt)

## D151 — NORMAL

정상; 기존 검토에서 배기 confidence 최저 0.6512 사례

| 원본 | M1 기존 PT 예측 | M2 기존 PT 예측 |
|---|---|---|
| ![원본](examples/D151/original/D151.png) | ![M1](examples/D151/predictions/M1/D151.jpg) | ![M2](examples/D151/predictions/M2/D151_pred.jpg) |

정답: [M1 TXT](examples/D151/labels/M1/D151.txt) · [M2 TXT](examples/D151/labels/M2/D151.txt)

## D156 — NORMAL

정상; 기존 검토의 배기 박스 경계 차이 IoU 0.6372

| 원본 | M1 기존 PT 예측 | M2 기존 PT 예측 |
|---|---|---|
| ![원본](examples/D156/original/D156.png) | ![M1](examples/D156/predictions/M1/D156.jpg) | ![M2](examples/D156/predictions/M2/D156_pred.jpg) |

정답: [M1 TXT](examples/D156/labels/M1/D156.txt) · [M2 TXT](examples/D156/labels/M2/D156.txt)

## D159 — MISSING_PIPE_LEFT

왼쪽 파이프 결품; 남은 파이프와 다른 클래스 비교

| 원본 | M1 기존 PT 예측 | M2 기존 PT 예측 |
|---|---|---|
| ![원본](examples/D159/original/D159.png) | ![M1](examples/D159/predictions/M1/D159.jpg) | ![M2](examples/D159/predictions/M2/D159_pred.jpg) |

정답: [M1 TXT](examples/D159/labels/M1/D159.txt) · [M2 TXT](examples/D159/labels/M2/D159.txt)

## D172 — MISSING_PIPE_RIGHT

오른쪽 파이프 결품; 기존 검토의 배기/파이프 박스 위치 차이

| 원본 | M1 기존 PT 예측 | M2 기존 PT 예측 |
|---|---|---|
| ![원본](examples/D172/original/D172.png) | ![M1](examples/D172/predictions/M1/D172.jpg) | ![M2](examples/D172/predictions/M2/D172_pred.jpg) |

정답: [M1 TXT](examples/D172/labels/M1/D172.txt) · [M2 TXT](examples/D172/labels/M2/D172.txt)

## D180 — MISSING_PIPE_RIGHT

오른쪽 파이프 결품; 다른 목표 회전 구도의 설명용 사례

| 원본 | M1 기존 PT 예측 | M2 기존 PT 예측 |
|---|---|---|
| ![원본](examples/D180/original/D180.png) | ![M1](examples/D180/predictions/M1/D180.jpg) | ![M2](examples/D180/predictions/M2/D180_pred.jpg) |

정답: [M1 TXT](examples/D180/labels/M1/D180.txt) · [M2 TXT](examples/D180/labels/M2/D180.txt)

## D187 — MISSING_EXHAUST_TOP

배기 부품 결품; 다른 부품은 존재

| 원본 | M1 기존 PT 예측 | M2 기존 PT 예측 |
|---|---|---|
| ![원본](examples/D187/original/D187.png) | ![M1](examples/D187/predictions/M1/D187.jpg) | ![M2](examples/D187/predictions/M2/D187_pred.jpg) |

정답: [M1 TXT](examples/D187/labels/M1/D187.txt) · [M2 TXT](examples/D187/labels/M2/D187.txt)

## D201 — MISSING_SYMBOL_MODULE

문양 부품 결품; 다른 부품은 존재

| 원본 | M1 기존 PT 예측 | M2 기존 PT 예측 |
|---|---|---|
| ![원본](examples/D201/original/D201.png) | ![M1](examples/D201/predictions/M1/D201.jpg) | ![M2](examples/D201/predictions/M2/D201_pred.jpg) |

정답: [M1 TXT](examples/D201/labels/M1/D201.txt) · [M2 TXT](examples/D201/labels/M2/D201.txt)

## D205 — MISSING_ALL_TARGETS

전체 대상 부품 결품; M1 빈 라벨·빈 예측이나 M2 엔진 존재

| 원본 | M1 기존 PT 예측 | M2 기존 PT 예측 |
|---|---|---|
| ![원본](examples/D205/original/D205.png) | ![M1](examples/D205/predictions/M1/D205.jpg) | ![M2](examples/D205/predictions/M2/D205_pred.jpg) |

정답: [M1 TXT](examples/D205/labels/M1/D205.txt) · [M2 TXT](examples/D205/labels/M2/D205.txt)

## D215 — MISSING_ALL_TARGETS

전체 대상 부품 결품; 다른 구도에서도 빈 벨트와 구분

| 원본 | M1 기존 PT 예측 | M2 기존 PT 예측 |
|---|---|---|
| ![원본](examples/D215/original/D215.png) | ![M1](examples/D215/predictions/M1/D215.jpg) | ![M2](examples/D215/predictions/M2/D215_pred.jpg) |

정답: [M1 TXT](examples/D215/labels/M1/D215.txt) · [M2 TXT](examples/D215/labels/M2/D215.txt)
