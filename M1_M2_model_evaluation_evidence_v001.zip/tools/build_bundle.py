"""기존 증빙만 복사/집계한다. 학습·평가·추론 모듈을 import하거나 실행하지 않는다."""
from pathlib import Path
import csv
import hashlib
import json
import re
import shutil
from datetime import datetime, timezone

ROOT = Path('D:/OneDevice_Team_project')
BASE = ROOT/'docs/evaluation_assets/20261019'
WORK = Path(__file__).resolve().parent
W = Path('D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001')
P = W/'outputs/run_20260921T082749Z_709634'
D = ROOT/'runs/engine_dynamic_pose_002'
I = ROOT/'runs/engine_package_integration_001'
OBS = ROOT/'runs/evaluation_asset_inventory_20261019'

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            value.update(block)
    return value.hexdigest()

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')

def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

version = 1
while (BASE/f'M1_M2_model_evaluation_evidence_v{version:03d}').exists() or (BASE/f'M1_M2_model_evaluation_evidence_v{version:03d}.zip').exists():
    version += 1
B = BASE/f'M1_M2_model_evaluation_evidence_v{version:03d}'
B.mkdir()
registry = {}

def copy(src, relative, purpose):
    src = Path(src)
    assert src.is_file(), src
    assert not any(x.upper() in ('E04','B04') for x in src.parts), src
    assert src.suffix.lower() not in ('.pt','.onnx','.plan','.engine','.sqlite3','.db','.zip','.tar','.gz'), src
    dest = B/relative
    assert relative not in registry and not dest.exists(), dest
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
    assert sha(src) == sha(dest)
    registry[relative] = {'original_path':str(src), 'kind':'unchanged_copy', 'purpose':purpose}
    return relative

for model, run, train, val, metrics, code, log in [
    ('M1',P,P/'training/engine_parts',P/'validation',P/'validation_metrics.json',W/'train_engine_parts.py',P/'training_console_utf8.log'),
    ('M2',D,D/'training/envelope_v004',D/'validation/e03',D/'training_result.json',D/'train_envelope.py',D/'train_console_v004.log')]:
    copy(train/'args.yaml',f'{model}/training/args.yaml','학습 설정 원문')
    copy(train/'results.csv',f'{model}/training/results.csv','전체 epoch CSV')
    copy(metrics,f'{model}/{metrics.name}','별도 PT 개발 검증 지표')
    copy(code,f'{model}/execution/{code.name}','학습·별도 검증·예측 생성 호출 근거; 실행하지 않음')
    copy(log,f'{model}/execution/{log.name}','당시 실행 로그 전체')
    dataset = P/'dataset' if model=='M1' else D/'dataset_v004'
    copy(dataset/'data.yaml',f'{model}/dataset/data.yaml','학습 당시 절대경로를 보존한 원문')
    for folder, phase in [(train,'training'),(val,'validation')]:
        for image in sorted(folder.iterdir()):
            if image.is_file() and image.suffix.lower() in ('.png','.jpg','.jpeg') and not re.fullmatch(r'D\d+_pred',image.stem):
                copy(image,f'{model}/{phase}/{image.name}','기존 학습/검증 그림; 새 평가 없음')

for name in ['environment.json','model_manifest.json','approval.json','approval_provenance.json','RESULT_KO.md','status.json']:
    copy(P/name,f'M1/provenance/{name}','학습 run 및 가중치·승인 연결')
for name in ['prediction_diagnostics.json','visual_review.json','artifact_verification.json']:
    copy(P/'review_after_training'/name,f'M1/review/{name}','기존 예측 대조/오류 검토 기록')
copy(P/'val_predictions.jsonl','M1/predictions/val_predictions.jsonl','기존 PT 예측 좌표·점수 72건 전체')
copy(D/'envelope_predictions_e03.json','M2/predictions/envelope_predictions_e03.json','기존 PT 예측 좌표·점수 72건 전체')
copy(P/'dataset/lineage.json','M1/dataset/lineage.json','E01-E03 원본/분할 연결')
copy(W/'source_index.json','shared/source_index.json','E01-E03 촬영 상태/출처; E04 이미지·정답 제외')
copy(D/'dataset_pose_audit_v004.json','M2/dataset/dataset_pose_audit_v004.json','M2 AI 검토 라벨·같은 원본 연결')
copy(D/'final_provenance_verification.json','shared/final_provenance_verification.json','기존 운영 패키지 출처 검증')

for model, pkg, build in [('M1','dynamic_parts_005','parts_fp16_head32_v001'),('M2','envelope_v007_fp16','envelope_fp16_backbone32_v007')]:
    for name in ['manifest.json','preprocessing.json','classes.json']:
        src=ROOT/f'jetson/products/ENGINE_Z3005_5/{pkg}/{name}'
        if src.is_file():copy(src,f'{model}/deployment/{name}','현재 운영 제품 패키지 원문')
    copy(D/build/'build_manifest.json',f'{model}/conversion/build_manifest.json','TensorRT 빌드 환경/ONNX·PLAN 해시 원문')
    copy(D/build/'parser.log',f'{model}/conversion/parser.log','기존 TensorRT parser 로그')
copy(I/'controlled_export.json','M1/conversion/controlled_export.json','M1 PT→ONNX export 원문')
copy(I/'export_console.log','M1/conversion/export_console.log','기존 M1 export 로그')
copy(I/'export_controlled.py','M1/conversion/export_controlled.py','기존 export 호출 코드; 실행하지 않음')
copy(D/'envelope_export.json','M2/conversion/envelope_export.json','M2 v004 PT/ONNX export 원문')
copy(D/'export_envelope.py','M2/conversion/export_envelope.py','M2 v004 export 경로·호출 코드')
copy(D/'export_console_v002.log','M2/conversion/export_console_v002.log','기존 export 로그; 경로/해시를 별도 원문과 대조')
copy(D/'parts_parity_v001.json','M1/parity/parts_parity_v001.json','현재 M1 PLAN의 기존 E03 72건 parity와 latency')
copy(D/'check_parts_jetson.py','M1/parity/check_parts_jetson.py','parity 실행 코드 원문; 옛 Jetson 경로 유지')
for name in ['pt_reference.json','parity_check.py','jetson_package_check.py','threshold_policy.json','protection_checkpoint.json']:
    copy(I/name,f'M1/parity/reference/{name}','보존된 PT reference 및 동일 목적의 전처리/비교 근거')
copy(I/'parity_pt_training/results.json','M1/parity/reference/pt_training_results.json','PT reference 저장 출력')
for name in ['tensorrt_preprocess.py','tensorrt_postprocess.py']:
    copy(I/'candidate_runtime/src/vision'/name,f'M1/parity/reference/{name}','보존된 parity 전처리/후처리 코드')
copy(OBS/'remote_model_detail.json','runtime/remote_model_detail.json','2026-10-19 기존 Jetson 모델 실제 해시 관측 원문')
copy(ROOT/'notebook/deployment/RELEASE_MANIFEST.json','runtime/RELEASE_MANIFEST.json','로컬 32c4 release manifest 원문')
# 전체 DB·검사 목록을 담지 않도록 기존 관측 JSON의 release 부분만 명시적 발췌한다.
remote_source=OBS/'remote_inventory.json'
remote=read_json(remote_source)
write_json(B/'runtime/remote_release_observation_excerpt.json',{
    'kind':'EXCERPT_NOT_ORIGINAL_FILE','source_path':str(remote_source),'source_sha256':sha(remote_source),
    'json_pointers':['/observed_at','/host','/root','/release.json'],
    **{k:remote[k] for k in ['observed_at','host','root','release.json']}})
copy(BASE/'asset_inventory.json','basis/asset_inventory.json','출발 인벤토리 원문; 성능 자료와 구분')
copy(BASE/'INVENTORY_KO.md','basis/INVENTORY_KO.md','기존 인벤토리 해석 범위')
previous=ROOT/'runs/dataset_explanation_bundle_20261019/deliverables/M1_M2_dataset_evidence_v001'
copy(previous/'bundle_manifest.json','basis/dataset_evidence_bundle_manifest.json','직전 데이터셋 묶음 연결; 모델/분할 유지')

for src in [ROOT/'runs/engine_misassembly_baseline_training_001/v001_20261002T191929Z/training_metrics.json',ROOT/'runs/engine_preprocessing_recovery_001/v001_20261003T033452Z/before_after_metrics.json']:
    copy(src,f'appendix_reference_only/{src.name}','M3-M6 참고 전용 원문; 처리 성공/제외 분모 보존')

source_rows=read_json(W/'source_index.json')['rows']
assert len(source_rows)==216 and all(x['round_id'] in ('E01','E02','E03') and not x['test_reserved'] for x in source_rows)
index={x['review_id']:x for x in source_rows}
m1pred={Path(x['image']).stem:x for x in map(json.loads,(P/'val_predictions.jsonl').read_text(encoding='utf-8').splitlines())}
m2pred={x['id']:x for x in read_json(D/'envelope_predictions_e03.json')}
assert len(m1pred)==len(m2pred)==72 and set(m1pred)==set(m2pred)=={f'D{i:03d}' for i in range(145,217)}
choices={
    'D145':'정상 기본 사례; 두 파이프·배기·문양 및 M2 전체 박스',
    'D151':'정상; 기존 검토에서 배기 confidence 최저 0.6512 사례',
    'D156':'정상; 기존 검토의 배기 박스 경계 차이 IoU 0.6372',
    'D159':'왼쪽 파이프 결품; 남은 파이프와 다른 클래스 비교',
    'D172':'오른쪽 파이프 결품; 기존 검토의 배기/파이프 박스 위치 차이',
    'D180':'오른쪽 파이프 결품; 다른 목표 회전 구도의 설명용 사례',
    'D187':'배기 부품 결품; 다른 부품은 존재',
    'D201':'문양 부품 결품; 다른 부품은 존재',
    'D205':'전체 대상 부품 결품; M1 빈 라벨·빈 예측이나 M2 엔진 존재',
    'D215':'전체 대상 부품 결품; 다른 구도에서도 빈 벨트와 구분'}
examples=[]
for rid,reason in choices.items():
    truth=index[rid]
    assert truth['split']=='val' and truth['round_id']=='E03'
    a=P/f'dataset/images/val/{rid}.png';b=D/f'dataset_v004/images/val/{rid}.png'
    assert sha(a)==sha(b)==truth['image_sha256']
    original=copy(a,f'examples/{rid}/original/{rid}.png','선정 E03 원본; M1/M2 동일 SHA')
    l1=copy(P/f'dataset/labels/val/{rid}.txt',f'examples/{rid}/labels/M1/{rid}.txt','M1 실제 정답 YOLO TXT')
    l2=copy(D/f'dataset_v004/labels/val/{rid}.txt',f'examples/{rid}/labels/M2/{rid}.txt','M2 실제 정답 YOLO TXT')
    p1=copy(P/f'val_predictions/{rid}.jpg',f'examples/{rid}/predictions/M1/{rid}.jpg','기존 M1 PT 표시 예측')
    p2=copy(D/f'validation/e03/{rid}_pred.jpg',f'examples/{rid}/predictions/M2/{rid}_pred.jpg','기존 M2 PT 표시 예측')
    examples.append({'image_id':rid,'split':'val','round_id':'E03','capture_id':truth['capture_id'],
        'capture_state':truth['scenario_capture_truth'],'origin_group_id':truth['origin_group_id'],
        'original_bundle_path':original,'original_source_path':str(a),'M2_original_source_path':str(b),
        'image_sha256':truth['image_sha256'],'M1_gt_bundle_path':l1,'M2_gt_bundle_path':l2,
        'M1_gt_source_path':str(P/f'dataset/labels/val/{rid}.txt'),'M2_gt_source_path':str(D/f'dataset_v004/labels/val/{rid}.txt'),
        'M1_prediction_bundle_path':p1,'M2_prediction_bundle_path':p2,
        'M1_prediction_source_path':str(P/f'val_predictions/{rid}.jpg'),'M2_prediction_source_path':str(D/f'validation/e03/{rid}_pred.jpg'),
        'M1_coordinates_bundle_path':'M1/predictions/val_predictions.jsonl','M1_coordinates_record_key':f'image={rid}.png',
        'M2_coordinates_bundle_path':'M2/predictions/envelope_predictions_e03.json','M2_coordinates_record_key':f'id={rid}',
        'M1_run':str(P),'M2_run':str(D/'training/envelope_v004'),
        'M1_weight_link':'train_engine_parts.py best.pt reload + model_manifest SHA + actual PT hash',
        'M2_weight_link':'train_envelope.py best.pt reload + training_result best path + export PT SHA + actual PT hash',
        'selection_reason':reason,'scope':'EXPLANATION_ONLY_E03_PT_PREDICTIONS_NOT_NEW_EVALUATION'})
write_csv(B/'examples.csv',examples)

# 바이너리는 복사하지 않고, 기록에 선언된 연결과 현재 보관 파일의 SHA를 대조한다.
chain=[]
hashes=[]
remote_models={x['path']:x for x in read_json(OBS/'remote_model_detail.json')['models']}
for model,pkg,build,pt,onnx,export in [
 ('M1','dynamic_parts_005','parts_fp16_head32_v001',P/'models/engine_parts_best.pt',D/'engine_parts.onnx',I/'controlled_export.json'),
 ('M2','envelope_v007_fp16','envelope_fp16_backbone32_v007',D/'training/envelope_v004/weights/best.pt',D/'envelope_export_v004/envelope_best.onnx',D/'envelope_export.json')]:
    manifest=read_json(ROOT/f'jetson/products/ENGINE_Z3005_5/{pkg}/manifest.json')
    build_record=read_json(D/build/'build_manifest.json'); exp=read_json(export)
    pt_hash=sha(pt);onnx_hash=sha(onnx);plan=ROOT/f'jetson/products/ENGINE_Z3005_5/{pkg}/model.plan';plan_hash=sha(plan)
    export_pt=exp['source_pt_sha256'] if model=='M1' else exp['pt_sha256']
    export_onnx=exp['onnx']['sha256'] if model=='M1' else exp['source_onnx']['sha256']
    for kind,path,digest in [('PT',pt,pt_hash),('ONNX',onnx,onnx_hash),('TRT',plan,plan_hash)]:
        hashes.append({'model':model,'kind':kind,'original_path':str(path),'bytes':path.stat().st_size,'sha256':digest,'included_binary':False})
    remote_path=f'/home/jetson/oned_device_bench/assets/products/ENGINE_Z3005_5/{pkg}/model.plan'
    edges={
      'PT_to_export':pt_hash==export_pt,
      'ONNX_to_export':onnx_hash==export_onnx,
      'ONNX_to_build':onnx_hash==build_record['onnx_sha256'],
      'build_to_PLAN':plan_hash==build_record['plan_sha256'],
      'PLAN_to_package':plan_hash==manifest['files']['model']['sha256'],
      'PT_to_package':pt_hash==manifest['detector']['source_model_sha256']==manifest['training_provenance']['model_sha256'],
      'ONNX_to_package':onnx_hash==manifest['detector']['provenance']['source_onnx']['sha256'],
      'PLAN_to_release':plan_hash==remote['release.json']['files'][f'assets/products/ENGINE_Z3005_5/{pkg}/model.plan'],
      'PLAN_to_observed_Jetson':plan_hash==remote_models[remote_path]['sha256'],
      'manifest_to_release':sha(ROOT/f'jetson/products/ENGINE_Z3005_5/{pkg}/manifest.json')==remote['release.json']['files'][f'assets/products/ENGINE_Z3005_5/{pkg}/manifest.json']}
    if model=='M2':edges['export_staged_PT_to_training_PT']=sha(D/'envelope_export_v004/envelope_best.pt')==pt_hash
    else:edges['training_best_to_model_copy']=sha(P/'training/engine_parts/weights/best.pt')==pt_hash
    assert all(edges.values()),edges
    chain.append({'model':model,'package':pkg,'model_version':manifest['model_version'],'pt_sha256':pt_hash,
        'onnx_sha256':onnx_hash,'plan_sha256':plan_hash,'edges':edges,'remote_path':remote_path,
        'remote_observed_at':remote['observed_at'],'observed_release':remote['release.json']['release_id']})
write_json(B/'verification/model_hash_chain.json',{'scope':'READ_EXISTING_BYTES_AND_RECORDS_ONLY','models':chain,'binary_files':hashes})

parity=read_json(D/'parts_parity_v001.json');reference=read_json(I/'pt_reference.json')
ref_result=read_json(I/'parity_pt_training/results.json')
assert reference==ref_result
assert {r['id'] for r in parity['rows']}==set(m1pred)
inputs=[]
for row in reference['rows']:
    path=P/f'dataset/images/val/{row["id"]}.png'
    h=sha(path);assert h==row['image_sha256']==index[row['id']]['image_sha256']
    inputs.append({'image_id':row['id'],'source_path':str(path),'sha256':h,'reference_sha_match':True})
write_csv(B/'verification/parity_input_hashes.csv',inputs)
pairs=[p for row in parity['rows'] for p in row['parity']['pairs']]
assert len(parity['rows'])==parity['count']==parity['pass_count']==72
assert all(row['parity']['pass'] for row in parity['rows'])
close=parity['close'];m1=chain[0]
assert close['artifact_sha256']==close['observed_runtime']['engine_sha256']==m1['plan_sha256']
assert close['source_model_sha256']==m1['pt_sha256'] and close['source_onnx_sha256']==m1['onnx_sha256']
write_json(B/'verification/parity_record_audit.json',{
    'scope':'AUDIT_OF_EXISTING_RECORDS_NOT_NEW_PARITY','count':72,'recorded_pass_count':72,'pairs':len(pairs),
    'stored_min_bbox_iou':min(p['bbox_iou'] for p in pairs),'stored_max_confidence_abs_diff':max(p['confidence_abs_diff'] for p in pairs),
    'stored_max_coordinate_abs_diff_px':max(p['max_coordinate_abs_diff_px'] for p in pairs),
    'all_input_sha_match':True,'reference_copy_equals_training_results':True,'model_hashes_match':True,
    'preserved_reference_policy':read_json(I/'threshold_policy.json'),
    'comparison_code_conditions':{'class_and_count_match':True,'bbox_iou_min':0.98,'confidence_abs_diff_max':0.02,'coordinate_diff_gate':None},
    'limitation':'check_parts_jetson.py refers to old remote engine_parts_pkg_candidate_001_20260922. Local counterpart code/reference found in engine_package_integration_001, but the imported helper and PT reference file SHA were not embedded in parts_parity_v001.json. Current copied code/hash is not proof of the exact historical imported bytes.',
    'latency':{k:parity[k] for k in ['cold_first_ms','warm_p50_ms','warm_p95_ms','scope']}})

summaries=[]
for model,run in [('M1',P/'training/engine_parts'),('M2',D/'training/envelope_v004')]:
    with (run/'results.csv').open(encoding='utf-8-sig',newline='') as f:
        rows=[{k.strip():v.strip() for k,v in row.items()} for row in csv.DictReader(f)]
    top=max(rows,key=lambda r:float(r['metrics/mAP50-95(B)']))
    metrics=read_json(P/'validation_metrics.json' if model=='M1' else D/'training_result.json')['metrics']
    summaries.append({'model':model,'max_epochs':100,'actual_epochs':len(rows),'last_csv_epoch':int(rows[-1]['epoch']),
        'best_pt_epoch':None if model=='M1' else 37,
        'best_epoch_basis':'UNCONFIRMED; CSV maximum is not checkpoint selection proof' if model=='M1' else 'EarlyStopping log explicitly says best epoch 37',
        'csv_map5095_max_epoch':int(top['epoch']),'csv_map5095_max_value':float(top['metrics/mAP50-95(B)']),
        'csv_last_time_seconds':float(rows[-1]['time']),'metrics':metrics})
write_json(B/'tables/training_summary.json',summaries)

figure_rows=[]
for rel,entry in registry.items():
    if Path(rel).suffix.lower() in ('.png','.jpg','.jpeg') and rel.split('/')[0] in ('M1','M2'):
        phase=rel.split('/')[1]
        figure_rows.append({'model':rel.split('/')[0],'phase':phase,'bundle_path':rel,'source_path':entry['original_path'],
            'scope':'E01/E02 training batch' if Path(rel).name.startswith('train_batch') else 'training epoch history' if Path(rel).name=='results.png' else 'label distribution' if Path(rel).name=='labels.jpg' else 'E03 development PT validation',
            'weight_binding':'training process; not one checkpoint' if phase=='training' else 'best.pt explicit reload + standalone val call and log; no per-image embedded checkpoint SHA',
            'mosaic_id_link':'not used for example ID assignment; individual ID prediction files used instead' if 'val_batch' in rel else ''})
write_csv(B/'tables/figures.csv',figure_rows)

ref_rows=[]
for filename in ['training_metrics.json','before_after_metrics.json']:
    value=read_json(B/f'appendix_reference_only/{filename}')
    for part,v in value['parts'].items():
        ref_rows.append({'source_file':filename,'part':part,'candidates':v['candidate_count'],'processed':v['predicted_count'],
            'excluded':v['candidate_count']-v['predicted_count'],'accuracy_on_processed':v['accuracy'],'macro_f1_on_processed':v['macro_f1'],
            'scope':'reference_only_development_not_final_test'})
# 두 원문 외 참고용 파일은 별도 생성하지 않고 README 작성 자료만 작업 폴더에 보존한다.
write_json(WORK/'reference_summary.json',ref_rows)

searches=[
 {'item':'M1 best.pt 선택 epoch','searched':[str(P/'training/engine_parts/results.csv'),str(P/'training_console_utf8.log'),str(P/'model_manifest.json'),str(P/'RESULT_KO.md')],'result':'기존 자료 미확인; CSV mAP50-95 최고 epoch96만 확인. PT를 로드해 추정하지 않음'},
 {'item':'M1/M2 수치형 원본 혼동행렬','searched':[str(P/'training/engine_parts'),str(P/'validation'),str(P/'validation_metrics.json'),str(D/'training/envelope_v004'),str(D/'validation/e03'),str(D/'training_result.json')],'result':'기존 자료 미확인; PNG는 있음. M1 기존 TP/FP/FN 진단은 별도 조건이며 framework 혼동행렬 대체 불가'},
 {'item':'별도 framework val의 최종 effective conf/NMS/GT matching 전체 설정','searched':[str(W/'train_engine_parts.py'),str(D/'train_envelope.py'),str(P/'training_console_utf8.log'),str(D/'train_console_v004.log'),str(P/'training/engine_parts/args.yaml'),str(D/'training/envelope_v004/args.yaml')],'result':'호출 코드·버전·train args 확보. 별도 val에서 conf/iou 미지정 및 effective args snapshot 없음; 운영 threshold로 보충하지 않음'},
 {'item':'M1 72/72 parity 당시 import helper/PT reference 파일 SHA','searched':[str(D/'parts_parity_v001.json'),str(D/'check_parts_jetson.py'),str(ROOT/'runs/engine_parts_pkg_candidate_001_20260922'),str(I/'jetson_package_check.py'),str(I/'pt_reference.json'),str(D/'parts_build_inputs.tar.gz'),str(D/'runtime_tests_v001.tar.gz')],'result':'모델 SHA·72 ID·입력 SHA·reference 코드/정책 확보. 옛 remote path의 exact helper/ref 파일 해시 영수증은 기존 자료 미확인'},
 {'item':'M2 정답 매칭 FP/FN·위치 오류의 개별 사례 목록','searched':[str(D/'training_result.json'),str(D/'envelope_predictions_e03.json'),str(D/'validation/e03'),str(D/'detector_replay_e03_v004.json')],'result':'저장된 예측·그림 확보. 별도 객체 검출 FP/FN 목록은 기존 자료 미확인; P/R에서 역산하거나 새 매칭 평가하지 않음'},
 {'item':'현재 TensorRT의 독립 최종시험 mAP','searched':[str(BASE/'asset_inventory.json'),str(D/'parts_parity_v001.json'),str(D/'training_result.json')],'result':'기존 자료 미확인; PT E03 지표와 수치 parity는 독립 final-test mAP가 아님. 보호 E04/B04 열람 없음'}]
write_json(B/'verification/missing_evidence_search.json',searches)
write_json(WORK/'state.json',{'bundle_path':str(B),'registry':registry,'summaries':summaries,'examples':examples,'figures_count':len(figure_rows),'hash_chain':chain,'missing':searches})
print(json.dumps({'bundle':str(B),'copied_files':len(registry),'example_ids':len(examples),'figures':len(figure_rows),'hash_chain':'ALL_MATCH'},ensure_ascii=False))
