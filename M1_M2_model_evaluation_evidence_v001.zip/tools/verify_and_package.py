"""원본 동일성·CSV 연결·기존 기록 집계·ZIP을 독립 검증. 새 모델 실행 없음."""
from pathlib import Path, PurePosixPath
from collections import Counter
from datetime import datetime, timezone
import csv
import hashlib
import json
import re
import shutil
import zipfile
from PIL import Image

WORK=Path(__file__).resolve().parent
state=json.loads((WORK/'state.json').read_text(encoding='utf-8'))
B=Path(state['bundle_path'])

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()

def read(relative):return json.loads((B/relative).read_text(encoding='utf-8-sig'))
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def csv_rows(relative):
    with (B/relative).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

# 이번 자료 생성 코드도 증빙에 포함한다. 여기서 생성 코드를 다시 실행하지 않는다.
for name in ['build_bundle.py','write_documents.py','verify_and_package.py']:
    relative=f'tools/{name}';dest=B/relative;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(WORK/name,dest)
    state['registry'][relative]={'original_path':str(WORK/name),'kind':'task_tool_source','purpose':'이 자료 작성에 실행한 코드; 운영 프로그램 아님'}

copy_checks=[]
for relative,entry in state['registry'].items():
    src=Path(entry['original_path']);dest=B/relative
    source_sha=digest(src);dest_sha=digest(dest)
    assert source_sha==dest_sha,(relative,'COPY_HASH_MISMATCH')
    copy_checks.append({'relative_path':relative,'original_path':str(src),'size_bytes':dest.stat().st_size,'sha256':dest_sha,'source_sha256':source_sha,'match':True})

refs_checked=0
for filename in ['examples.csv','tables/figures.csv','tables/validation_metrics.csv','tables/historical_log_excerpts.csv','verification/parity_input_hashes.csv']:
    for row in csv_rows(filename):
        for key,value in row.items():
            if key.endswith('bundle_path') and value:
                assert not Path(value).is_absolute() and '..' not in PurePosixPath(value).parts
                assert (B/value).is_file(),(filename,key,value)
                refs_checked+=1
            if key.endswith('source_path') and value:
                assert Path(value).is_file(),(filename,key,value)

examples=csv_rows('examples.csv');index={r['review_id']:r for r in read('shared/source_index.json')['rows']}
assert len(examples)==10 and len({r['image_id'] for r in examples})==10
assert {r['capture_state'] for r in examples}=={'NORMAL','MISSING_PIPE_LEFT','MISSING_PIPE_RIGHT','MISSING_EXHAUST_TOP','MISSING_SYMBOL_MODULE','MISSING_ALL_TARGETS'}
pred1={Path(r['image']).stem:r for r in map(json.loads,(B/'M1/predictions/val_predictions.jsonl').read_text(encoding='utf-8').splitlines())}
pred2={r['id']:r for r in read('M2/predictions/envelope_predictions_e03.json')}
names=['gray_pipe','exhaust_top','symbol_module']
for row in examples:
    rid=row['image_id'];truth=index[rid]
    assert truth['round_id']=='E03' and truth['split']=='val' and not truth['test_reserved']
    assert digest(B/row['original_bundle_path'])==row['image_sha256']==truth['image_sha256']
    assert digest(Path(row['M2_original_source_path']))==row['image_sha256']
    assert rid in pred1 and rid in pred2
    observed=Counter()
    for line in (B/row['M1_gt_bundle_path']).read_text(encoding='utf-8').splitlines():
        cls,*coords=map(float,line.split());assert cls.is_integer() and int(cls) in range(3)
        assert len(coords)==4 and all(0<=v<=1 for v in coords) and coords[2]>0 and coords[3]>0
        observed[names[int(cls)]]+=1
    assert observed==Counter(truth['expected_counts']),(rid,observed,truth['expected_counts'])
    second=(B/row['M2_gt_bundle_path']).read_text(encoding='utf-8').splitlines()
    assert len(second)==1 and second[0].split()[0]=='0'

# 새 매칭을 수행하지 않고 기존 TP/FP/FN 기록과 요약 수치를 대조한다.
diag=read('M1/review/prediction_diagnostics.json')
assert sum(x['tp'] for x in diag['counts'].values())==192
assert sum(x['fp']+x['fn'] for x in diag['counts'].values())==0
parity=read('M1/parity/parts_parity_v001.json')
assert sum(bool(r['parity']['pass']) for r in parity['rows'])==parity['pass_count']==72
chain=read('verification/model_hash_chain.json')
assert all(all(m['edges'].values()) for m in chain['models'])
remote=read('runtime/remote_release_observation_excerpt.json')
local=read('runtime/RELEASE_MANIFEST.json')
assert remote['release.json']['release_id']==local['release_id']=='engine-integrated-32c484ac6aeb07f1'
assert digest(Path(remote['source_path']))==remote['source_sha256']
remote_original=json.loads(Path(remote['source_path']).read_text(encoding='utf-8'))
assert remote_original['release.json']==remote['release.json']
assert remote_original['host']==remote['host'] and remote_original['observed_at']==remote['observed_at']
for m in chain['models']:
    for name in ['model.plan','manifest.json','preprocessing.json']:
        key=f'assets/products/ENGINE_Z3005_5/{m["package"]}/{name}'
        assert local['files'][key]==remote['release.json']['files'][key]
        if name!='model.plan':assert digest(B/f'{m["model"]}/deployment/{name}')==local['files'][key]

summary=read('tables/training_summary.json')
for model,n in [('M1',100),('M2',57)]:
    rows=csv_rows(f'{model}/training/results.csv')
    cleaned=[{k.strip():v.strip() for k,v in r.items()} for r in rows]
    assert len(cleaned)==n and [int(r['epoch']) for r in cleaned]==list(range(1,n+1))
    highest=max(float(r['metrics/mAP50-95(B)']) for r in cleaned)
    epochs=[int(r['epoch']) for r in cleaned if float(r['metrics/mAP50-95(B)'])==highest]
    s=next(x for x in summary if x['model']==model)
    assert s['csv_map5095_max_epoch'] in epochs and s['csv_map5095_max_value']==highest

image_count=0
for path in B.rglob('*'):
    if not path.is_file():continue
    assert path.suffix.lower() not in ('.pt','.onnx','.plan','.engine','.sqlite','.sqlite3','.db','.npz','.zip','.gz')
    assert not any(x.upper() in ('E04','B04') for x in path.relative_to(B).parts)
    if path.suffix.lower() in ('.jpg','.jpeg','.png'):
        with Image.open(path) as image:image.verify()
        image_count+=1
    if path.suffix.lower() in ('.jpg','.jpeg','.png','.txt'):
        match=re.match(r'(D\d{3})(?:_|\.)',path.name)
        if match:assert 145<=int(match.group(1)[1:])<=216

checks={'status':'PASS','scope':'EXISTING_EVIDENCE_ONLY_NO_MODEL_EXECUTION','copied_source_hashes_checked':len(copy_checks),
        'example_unique_ids':10,'example_states':dict(Counter(r['capture_state'] for r in examples)),
        'csv_bundle_references_checked':refs_checked,'image_files_verified':image_count,'chart_files':len(csv_rows('tables/figures.csv')),
        'protected_image_or_label_files_included':0,'model_binaries_or_database_included':0,
        'parity_source_input_hash_rows':len(csv_rows('verification/parity_input_hashes.csv')),
        'local_release_and_remote_observation_model_file_hashes_match':True,
        'original_files_modified':False,'checks':copy_checks}
save(B/'verification/bundle_checks.json',checks)
state['generated_sources']['verification/bundle_checks.json']=['examples.csv','verification/model_hash_chain.json','tables/figures.csv','M1/review/prediction_diagnostics.json']

entries=[]
for path in sorted(B.rglob('*')):
    if not path.is_file() or path.name=='bundle_manifest.json':continue
    relative=path.relative_to(B).as_posix();entry=state['registry'].get(relative)
    if entry is None:
        assert relative in state['generated_sources'],('UNREGISTERED_GENERATED_FILE',relative)
        entry={'original_path':None,'kind':'generated_from_existing_evidence','derived_from':state['generated_sources'][relative]}
    entries.append({'relative_path':relative,'size_bytes':path.stat().st_size,'sha256':digest(path),**entry})
manifest={'bundle_name':B.name,'created_utc':datetime.now(timezone.utc).isoformat(),'scope':'COPY_AND_SUMMARIZE_EXISTING_EVIDENCE_ONLY',
    'self_exclusion':'This manifest alone is excluded from its own file list. Its SHA is in the external ZIP verification receipt.',
    'source_original_path_null_means':'New report/table/verification derived from linked existing evidence, not an original source file.',
    'file_count_excluding_manifest':len(entries),'files':entries}
save(B/'bundle_manifest.json',manifest)

# MD 상대 링크도 최종 파일 집합에 대해 검사한다.
for path in [B/'README_KO.md',B/'EXAMPLES_KO.md']:
    for link in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
        assert (B/link).exists(),(path.name,link)
archive=B.with_suffix('.zip')
assert not archive.exists(),archive
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
    for path in sorted(B.rglob('*')):
        if path.is_file():z.write(path,path.relative_to(B).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    expected={p.relative_to(B).as_posix() for p in B.rglob('*') if p.is_file()}
    assert set(z.namelist())==expected and len(z.namelist())==len(expected)
    for name in z.namelist():assert hashlib.sha256(z.read(name)).hexdigest()==digest(B/name)
    zipped_manifest=json.loads(z.read('bundle_manifest.json'))
    assert len(zipped_manifest['files'])+1==len(z.namelist())
    for e in zipped_manifest['files']:
        assert hashlib.sha256(z.read(e['relative_path'])).hexdigest()==e['sha256']
    file_count=len(z.namelist())
receipt={'status':'PASS','zip_path':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive),
    'zip_file_count':file_count,'bundle_path':str(B),'readme_path':str(B/'README_KO.md'),
    'manifest_sha256':digest(B/'bundle_manifest.json'),'CRC':'PASS','zip_folder_file_set_and_sha':'ALL_MATCH',
    'copied_original_hash_checks':len(copy_checks),'example_ids':10,'figures':len(csv_rows('tables/figures.csv')),
    'verification_time_utc':datetime.now(timezone.utc).isoformat()}
save(B.parent/f'{B.name}_verification.json',receipt)
print(json.dumps(receipt,ensure_ascii=False))
