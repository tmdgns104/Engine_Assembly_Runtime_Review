# 엔진 부품 3종 GPU 학습 결과

2026-09-21 / 실행 ID: `run_20260921T082749Z_709634`

## 결과와 범위

기존 `train_engine_parts.py`로 Windows RTX 5070 Laptop GPU에서 100/100 epoch 학습과 E03 개발 검증을 완료했다. `status.json`은 `TRAINING_AND_VAL_COMPLETE`다. 조기 종료, OOM, batch 변경, 재시도, 추가 튜닝은 없었다.

학습 CSV의 마지막 시간은 650.589초이며 콘솔은 0.181시간을 보고했다. 초기 준비·최종 검증·결과 정리를 모두 포함한 작업 시간은 아니다.

**확인 한계:** 마지막 실행 도구 출력이 길이 제한으로 보존되지 않아 학습 프로세스의 OS 종료 코드 숫자는 재확인하지 못했다. 100개 epoch 행, 정상 완료 상태, 최종 ZIP 출력, 두 모델 재로딩, E03 예측 72장 및 ZIP CRC를 교차 확인했다. 종료 코드를 임의로 0으로 기록하지 않았다. 후속 산출물 검증 명령은 exit 0이다.

이 결과는 개발용 부품검출 모델이다. 엔진 전체 판정, Whole-Product Observation, Tracking, 실시간 운전 및 생산 수용 결과가 아니다. E04는 열람·추출·학습·추론·평가하지 않았다. Jetson 배포와 이어폰 패키지 교체도 하지 않았다.

## 사용 환경과 설정

- Python: `D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_training_kit_v001/.venv/Scripts/python.exe`
- Python 3.13.5 / torch 2.10.0+cu128 / ultralytics 8.3.253
- 실제 장치: NVIDIA GeForce RTX 5070 Laptop GPU, CUDA:0, 로그 기준 8151 MiB
- 초기 가중치: `D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_training_kit_v001/models/yolo11n.pt`
- 원본 ZIP: `D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/CFA8507BBBF384292.zip`
- epochs 100 / imgsz 640 / batch 8 / workers 0 / seed 42 / amp false / patience 20
- 기존 스크립트의 회전·반전·mosaic 설정을 그대로 사용했다. 전체 설정은 `review_after_training/training_args.yaml`에 보존했다.
- 패키지 설치·업데이트, 가상환경 재생성, CPU 전환 없음.

실제 실행 인수:

```text
<위 Python> -X utf8 -B train_engine_parts.py --source-zip D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/CFA8507BBBF384292.zip --weights D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_training_kit_v001/models/yolo11n.pt --epochs 100 --imgsz 640 --batch 8
```

## 라벨 승인과 분할

사용자 확인: **“216장 전체 확인 완료, 학습 승인”**. 이 확인을 받은 뒤에만 기존 스크립트에 `APPROVE 216`을 전달했다.

승인 bbox SHA256:
`78ad9ffe8fa98eda241b92d22ba42be377a85c7842878e90dc7634a69cdc1877`

현재 `bbox_candidates.json`, 실행의 `annotations_used.json`, `approval.json`이 같은 승인 해시를 가리킨다. 후보 JSON 내부의 초안 플래그는 승인 후 해시를 바꾸지 않도록 유지했으며 실제 사람 승인은 별도 영수증 `approval.json`과 `approval_provenance.json`에 기록했다.

- E01+E02 train: 144장, 빈 라벨 24장
- E03 val: 72장, 빈 라벨 12장
- E04 사용: 0장
- 클래스: 0 gray_pipe / 1 exhaust_top / 2 symbol_module
- gray_pipe는 파이프 하나당 한 박스, symbol_module은 검은 문양이 붙은 회색 모듈 전체다. V8 글자판은 대상이 아니다.
- 전체 부품 누락의 빈 라벨은 유효하며 제품 없음 또는 PASS를 의미하지 않는다.

승인 이후 라벨 좌표·촬영 상태·각도·좌우 선언·분할을 바꾸지 않았다. 선택된 216개 학습/검증 이미지의 바이트 해시를 원래 인덱스와 대조했다. 원본 ZIP, source_index, 초기 가중치, 승인 bbox 해시는 학습 전후 동일하다.

## E03 개발 검증 지표

최종 best 모델의 별도 검증 결과다. 클래스별 수치는 콘솔의 반올림 표시이며 전체 정밀값은 `validation_metrics.json`에 있다.

| 대상 | 정답 부품 수 | Precision | Recall | mAP50 | mAP50–95 |
|---|---:|---:|---:|---:|---:|
| 전체 | 192 | 0.997696 | 1.000 | 0.995 | 0.664726 |
| gray_pipe | 96 | 0.998 | 1.000 | 0.995 | 0.750 |
| exhaust_top | 48 | 0.999 | 1.000 | 0.995 | 0.571 |
| symbol_module | 48 | 0.996 | 1.000 | 0.995 | 0.673 |

별도로 기존 `val_predictions.jsonl`을 승인 라벨과 대조했다. 저장 당시 conf=0.25, 클래스 일치 및 IoU>=0.50, confidence 내림차순 일대일 매칭에서 TP 192 / FP 0 / FN 0이었다. 부품 전체 누락 12장도 추가 검출 0이었다. 이 고정 임계값 대조는 위 Ultralytics mAP 산출 방식과 다르며 생산 정확도 100%를 뜻하지 않는다. 재추론이나 재학습은 하지 않았다.

## 실제 예측 이미지 검토

`review_after_training/E03_predictions_sheet_01.jpg`부터 `06.jpg`까지 실제 예측 72장 전체를 확인했다. D151, D156, D172, D205는 개별 원해상도 이미지도 확인했다.

| 사례 | 관찰 | 이미지 |
|---|---|---|
| D156 | 배기구는 검출했지만 승인 박스 대비 위·좌우로 넓고 아래 경계가 약 12px 위로 이동했다. 배기구 IoU 0.6372. | `val_predictions/D156.jpg` |
| D172 | 배기구와 파이프 박스가 승인 박스보다 위로 이동했다. 배기구 IoU 0.6672, 파이프 0.6835. 클래스/개수 일치는 박스 경계의 정확성까지 보장하지 않는다. | `val_predictions/D172.jpg` |
| D151 | 밝은 배기구 표면이 보이고 exhaust_top 신뢰도는 0.6512로 검증 세트 내 해당 클래스 최저다. 반사가 원인인지는 별도 시험하지 않았다. | `val_predictions/D151.jpg` |
| D205 | 엔진 본체는 있지만 대상 부품 전체가 빠진 사진에서 검출 0. 정상 PASS로 해석하지 않는다. | `val_predictions/D205.jpg` |

검토 범위에서 명백한 클래스 혼동·누락·추가 검출은 발견하지 못했다. 배기구의 mAP50–95와 박스 경계 차이는 남은 문제다. 결과를 좋게 만들기 위한 라벨 수정이나 E03 학습 혼입, 임계값 튜닝은 하지 않았다.

## 모델과 인계 파일

실행 폴더:
`D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634`

- 권장 검토 모델: `models/engine_parts_best.pt`
- 마지막 epoch 모델: `models/engine_parts_last.pt`
- best SHA256: `42db183006ad2a4f61dc9c22e7a61a5b506cdacb5099004fc7c3b73b74bf5259`
- last SHA256: `a5289d4a7c1d4d2afb18447696d6a9386d2e9736b5a4b860cae03b9886294500`
- 각각 5,456,154 bytes. 기존 YOLO로 두 파일을 다시 열어 3종 클래스 매핑을 확인했다.
- 원래 스크립트 ZIP: `../run_20260921T082749Z_709634_return.zip` — 보존.
- 보고서와 추가 검토 근거를 포함한 최종 인계 ZIP: `../run_20260921T082749Z_709634_reviewed_return.zip`

인계 ZIP에는 모델, 승인 영수증, 승인 라벨, 환경, 검증 지표, 실제 예측 72장, 전체 검토 시트, 원본 계보, 학습 설정·CSV·콘솔 로그, 이 보고서를 넣었다. 원본 dataset과 중간 training 폴더는 제외한다. ZIP CRC·멤버 해시·필수 파일 검증 결과는 ZIP 옆 `_verification.json`으로 남긴다.

## 검증과 미실행 범위

- 학습 전 기존 `--check-only`: exit 0, train144/val72/E04 0.
- 기존 unittest: 20/20 통과, exit 0. 코드 변경이 없어 같은 테스트를 불필요하게 반복하지 않았다.
- 승인 해시, 216장 입력 해시·분할, 모델 재로딩, 실제 예측72장, ZIP CRC: 확인.
- 학습 OS 종료 코드: 숫자 증거 미보존. 정상 완료 산출물은 확인.
- 원본 ZIP과 source_index·초기 가중치·승인 라벨 보존: 확인.
- E04 최종 시험, 다른 촬영 환경 일반화, ONNX/TensorRT 변환, Jetson 배포, 엔진 판정 레시피, Tracking, 실제 운전: 미실행.
- 이 PT 파일 하나를 기존 이어폰 패키지에 덮어쓰면 안 된다. 추후 모델 계약·클래스 매핑·레시피·촬영/보정 설정을 포함한 엔진 패키지 작업과 별도 검증이 필요하다.
