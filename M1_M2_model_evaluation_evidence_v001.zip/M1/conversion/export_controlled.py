"""기존 P0-004E 통제 export 재사용: 엔진 고정 PT, 격리 출력, Windows GPU. 원본 변경/자동 설치 없음."""
from collections import Counter
from datetime import datetime,timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import sys
import traceback

OUT=Path(__file__).resolve().parent
PT=Path('D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634/models/engine_parts_best.pt')
EXPECTED='42db183006ad2a4f61dc9c22e7a61a5b506cdacb5099004fc7c3b73b74bf5259'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def inspect_onnx(path):
    import onnx
    model=onnx.load(str(path));onnx.checker.check_model(model)
    def tensor(value):
        t=value.type.tensor_type
        return {'name':value.name,'shape':[d.dim_value if d.HasField('dim_value') else d.dim_param for d in t.shape.dim],
                'dtype':onnx.TensorProto.DataType.Name(t.elem_type)}
    graph=[{'op':n.op_type,'domain':n.domain,'inputs':list(n.input),'outputs':list(n.output)} for n in model.graph.node]
    return {'sha256':sha(path),'bytes':path.stat().st_size,'checker':'PASS',
        'inputs':[tensor(v) for v in model.graph.input],'outputs':[tensor(v) for v in model.graph.output],
        'opsets':{v.domain:v.version for v in model.opset_import},'ir_version':model.ir_version,
        'nodes':len(model.graph.node),'op_counts':dict(Counter(n.op_type for n in model.graph.node)),
        'graph_structure_sha256':hashlib.sha256(json.dumps(graph,sort_keys=True).encode()).hexdigest(),
        'metadata':{p.key:p.value for p in model.metadata_props},'external_data':any(v.data_location==1 for v in model.graph.initializer)}

def main():
    stage=OUT/'export_staging';stage.mkdir()
    config=stage/'ultralytics_config';config.mkdir()
    os.environ.update(YOLO_AUTOINSTALL='false',YOLO_CONFIG_DIR=str(config),PYTHONDONTWRITEBYTECODE='1')
    record={'status':'RUNNING','start_utc':datetime.now(timezone.utc).isoformat(),
            'source_pt':str(PT),'source_pt_sha256':sha(PT),'python':sys.version,'executable':sys.executable,
            'host_architecture':platform.machine(),'environment_variables':{k:os.environ[k] for k in ['YOLO_AUTOINSTALL','YOLO_CONFIG_DIR','PYTHONDONTWRITEBYTECODE']}}
    try:
        assert record['source_pt_sha256']==EXPECTED
        for module in ['torch','ultralytics','onnx']:importlib.metadata.version(module)
        shutil.copyfile(PT,stage/'source.pt');assert sha(stage/'source.pt')==EXPECTED
        import torch,ultralytics,onnx
        from ultralytics.utils import AUTOINSTALL
        assert not AUTOINSTALL
        record['environment']={n:{'version':m.__version__,'path':m.__file__} for n,m in [('torch',torch),('ultralytics',ultralytics),('onnx',onnx)]}
        model=ultralytics.YOLO(str(stage/'source.pt'))
        record['model']={'task':model.task,'names':model.names,'head_class':type(model.model.model[-1]).__name__}
        options={'format':'onnx','imgsz':640,'batch':1,'dynamic':False,'half':False,'nms':False,'simplify':False,'opset':12,'device':0}
        record['explicit_options']=options
        def observed(exporter):record['effective_options']=vars(exporter.args).copy()
        model.add_callback('on_export_end',observed)
        target=Path(model.export(**options)).resolve()
        assert target.is_relative_to(stage.resolve())
        record['onnx']=inspect_onnx(target);record['onnx_path']=str(target)
        assert record['onnx']['inputs'][0]['shape']==[1,3,640,640]
        assert record['onnx']['outputs'][0]['shape']==[1,4+len(model.names),8400]
        assert len(record['onnx']['inputs'])==len(record['onnx']['outputs'])==1
        assert record['onnx']['inputs'][0]['dtype']==record['onnx']['outputs'][0]['dtype']=='FLOAT'
        assert not record['onnx']['external_data']
        assert 'NonMaxSuppression' not in record['onnx']['op_counts']
        assert sha(PT)==EXPECTED
        record['status']='CONTROLLED_ONNX_EXPORT'
    except Exception as error:
        record.update(status='BLOCKED_CONTROLLED_EXPORT',error=str(error),traceback=traceback.format_exc());traceback.print_exc()
    finally:
        record['end_utc']=datetime.now(timezone.utc).isoformat()
        with (OUT/'controlled_export.json').open('x',encoding='utf-8') as f:json.dump(record,f,indent=2,default=str)
    print(json.dumps({'status':record['status'],'onnx':record.get('onnx'),'error':record.get('error')}))
    return 0 if record['status']=='CONTROLLED_ONNX_EXPORT' else 1

if __name__=='__main__':sys.exit(main())
