"""E03만 읽는 고정 모델 변환 대조. 기존 Runtime 전처리/후처리를 재사용한다."""
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
TRAIN = Path('D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634')
sys.path.insert(0, str(OUT/'candidate_runtime'))
os.environ.update(YOLO_AUTOINSTALL='false', YOLO_CONFIG_DIR=str(OUT/'export_staging/ultralytics_config'))
import cv2
import numpy as np
from src.vision.tensorrt_preprocess import preprocess
from src.vision.tensorrt_postprocess import postprocess

NAMES = ['gray_pipe', 'exhaust_top', 'symbol_module']
OUTPUT = {'layout':'BCN','box_format':'xywh','coordinate_space':'letterbox_pixels',
    'class_score_semantics':'sigmoid_probabilities','objectness_semantics':'absent',
    'number_of_classes':3,'tensor_shape_contract':{'name':'output0','dtype':'float32',
    'shape':[1,7,8400],'batch_axis':0,'feature_axis':1,'candidate_axis':2}}


def iou(a, b):
    overlap = np.maximum(0, np.minimum(a[2:], b[2:])-np.maximum(a[:2], b[:2])).prod()
    return float(overlap / (np.prod(a[2:]-a[:2])+np.prod(b[2:]-b[:2])-overlap))


def compare(left, right):
    remaining = set(range(len(right)))
    pairs = []
    for item in left:
        candidates = [(iou(np.array(item['bbox']),np.array(right[j]['bbox'])),j)
                      for j in remaining if right[j]['class_id']==item['class_id']]
        if not candidates:
            return {'pass':False,'reason':'CLASS_OR_COUNT_MISMATCH','pairs':pairs}
        overlap, index = max(candidates)
        remaining.remove(index)
        pairs.append({'class_id':item['class_id'],'bbox_iou':overlap,
            'confidence_abs_diff':abs(item['confidence']-right[index]['confidence']),
            'max_coordinate_abs_diff_px':max(abs(a-b) for a,b in zip(item['bbox'],right[index]['bbox']))})
    return {'pass':not remaining and all(p['bbox_iou']>=.98 and p['confidence_abs_diff']<=.02 for p in pairs), 'pairs':pairs}


def run(stage):
    policy = json.loads((OUT/'threshold_policy.json').read_text('utf-8'))
    annotations = json.loads((TRAIN/'annotations_used.json').read_text('utf-8'))
    items = [x for x in annotations['items'] if x['split']=='val']
    assert len(items)==72 and all(x['round_id']=='E03' for x in items)
    destination = OUT/('parity_'+stage)
    destination.mkdir(exist_ok=False)
    if stage.startswith('pt'):
        import torch, ultralytics
        assert torch.cuda.is_available()
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        model = ultralytics.YOLO(str(TRAIN/'models/engine_parts_best.pt'))
        assert list(model.names.values())==NAMES
        network = model.model.to('cuda').float().eval()
        network.fuse()
        environment = {'torch':torch.__version__,'ultralytics':ultralytics.__version__,
                       'gpu':torch.cuda.get_device_name(0),'device':'cuda:0'}
    else:
        import onnxruntime as ort
        session = ort.InferenceSession(str(OUT/'engine_parts.onnx'),providers=['CPUExecutionProvider'])
        environment = {'onnxruntime':ort.__version__,'providers':session.get_providers()}
    rows = []
    for item in items:
        name = item['review_id']
        path = TRAIN/'dataset/images/val'/(name+'.png')
        assert hashlib.sha256(path.read_bytes()).hexdigest()==item['image_sha256']
        tensor, transform = preprocess(cv2.imread(str(path)), 'float32')
        if stage.startswith('pt'):
            with torch.inference_mode():
                output = network(torch.from_numpy(tensor).to('cuda'))
                raw = (output[0] if isinstance(output,tuple) else output).float().cpu().numpy()
        else:
            raw = session.run(['output0'],{'images':tensor})[0]
        np.savez_compressed(destination/(name+'.npz'),output0=raw)
        detections = postprocess({'output0':raw},OUTPUT,NAMES,policy['confidence'],policy['nms_iou'],transform)
        values = [{'class_id':d.class_id,'confidence':d.confidence,'bbox':[d.bounding_box.x1,d.bounding_box.y1,d.bounding_box.x2,d.bounding_box.y2]} for d in detections]
        rows.append({'id':name,'scenario':item['scenario_capture_truth'],'image_sha256':item['image_sha256'],
                     'detections':values,'expected_counts':dict(Counter(b['class_id'] for b in item['boxes'])),
                     'observed_counts':dict(Counter(d['class_id'] for d in values))})
    result = {'stage':stage,'environment':environment,'images':72,'e04_used':0,'rows':rows}
    if stage!='pt_training':
        reference = json.loads((OUT/'parity_pt_training/results.json').read_text('utf-8'))
        comparisons=[]
        for left,right in zip(reference['rows'],rows):
            assert left['id']==right['id']
            value=compare(left['detections'],right['detections']);value['id']=left['id']
            first=np.load(OUT/'parity_pt_training'/(left['id']+'.npz'))['output0']
            last=np.load(destination/(left['id']+'.npz'))['output0']
            value['raw_max_abs_diff']=float(np.max(np.abs(first-last)))
            comparisons.append(value)
        result['comparison']=comparisons
        result['pass']=all(x['pass'] for x in comparisons)
    result['counts_match']=all(x['expected_counts']==x['observed_counts'] for x in rows)
    (destination/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('rows','comparison')},ensure_ascii=False))
    return 0 if result.get('pass',True) else 1


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('stage',choices=['pt_training','pt_export','onnx'])
    raise SystemExit(run(parser.parse_args().stage))
