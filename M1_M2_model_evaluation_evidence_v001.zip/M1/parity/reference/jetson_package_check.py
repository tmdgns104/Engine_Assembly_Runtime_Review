"""Jetson의 기존 load_package/create_detector로 실제 FP16 72장 대조와 종료를 검증한다."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import traceback

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'candidate_runtime'))
import cv2
import numpy as np
from src.contracts import CameraFrame
from src.recipe.package import load_package
from src.vision.detector_factory import create_detector
from src.decision.slots import assess
from src.quality.image import assess_image


def compare(left,right):
    remaining=set(range(len(right)))
    pairs=[]
    for item in left:
        candidates=[]
        a=np.array(item['bbox'])
        for j in remaining:
            if right[j]['class_id']!=item['class_id']:continue
            b=np.array(right[j]['bbox'])
            inter=np.maximum(0,np.minimum(a[2:],b[2:])-np.maximum(a[:2],b[:2])).prod()
            overlap=float(inter/(np.prod(a[2:]-a[:2])+np.prod(b[2:]-b[:2])-inter))
            candidates.append((overlap,j))
        if not candidates:return {'pass':False,'reason':'CLASS_OR_COUNT_MISMATCH','pairs':pairs}
        overlap,index=max(candidates);remaining.remove(index)
        pairs.append({'class_id':item['class_id'],'bbox_iou':overlap,
                      'confidence_abs_diff':abs(item['confidence']-right[index]['confidence']),
                      'max_coordinate_abs_diff_px':max(abs(a-b) for a,b in zip(item['bbox'],right[index]['bbox']))})
    return {'pass':not remaining and all(x['bbox_iou']>=.98 and x['confidence_abs_diff']<=.02 for x in pairs),'pairs':pairs}


def main():
    result={'status':'RUNNING','scope':'E03_NATIVE_TRT_REPLAY_NOT_LIVE_CAMERA','e04_used':0}
    detector=None
    try:
        package=load_package(ROOT/'products/ENGINE_Z3005_5/engine_parts_fp16_candidate_001')
        detector=create_detector(package)
        result['loaded']=detector.runtime_metadata()
        image=cv2.imread(str(package.root/package.manifest['files']['self_test']['path']))
        warm=detector.detect(CameraFrame(image,'self-test-D145',datetime.now(timezone.utc),image.shape[1],image.shape[0],'E03_REPLAY'))
        counts=Counter(d.class_name for d in warm.detections)
        assert counts=={'gray_pipe':2,'exhaust_top':1,'symbol_module':1},counts
        assert all(d.confidence>=package.recipe['presence_confidence'] for d in warm.detections)
        result['self_test']={'id':'D145','counts':dict(counts),'pass':True}
        reference=json.loads((ROOT/'pt_reference.json').read_text())
        assert reference['images']==72 and reference['e04_used']==0
        station=json.loads((ROOT/'station.json').read_text())
        rows=[]
        view={'alignment_confirmed':True,'product_identity':'human_confirmed',
              'visible_slots':{s['id']:True for s in package.recipe['slots']},
              'basis':'SYNTHETIC_REPLAY_COVERAGE_NOT_HUMAN_APPROVAL'}
        calibration={'confirmed':True,'slots':{s['id']:s['region'] for s in package.recipe['slots']},
                     'source':'SYNTHETIC_REPLAY_ONLY_NOT_SAVED_CALIBRATION'}
        for item in reference['rows']:
            path=ROOT/'e03'/(item['id']+'.png')
            assert hashlib.sha256(path.read_bytes()).hexdigest()==item['image_sha256']
            image=cv2.imread(str(path))
            frame=CameraFrame(image,item['id'],datetime.now(timezone.utc),image.shape[1],image.shape[0],'E03_REPLAY')
            detection=detector.detect(frame)
            values=[{'class_id':d.class_id,'confidence':d.confidence,
                     'bbox':[d.bounding_box.x1,d.bounding_box.y1,d.bounding_box.x2,d.bounding_box.y2]} for d in detection.detections]
            parity=compare(item['detections'],values)
            observed={str(k):v for k,v in Counter(d.class_id for d in detection.detections).items()}
            observation=detection.to_dict()
            observation.update(width=frame.width,height=frame.height,quality=assess_image(image,station['quality']))
            sequence=[dict(observation,frame_id=f'{item["id"]}-synthetic-{i}',freshness={'source_pts_ns':i}) for i in range(3)]
            decision=assess(sequence,package.recipe,view,calibration)
            expected='PASS' if item['scenario']=='NORMAL' else 'FAIL'
            rows.append({'id':item['id'],'scenario':item['scenario'],'detections':values,'parity':parity,
                'expected_counts':item['expected_counts'],'observed_counts':observed,
                'counts_match':observed==item['expected_counts'],'decision':decision,
                'synthetic_coverage_decision_matches':decision['decision']==expected})
        result.update(rows=rows,images=len(rows),before_close=detector.runtime_metadata())
        result['status']='PASS' if all(x['parity']['pass'] and x['counts_match'] and x['synthetic_coverage_decision_matches'] for x in rows) else 'PARITY_OR_DECISION_BLOCKED'
    except Exception:
        result.update(status='ERROR',traceback=traceback.format_exc())
    finally:
        if detector:
            try:
                detector.close()
                result['after_close']=detector.runtime_metadata()
                detector.close()
                result['idempotent_close']=result['after_close']==detector.runtime_metadata()
            except Exception:result.update(status='CLEANUP_ERROR',cleanup=traceback.format_exc())
        (ROOT/'native_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('rows','loaded','before_close','after_close')},ensure_ascii=False))
    return 0 if result['status']=='PASS' else 1


if __name__=='__main__':raise SystemExit(main())
