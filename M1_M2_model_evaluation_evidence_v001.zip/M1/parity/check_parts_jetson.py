"""Native E03 numerical parity for isolated mixed-precision candidate, unchanged tolerances."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import shutil
import sys
import time

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'engine_parts_pkg_candidate_001_20260922'
sys.path[:0]=[str(OLD/'candidate_runtime'),str(OLD)]
import cv2
import numpy as np
from src.contracts import CameraFrame
from src.recipe.package import load_package
from src.vision.detector_factory import create_detector
from jetson_package_check import compare


def main():
    package=ROOT/'parts_test_package_v001'
    shutil.copytree(OLD/'products/ENGINE_Z3005_5/engine_parts_fp16_candidate_001',package)
    build=json.loads((ROOT/'parts_fp16_head32_v001/build_manifest.json').read_text())
    shutil.copyfile(ROOT/'parts_fp16_head32_v001/model.plan',package/'model.plan')
    manifest=json.loads((package/'manifest.json').read_text())
    manifest['release_id']='parts_fp16_head32_v001'
    manifest['files']['model']['sha256']=build['plan_sha256']
    manifest['detector']['provenance']['build']['options']=dict(build['options'],precision='fp16',actual_builder_flags=build['actual_builder_flags'])
    (package/'manifest.json').write_text(json.dumps(manifest,indent=2))
    detector=create_detector(load_package(package),latency_enabled=True)
    reference=json.loads((OLD/'pt_reference.json').read_text())
    assert len(reference['rows'])==72
    rows=[]
    try:
        for item in reference['rows']:
            rid=item['id']
            assert 145<=int(rid[1:])<=216
            path=OLD/'e03'/f'{rid}.png'
            assert hashlib.sha256(path.read_bytes()).hexdigest()==item['image_sha256']
            image=cv2.imread(str(path))
            frame=CameraFrame(image,rid,datetime.now(timezone.utc),1280,720,'E03_REPLAY')
            start=time.perf_counter()
            detected=detector.detect(frame).to_dict()
            latency=(time.perf_counter()-start)*1000
            values=[{'class_id':d['class_id'],'confidence':d['confidence'],
                     'bbox':[d['bounding_box'][k] for k in ('x1','y1','x2','y2')]} for d in detected['detections']]
            rows.append({'id':rid,'detections':values,'parity':compare(item['detections'],values),'latency_ms':latency})
    finally:detector.close()
    report={'rows':rows,'pass_count':sum(r['parity']['pass'] for r in rows),'count':72,'e04_used':0,
        'failed':[r['id'] for r in rows if not r['parity']['pass']],
        'cold_first_ms':rows[0]['latency_ms'],'warm_p50_ms':float(np.median([r['latency_ms'] for r in rows[1:]])),
        'warm_p95_ms':float(np.percentile([r['latency_ms'] for r in rows[1:]],95)),
        'close':detector.runtime_metadata(),'scope':'E03 stored frames, parts detector only; not live FPS'}
    (ROOT/'parts_parity_v001.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:v for k,v in report.items() if k not in ('rows','close')}))


if __name__=='__main__':main()
