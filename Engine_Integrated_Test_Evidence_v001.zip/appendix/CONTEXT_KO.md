# 다른 시점 자료의 적용 범위

| 자료 | 릴리스/조건 | 확인된 내용 | 이번 7건과의 관계 |
|---|---|---|---|
| FIELD_v002_FINDINGS.md | 2026-10-18, engine-integrated-9488d93c4d69566e | 별도 PASS 1건과 빈 벨트 220프레임. 요청은 녹화 종료 약14초 뒤. RUN_CAPTURE_OWNER_CHANGED는 추적 ID 해석 진단 | 다른 릴리스·다른 ID. 7회 영상이나 7건의 실패로 쓰지 않음. 당시 후보/미적용 문장은 그 기록 시점의 상태 |
| sources/field_ten/AFTER_*.json | 이번 4c4b 시험 | 이전 제품 추적 진단 PRODUCT_PASSAGE_OCCLUSION_OR_AMBIGUITY가 남지만 선택7건은 COMPLETE, 기본/최종 REVIEW·ERROR 0 | 기록 보존. 추적 진단을 삭제하거나 부품검사 실패로 재명명하지 않음 |
| benchmark_operating_after_verification.json | 2026-10-19, 32c4 운영 복구 | 모델·운영 파일 해시 유지 및 기존 운영 준비 관측 | 저장 사진 Benchmark/복구 증거이며 새 실물 이송시험 아님 |
| restore_observation_174722.json | 같은 Benchmark 후 카메라 복구 | 당시 카메라·IPC/준비 상태 관측 | 그 시점 복구 범위. 오늘 재현된 카메라 장애라고 해석하지 않음 |
| sources/inventory_selected_sections.json | 기존 녹화·현장 자산 목록 | 빈 벨트·진단·다른 시점 경로 검색 근거 | 선택7건 ID와 연계된 동작영상 미확보. 전체 영상을 복사하거나 새 촬영하지 않음 |

조명 수치·거리·허용 위치/각도 분포는 이 7회에 연결되는 계측 근거가 없어 추정하지 않았다. 더 과거의 STATIC300 참고 분류나 다른 릴리스의 반복시험 결과는 이번 정상4/결품3의 성능 분모에 넣지 않았다. 오류 대응 코드·당시 재부팅 준비 확인이 존재해도 모든 현장 장애가 해결됐다는 포괄적 보증으로 사용하지 않는다.
