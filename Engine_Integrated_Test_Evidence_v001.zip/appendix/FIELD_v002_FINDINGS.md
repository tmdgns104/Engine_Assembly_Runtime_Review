# 이번 운전과 진단 수집의 분리 확인

- 운영본 `engine-integrated-9488d93c4d69566e` 적용·실제 재부팅·자동 준비 완료. 전환 명령 재실행 없음.
- 검사 `31c25aaaeb6548299e62f3b512e600eb`: COMPLETE/PASS, 2026-10-18 07:42:21.711603Z 수락 → 07:42:24.102263Z 원검사 완료. PLC Result/Done/완료 각 1. 통합 PLC 전체 응답 시간과 원검사 저장 시간을 혼동하지 않음.
- 운전 진단은 07:41:47.870950Z~07:42:07.724109Z, 원본 220장, source span 19.864초. RAW SHA와 디코딩 pixel SHA 220/220 일치, 중복·수집 드롭 0. 기록된 PLC 요청은 전부 0/IDLE이고 220장 모두 NO_FOREGROUND·부품 NOT_COMPUTED.
- 실제 검사 수락은 마지막 진단 프레임보다 약 14초 뒤다. 이 영상은 빈 벨트 운전 자료이며 엔진의 진입→정지→검사→배출 구간 확보 성공이 아니다. 확인 메시지를 기다린 진행 방식 때문에 20초 창을 놓쳤다.

## RUN_CAPTURE_OWNER_CHANGED

arm과 완료 시점의 실제 camera Worker 2872, worker generation, camera epoch, Service session, PLC boot/connection은 동일하다. 변경된 것은 `runtime_session_id` 하나다.

`StandaloneRuntime._start_automatic_observation_window`는 유효 PLC 요청을 수락하면 `_reset_unbound_observation`을 호출하고 제품 추적 세션을 갱신한다. 진단 controller가 이 추적 ID를 장치 실행 주체로 잘못 사용했다. 이번에는 20초 녹화가 끝난 후 새 요청을 처리하면서 종료 상태에 경고가 붙었다. 실제 검사 장애나 카메라 교체로 기록하지 않는다.

후보 `engine-integrated-0ff4d41638d745ff`는 이 비교 한 곳만 수정한다. 동일 controller/runtime 객체, Service session, Worker generation, 카메라 epoch, PLC boot/connection, 공유 신호 객체 검사는 유지한다. 실제 장치·연결 교체는 진단 중단을 유지한다. 모델·임계값·촬영/안정 시간·원본 요구·400ms·PLC 제어·메모리 복사/저장 경로 변경 없음.

Windows 관련 28 PASS, ARM64 관련 49 PASS, 기존 코드로 정상 추적 갱신 시 2실패 재현. Windows 초기 실행 2건의 정체는 asyncio socketpair 초기화였고 실패 로그를 보존했다. 제한 환경 밖에서 같은 관련 시험을 통과했다. 운영 미적용, 새 후보 재부팅·실물 수집 미실행.

## PLC 해석과 다음 절차

근거는 제공된 PLC 저장파일 SHA `c0dff344cb815ae75cffe63c21454384393061abf4fa35e7d46405033c879137`, 23 rung과 실제 C snapshot이다. 온라인 PLC 전체 프로그램 일치 여부는 미확인이다.

| 신호 | 확인한 의미 | 실제 관측 범위 |
|---|---|---|
| Start_PB | 정상 STOP/E-stop 회로에서 Mc_Run 자기유지 시작 | 사용자의 실제 버튼 동작과 Mc_Run 전이로 확인; 입력 자체는 Jetson에 미노출 |
| Stop_PB | true가 정상/해제된 STOP 회로 | STOP 대기와 RUN 양쪽 모두 true 관측; 물리 STOP 후 Mc_Run=false |
| Mc_Run | 운전 유지 상태 | STOP false → START true → STOP false 관측 |
| PhotoSensor | Mc_Run 및 Sensor_Ready와 함께 새 이송 시작 조건 | 저장 PLC 소스 확인; 현재 Jetson 인터페이스에 미노출 |
| Sensor_Ready | 감지 후 해제, 주기 완료·센서 해제 또는 정지 조건에서 재준비 | 저장 PLC 소스 확인; 실시간 내부값 미관측 |
| Inspection_Request | 4.5초 이송·정지 뒤 2초 대기로 검사 요청 | 요청 1 수락·Result/Done/완료 1·LOW 복귀 확인 |

다음은 STOP·빈 벨트에서 진단 준비 → 실제 START → 실시간 신호를 직접 감시해 즉시 정상 모형 한 개 투입 안내 → 검사/배출 완료 → 실제 STOP 후 저장이다. START 답변을 기다리는 채팅 지연을 촬영 창에 소비하지 않는다. 새 진단 기능/기간 증가는 하지 않는다.

## 개선 채택 판단

STOP 극성 오류 때문에 진단이 즉시 0장으로 끝나던 문제는 이번 RUN 220장 수집으로 재현되지 않았다. 하지만 엔진 점수 미달과 저점수 추가 부품 후보 문제는 이 빈 벨트 자료로 평가할 수 없다. 두 문제의 최소 수정·보정 채택은 보류하며 모델/임계값은 그대로 유지한다. 정상 위치 편차의 오류 감소와 혼합30 수용시험은 미완료다. config.py 및 케이스별50회는 별도 후속작업이다.
