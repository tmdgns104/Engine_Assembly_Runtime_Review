"""User-authorized consistent SQLite backup, retaining live DB and source evidence."""
import hashlib,json,sqlite3,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[2]
output=root/'database/snapshots/20261018_post7'
output.mkdir(parents=True,exist_ok=True)
destination=output/'journal.sqlite3'
ssh=['ssh','-i','C:/Users/user/.ssh/oned_device_jetson_bench_ed25519','-o','BatchMode=yes','-o','ConnectTimeout=8','jetson@192.168.50.2']
code='''import hashlib,json,sqlite3,time
from datetime import datetime,timezone
from pathlib import Path
root=Path('/home/jetson/oned_device_bench')
cfg=json.loads((root/'config/standalone.json').read_text())
source=(root/'config'/cfg['data_root']).resolve()/'journal.sqlite3'
out=root/'tmp/verify/publication_20261018_post7'
out.mkdir(parents=True,exist_ok=True)
dest=out/'journal.sqlite3'
if not dest.exists():
 src=sqlite3.connect(source.as_uri()+'?mode=ro',uri=True,timeout=1)
 dst=sqlite3.connect(dest)
 try:src.backup(dst,pages=128,sleep=.02)
 finally:dst.close();src.close()
db=sqlite3.connect(dest.as_uri()+'?mode=ro',uri=True)
receipt={'source':'Jetson operational SQLite','created_at':datetime.now(timezone.utc).isoformat(),
 'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,
 'integrity_check':db.execute('PRAGMA integrity_check').fetchone()[0],
 'inspections':db.execute('SELECT COUNT(*) FROM inspections').fetchone()[0],
 'decisions':dict(db.execute("SELECT coalesce(decision,'PENDING'),count(*) FROM inspections GROUP BY decision")),
 'secret_named_state_keys':[r[0] for r in db.execute("SELECT key FROM service_state WHERE lower(key) LIKE '%password%' OR lower(key) LIKE '%secret%' OR lower(key) LIKE '%auth_token%'")],
 'assets_referenced':db.execute('SELECT COUNT(*) FROM frame_assets').fetchone()[0]}
db.close()
print(json.dumps(receipt))
'''
proc=subprocess.run(ssh+['/home/jetson/oned_device_bench/envs/app_v1/bin/python -B -'],input=code.encode(),capture_output=True,timeout=60)
if proc.returncode:raise RuntimeError(proc.stderr.decode(errors='replace')[-600:])
receipt=json.loads(proc.stdout)
if receipt['integrity_check']!='ok' or receipt['secret_named_state_keys']:raise RuntimeError('SNAPSHOT_NEEDS_REVIEW')
if not destination.exists():
    subprocess.run(['scp','-i','C:/Users/user/.ssh/oned_device_jetson_bench_ed25519','-o','BatchMode=yes','jetson@192.168.50.2:/home/jetson/oned_device_bench/tmp/verify/publication_20261018_post7/journal.sqlite3',str(destination)],check=True,timeout=60,capture_output=True)
assert hashlib.sha256(destination.read_bytes()).hexdigest()==receipt['sha256']
receipt['photos_included']=False
receipt['photo_scope']='DB references retained; raw inspection photos remain on Jetson/local evidence. Missing photo files are not hidden.'
(output/'snapshot.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
