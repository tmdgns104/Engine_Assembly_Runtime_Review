-- 읽기 전용 / Python sqlite3 URI mode=ro&immutable=1; PRAGMA query_only=ON; BEGIN.
-- :id 에 inspection_results.csv의 검사 ID를 바인딩한다. JSON 안의 이전 ID 참조는 주대상과 구분한다.
SELECT * FROM inspections WHERE inspection_id=:id;
SELECT * FROM frame_assets WHERE inspection_id=:id;
SELECT * FROM defects WHERE inspection_id=:id;
SELECT * FROM dispositions WHERE inspection_id=:id;
SELECT * FROM events WHERE instr(payload_json,:id)>0 ORDER BY occurred_at;
SELECT * FROM service_state WHERE key IN ('integrated_decision:'||:id,'production_publication:'||:id);
-- 실제 7건 일괄 조회 및 outbox/cycles join은 code/build_evidence.py에 기록.
