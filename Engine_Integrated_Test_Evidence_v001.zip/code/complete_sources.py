"""확인된 UI 후보 경로 2개만 보완한다. 원장 집계를 다시 수행하지 않는다."""
from pathlib import Path
import json,hashlib,shutil
O=Path(__file__).resolve().parents[1];W=Path('D:/OneDevice_Team_project/runs/config_ui_history_20261018')
read=lambda p:json.loads(p.read_text('utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
index=read(O/'provenance_index.json');release=read(W/'ui_transition/AFTER_REBOOT_PROOF.json')['release'];checks=[]
for name in ('apps/edge_service/line_details.js','apps/edge_service/line_hmi.html'):
    p=W/'ui_transition/candidate'/name;rel='sources/ui_transition/runtime/'+name;dest=O/rel
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
    assert sha(p)==sha(dest)==release['files']['current/'+name]
    index[rel]={'source_path':str(p),'method':'BYTE_COPY','source_sha256':sha(p)};checks.append({'path':str(p),'sha256':sha(p),'release_match':True})
(O/'provenance_index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),'utf-8')
trial=read(O/'trial_reconciliation.json');trial['source_search_resolved']=trial.pop('source_missing');trial['source_missing']=[]
trial['resolved_ui_sources']=checks;(O/'trial_reconciliation.json').write_text(json.dumps(trial,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'resolved_ui_files':len(checks),'checks':checks},ensure_ascii=False))
