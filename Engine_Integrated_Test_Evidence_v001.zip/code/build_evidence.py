"""기존 7건을 일관된 로컬 SQLite snapshot에서 읽어 제출용 증빙으로 연결한다.
운영 코드 실행, DB 쓰기, 카메라 열기, PLC 제어를 하지 않는다.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import csv, hashlib, json, sqlite3, shutil, statistics

P=Path('D:/OneDevice_Team_project'); W=P/'runs/config_ui_history_20261018'
O=Path(__file__).resolve().parents[1]
def read(p): return json.loads(Path(p).read_text('utf-8-sig'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(rel,data):
    p=O/rel;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(data if isinstance(data,str) else json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def csv_write(rel,rows,fields=None):
    p=O/rel;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields or list(rows[0]));w.writeheader();w.writerows(rows)
provenance={}; source_missing=[]
def copy(src,rel):
    src=Path(src)
    if not src.is_file():source_missing.append({'searched':str(src),'reason':'FILE_NOT_FOUND'});return
    dest=O/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
    assert sha(src)==sha(dest)
    provenance[rel]={'source_path':str(src),'method':'BYTE_COPY','source_sha256':sha(src)}

after_name='AFTER_20261018T092246_484843Z.json'
after=read(W/'field_ten'/after_name);before=read(W/'field_ten/BEFORE.json')
summary=read(W/'field_ten/FINAL_SUMMARY.json'); expected=read(W/'field_ten/EXPECTED_SEQUENCE.json')
records=sorted(after['records'],key=lambda r:r['row']['request_id'])
ids=[r['row']['inspection_id'] for r in records]; idset=set(ids)
assert len(ids)==7 and set(after['inspection_ids'])-set(before['inspection_ids'])==idset
for name in ('BEFORE.json','EXPECTED_SEQUENCE.json','FINAL_SUMMARY.json',after_name):copy(W/'field_ten'/name,'sources/field_ten/'+name)
for path in sorted((W/'field_ten').glob('OBSERVE_*.json')):copy(path,'sources/field_ten/'+path.name)
for sub in ('transition','ui_transition'):
    for name in ('DEPLOYMENT.json','AFTER_REBOOT_PROOF.json'):
        copy(W/sub/name,f'sources/{sub}/{name}')
copy(P/'docs/verification/CONFIG-UI-HISTORY-20261018.json','sources/CONFIG-UI-HISTORY-20261018.json')
copy(P/'database/snapshots/20261018_post7/snapshot.json','db/source_snapshot_receipt.json')
copy(W/'snapshot_post7.py','sources/historical_snapshot_post7.py')
for name in ('UI_CROP_JETSON.png','UI_CROP_JETSON.json','UI_DETAIL_VERIFIED.txt','UI_FILTER_VERIFIED.txt'):
    copy(W/name,'sources/screens/'+name)
for path in sorted(W.glob('UI_DEVICE_CHECK_*.json')):copy(path,'sources/screens/'+path.name)

runtime=W/'transition/runtime'
runtime_names=['src/config.py','src/configuration.py','src/runtime/standalone.py','src/runtime/standalone_web.py','src/control/opener_cyclic.py','src/control/standalone_plc.py','src/journal/history.py','apps/edge_service/history_api.py']
trial_release=read(W/'transition/AFTER_REBOOT_PROOF.json')['release']; trial_files=trial_release['files']
source_code_checks=[]
for name in runtime_names:
    p=runtime/name;copy(p,'sources/tested_runtime/'+name)
    source_code_checks.append({'file':name,'sha256':sha(p),'release_sha256':trial_files.get('current/'+name),'match':sha(p)==trial_files.get('current/'+name)})
assert all(x['match'] for x in source_code_checks)
for name in ('apps/edge_service/line_details.js','apps/edge_service/line_hmi.html'):
    for sub in ('transition','ui_transition'):
        source_dir='candidate' if sub=='ui_transition' else 'runtime'
        copy(W/sub/source_dir/name,f'sources/{sub}/runtime/{name}')
plc_src=Path('D:/머신러닝_학습자료/비전검사 푸셔없는버전 4 .smc2')
copy(plc_src,'sources/plc/'+plc_src.name)
for name in ('PLC_SELECTED_FILE_v001.json','PLC_SAVED_LADDER_v001.json'):
    copy(P/'runs/inspection_reliability_20261018/run_capture_transition'/name,'sources/plc/'+name)
copy(P/'runs/inspection_reliability_20261018/run_capture_polarity_transition/FIELD_v002_FINDINGS.md','appendix/FIELD_v002_FINDINGS.md')
ladder=read(O/'sources/plc/PLC_SAVED_LADDER_v001.json');assert sha(plc_src)==ladder['source_sha256']
benchmark=P/'docs/evaluation_assets/20261019/M1_M2_benchmark_evidence_v001'
copy(benchmark/'operating_after_verification.json','appendix/benchmark_operating_after_verification.json')
# 복구 관측 파일은 기존 묶음의 실제 경로만 사용한다.
restore=list(benchmark.rglob('restore_observation_174722.json'))
for p in restore:copy(p,'appendix/'+p.name)
inventory=read(P/'docs/evaluation_assets/20261019/asset_inventory.json')
write('sources/inventory_selected_sections.json',{k:inventory.get(k) for k in ('recordings','field_evaluation','remote_observation')})
provenance['sources/inventory_selected_sections.json']={'source_path':str(P/'docs/evaluation_assets/20261019/asset_inventory.json'),'method':'SELECTED_KEYS_EXPORT','source_sha256':sha(P/'docs/evaluation_assets/20261019/asset_inventory.json')}

db=P/'database/snapshots/20261018_post7/journal.sqlite3';db_hash=sha(db)
assert db_hash==read(O/'db/source_snapshot_receipt.json')['sha256']
con=sqlite3.connect(db.as_uri()+'?mode=ro&immutable=1',uri=True);con.row_factory=sqlite3.Row
con.execute('PRAGMA query_only=ON');con.execute('BEGIN')
integrity=con.execute('PRAGMA integrity_check').fetchone()[0];assert integrity=='ok'
schema='\n\n'.join(x[0]+';' for x in con.execute("SELECT sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name"))
write('db/schema.sql',schema)
marks=','.join('?' for _ in ids)
tables={}
for name in ('inspections','defects','frame_assets','dispositions'):
    tables[name]=[dict(x) for x in con.execute(f'SELECT * FROM {name} WHERE inspection_id IN ({marks})',ids)]
tables['cycles']=[dict(x) for x in con.execute(f'SELECT DISTINCT c.* FROM cycles c JOIN inspections i ON c.cell_id=i.cell_id AND c.plc_session_id=i.plc_session_id AND c.cycle_id=i.cycle_id WHERE i.inspection_id IN ({marks})',ids)]
tables['events']=[dict(x) for x in con.execute('SELECT * FROM events WHERE '+' OR '.join('instr(payload_json,?)>0' for _ in ids)+' ORDER BY occurred_at',ids)]
event_ids=[x['event_id'] for x in tables['events']]
tables['outbox']=[dict(x) for x in con.execute('SELECT * FROM outbox WHERE event_id IN ('+','.join('?' for _ in event_ids)+')',event_ids)]
tables['service_state']=[dict(x) for x in con.execute('SELECT * FROM service_state WHERE key IN ('+','.join('?' for _ in ids*2)+')',[f'{prefix}:{i}' for prefix in ('integrated_decision','production_publication') for i in ids])]
write('db/selected_rows.json',tables)
write('db/queries.sql','''-- 읽기 전용 / Python sqlite3 URI mode=ro&immutable=1; PRAGMA query_only=ON; BEGIN.
-- :id 에 inspection_results.csv의 검사 ID를 바인딩한다. JSON 안의 이전 ID 참조는 주대상과 구분한다.
SELECT * FROM inspections WHERE inspection_id=:id;
SELECT * FROM frame_assets WHERE inspection_id=:id;
SELECT * FROM defects WHERE inspection_id=:id;
SELECT * FROM dispositions WHERE inspection_id=:id;
SELECT * FROM events WHERE instr(payload_json,:id)>0 ORDER BY occurred_at;
SELECT * FROM service_state WHERE key IN ('integrated_decision:'||:id,'production_publication:'||:id);
-- 실제 7건 일괄 조회 및 outbox/cycles join은 code/build_evidence.py에 기록.
''')
byid={x['inspection_id']:x for x in tables['inspections']}
events=[]
for e in tables['events']:
    envelope=json.loads(e['payload_json']);payload=envelope.get('payload',{})
    events.append({'event_id':e['event_id'],'event_type':e['event_type'],'occurred_at':e['occurred_at'],'primary_inspection_id':payload.get('inspection_id'),'referenced_selected_ids':[i for i in ids if i in e['payload_json']],'payload':payload})
write('db/event_links.json',events)
con.rollback();con.close();assert sha(db)==db_hash
write('db/export_verification.json',{'source':str(db),'source_sha256_before':db_hash,'source_sha256_after':sha(db),'source_integrity':integrity,'source_db_bytes':db.stat().st_size,'mode':'mode=ro&immutable=1; query_only=ON; BEGIN; ROLLBACK','selected_counts':{k:len(v) for k,v in tables.items()},'full_db_included':False,'snapshot_method':'Existing 2026-10-18 SQLite backup() snapshot; source code and receipt included','exported_at':datetime.now(timezone.utc).isoformat()})

recovery=read(O/'remote_recovery_receipt.json');remote_by_path={x['output']:x for x in recovery['files']}
for item in recovery['files']:
    provenance[item['output']]={'source_path':item['source'],'method':'REMOTE_BYTE_COPY','source_sha256':item['actual_sha256']}
for query in recovery['queries']:
    if 'output' in query:provenance[query['output']]={'source_path':query['url'],'method':'READ_ONLY_HTTP_GET','source_sha256':query['sha256'],'observed_at':query['queried_at']}

history={x['inspection_id']:x for x in after['state']['history']}
results=[];assets=[];checks=[];metrics=[]
for number,record in enumerate(records,1):
    ident=record['row']['inspection_id'];row=byid[ident]; result=json.loads(row['result_json']);package=json.loads(row['package_json']); final=record['final']; hist=history[ident]
    # 모든 열과 JSON 의미 대조. 당시 수집 record와 snapshot의 동일 ID를 비교한다.
    mismatches=[]
    for k,v in row.items():
        actual=json.loads(v) if k.endswith('_json') and v is not None else v
        if actual!=record['row'][k]:mismatches.append(k)
    assert not mismatches,(ident,mismatches)
    own_events=[e for e in events if e['primary_inspection_id']==ident]
    completed=[e for e in own_events if e['event_type']=='PLC_CYCLIC_COMPLETION_OBSERVED'];assert len(completed)==1
    durable=[e for e in own_events if e['event_type']=='INSPECTION_DURABLE_TIMING'];assert len(durable)==1
    assert hist['cyclic_done_reset_observed'] is True and final['plc_consumption_confirmed'] is False
    write(f'assets/{ident}/db_result.json',row['result_json'])
    write(f'assets/{ident}/integrated_final.json',final)
    write(f'db/per_inspection/{ident}.json',{'inspection':row,'events':own_events,'saved_history':hist,'assets':record['assets']})
    provenance[f'assets/{ident}/db_result.json']={'source_path':str(db)+'#inspections.result_json:'+ident,'method':'DATABASE_FIELD_EXPORT','source_sha256':db_hash}
    provenance[f'assets/{ident}/integrated_final.json']={'source_path':str(W/'field_ten'/after_name)+'#records.final:'+ident,'method':'HISTORICAL_JSON_FIELD_EXPORT','source_sha256':sha(W/'field_ten'/after_name)}
    raw_paths=[];overlay_paths=[]
    for asset in record['assets']:
        rel=asset['relative_path'];p=O/rel;remote=remote_by_path[rel]
        assert p.is_file() and sha(p)==asset['sha256']==remote['actual_sha256']
        assert p.stat().st_size==asset['bytes']
        (raw_paths if asset['kind']=='raw' else overlay_paths).append(rel)
        assets.append({'inspection_id':ident,'role':asset['kind'],'original_path':remote['source'],'bundle_path':rel,'bytes':p.stat().st_size,'sha256':sha(p),'ledger_sha256':asset['sha256'],'ledger_match':True,'capture_at':asset['capture_at'],'width':asset['width'],'height':asset['height'],'verification_scope':'원장 SHA-256 및 원격 실파일·회수본 바이트 일치'})
    for rel,role in [(f'assets/{ident}/assembly/result.json','existing_reference_result_json'),(f'assets/{ident}/db_result.json','db_result_json_export'),(f'assets/{ident}/integrated_final.json','final_json_export')]:
        p=O/rel;assets.append({'inspection_id':ident,'role':role,'original_path':provenance[rel]['source_path'],'bundle_path':rel,'bytes':p.stat().st_size,'sha256':sha(p),'ledger_sha256':'','ledger_match':'NOT_APPLICABLE','capture_at':'','width':'','height':'','verification_scope':'원격 원본 SHA 일치' if role.startswith('existing') else '기존 DB/수집 JSON 필드의 명시적 내보내기'})
    detail=read(O/f'queries/{ident}_detail.json');search=read(O/f'queries/{ident}_search.json')
    # 조회 스키마를 엄격히 알기 전에 임의의 다른 ID를 연결하지 않는다.
    detail_text=json.dumps(detail);search_text=json.dumps(search)
    assert ident in detail_text and ident in search_text
    accepted=datetime.fromisoformat(row['accepted_at']); ended=datetime.fromisoformat(row['completed_at'])
    completion=completed[0];event_duration=(completion['payload']['monotonic_s']-final['cycle_admission_evidence']['accepted_at'])*1000
    payload=durable[0]['payload']; summary_row=summary['records'][number-1]
    result_row={'trial':'CONFIG_UI_HISTORY_FIELD_SEVEN_20261018','number':number,'inspection_id':ident,'request_id':row['request_id'],'plc_session_id':row['plc_session_id'],'cycle_id':row['cycle_id'],'attempt':row['attempt'],
        'input_state':expected['sequence'][number-1],'input_state_basis':'사전 순서표 + 두 모형 준비 사용자 확인 + 당시 FINAL_SUMMARY; 개별 ID별 독립 정답 영상 없음','expected_decision':expected['expected'][number-1],
        'basic_decision':row['decision'],'reference_assembly':final['assembly_reported'],'reference_affects_final':final['assembly_affects_final'],'final_decision':final['decision'],'matches_planned_expected':final['decision']==expected['expected'][number-1],'basic_reason':result['reason_code'],'reference_reason':final['assembly_reason'],'final_reason':final['reason'],
        'plc_result_value':final['plc_result_value'],'plc_result_done_status':hist['publication_status'],'cyclic_done_reset_observed':hist['cyclic_done_reset_observed'],'plc_consumption_confirmed':final['plc_consumption_confirmed'],'plc_completion_event_id':completion['event_id'],'plc_evidence_path':f'db/per_inspection/{ident}.json',
        'db_state':row['state'],'storage_success':result['storage_success'],'raw_count':len(raw_paths),'raw_paths':'|'.join(raw_paths),'overlay_paths':'|'.join(overlay_paths),'result_path':f'assets/{ident}/db_result.json','final_path':f'assets/{ident}/integrated_final.json','reference_path':f'assets/{ident}/assembly/result.json',
        'query_detail_path':f'queries/{ident}_detail.json','query_search_path':f'queries/{ident}_search.json','query_http_status':200,'query_at':next(q['queried_at'] for q in recovery['queries'] if q['inspection_id']==ident and q['kind']=='detail'),
        'release':summary['release'],'boot_id':after['boot_id'],'configuration_effective_sha256':package['configuration']['sha256'],'m1_model_sha256':result['backend']['artifact_sha256'],'m2_model_sha256':result['backend']['envelope']['artifact_sha256'],
        'accepted_at':row['accepted_at'],'raw_completed_at':row['completed_at'],'integrated_completed_at':final['completed_at'],'plc_completion_event_at':completion['occurred_at'],
        'journal_elapsed_ms':round((ended-accepted).total_seconds()*1000,3),'request_to_three_frames_ms':result['request_to_three_frames_ms'],'request_to_durable_result_ms':payload['request_to_durable_result_ms'],'storage_commit_ms':payload['storage_commit_ms'],'integrated_elapsed_ms':final['inspection_elapsed_ms'],'request_to_publication_ms':hist['request_to_publication_ms'],'request_to_plc_completion_event_ms':event_duration,
        'timing_definitions_path':'TIME_AND_FIELD_MAP_KO.md','device_observation':'사용자 실제 LED·컨베이어 동작 확인(2026-10-20 사후 진술, 시험 묶음 단위)','device_observation_path':'user_observations.md','unverified':'ID별 LED/모터 타임코드·독립 전기 피드백·실물 운전영상; 개별 투입 정답의 별도 확인'}
    results.append(result_row)
    checks.append({'inspection_id':ident,'snapshot_vs_historical_record_columns_equal':True,'raw_images':len(raw_paths),'overlay_images':len(overlay_paths),'plc_completion_events':len(completed),'planned_match':result_row['matches_planned_expected'],'new_queries_contain_exact_id':True,'detail_keys':list(detail),'search_keys':list(search)})
    for col in ('journal_elapsed_ms','request_to_three_frames_ms','integrated_elapsed_ms'):
        assert abs(float(result_row[col])-summary_row[col])<.002

csv_write('inspection_results.csv',results);csv_write('asset_manifest.csv',assets)
for field in ('journal_elapsed_ms','request_to_three_frames_ms','request_to_durable_result_ms','storage_commit_ms','integrated_elapsed_ms','request_to_publication_ms','request_to_plc_completion_event_ms'):
    values=[r[field] for r in results];metrics.append({'field':field,'count':7,'min_ms':min(values),'max_ms':max(values),'mean_ms':statistics.mean(values),'definition_path':'TIME_AND_FIELD_MAP_KO.md'})
csv_write('timing_summary.csv',metrics)
old_release=read(W/'transition/AFTER_REBOOT_PROOF.json')['release'];new_release=read(W/'ui_transition/AFTER_REBOOT_PROOF.json')['release']
diff=[{'path':key,'tested_sha256':old_release['files'].get(key),'ui_sha256':new_release['files'].get(key)} for key in sorted(set(old_release['files'])|set(new_release['files'])) if old_release['files'].get(key)!=new_release['files'].get(key)]
csv_write('release_file_changes.csv',diff)
assert set(x['path'] for x in diff)=={'current/apps/edge_service/line_details.js','current/apps/edge_service/line_hmi.html'}
current=read(O/'queries/current_operating_observation.json')
write('release_linkage.json',{'tested':summary['release'],'tested_boot':after['boot_id'],'ui_release':new_release['release_id'],'current_read_only_observation':current['release']['release_id'],'file_manifest_diff':diff,'trial_source_files':source_code_checks,'current_manifest_matches_ui_manifest':current['release']['files']==new_release['files'],'effective_configuration_sha256':summary['configuration_sha256'],'current_standalone_file_sha256':current['configuration_sha256'],'configuration_hash_scopes_differ':'effective process settings vs standalone.json bytes; do not compare as identical hash scopes','new_physical_test_performed':False})
write('user_observations.md','''# 사용자 현장 관찰 기록

출처: 이 작업의 현재 대화. 아래 문장은 사용자가 직접 전달한 진술을 수집자가 옮긴 것이며, 별도의 서명·녹화 원본은 아니다.

## 2026-10-20 후속 확인

> 내가 실제 테스트하면서 LED나 컨배이어밸트 운직이는거 다 확인했어

분류: **사용자관찰**. 실제 시험에서 LED 표시와 컨베이어 동작을 확인했다는 시험 묶음 단위 관찰로 연결한다. 통신 ACK에서 추정한 관찰이 아니다. 이 확인은 7건 증빙을 정리하는 현재 문맥에서 받은 확인이다. 검사 ID마다 색상·시각·모터 신호를 따로 확인했다고 확대하지 않는다. 원문에는 구체적인 LED 색상이 없으므로 색상은 새로 지정하지 않는다.

기존 원장의 `plc_consumption_confirmed=false`, `ack_scope=CYCLIC_SEND_AND_REQUEST_RESET_ONLY`는 수정하지 않았다. 이 값은 자동 피드백의 범위를 나타내며, 별도로 확보한 위 사용자 관찰을 취소하지 않는다.

## 당시 모형 준비와 종료

기존 대화에서 정상 모형과 오른쪽 파이프만 빠진 모형 준비 여부에 사용자는 “둘 다 준비됐어요”라고 답했고, 정상→오른쪽 파이프 결품을 반복하는 안내 후 “이정도 확인했으면 됬어”라고 종료했다. 후자는 `sources/field_ten/FINAL_SUMMARY.json`에도 저장돼 있다.
사전 `EXPECTED_SEQUENCE.json`과 7건 결과는 일치한다. 개별 검사 ID의 투입 상태를 예측값으로 역산하지 않았고, 각 투입을 별도로 재확인한 기록이나 동영상은 미확보다.
''')
before_plc=before['state']['plc']['snapshot'];after_plc=after['state']['plc']['snapshot']
window_start=min(r['accepted_at'] for r in results);window_end=max(r['plc_completion_event_at'] for r in results)
window_events=[e for e in events if window_start<=e['occurred_at']<=window_end]
write('trial_reconciliation.json',{'ids':ids,'before_after_new_ids':sorted(set(after['inspection_ids'])-set(before['inspection_ids'])),'planned':10,'actual':7,'user_ended_early':summary['user_ended_trial'],'decisions':dict(Counter(r['final_decision'] for r in results)),'basis':'Saved snapshot ID difference, request IDs 1–7, database records, completion events, PLC cumulative counters','before_plc':before_plc,'after_plc':after_plc,'counter_deltas':{k:after_plc[k]-before_plc[k] for k in ('request_id','result_count','done_count','completed_count','rejected')},'inspection_state_counts':dict(Counter(r['state'] for r in tables['inspections'])),'event_types_in_completed_window':dict(Counter(e['event_type'] for e in window_events)),'window_start_utc':window_start,'window_end_utc':window_end,'checks':checks,'stored_originals':21,'stored_overlays':7,'physical_observation_level':'USER_OBSERVATION','per_id_video_observation':False,'new_test':False,'source_missing':source_missing})
write('provenance_index.json',provenance)
print(json.dumps({'inspections':len(results),'assets_manifest_rows':len(assets),'source_code_hash_matches':sum(c['match'] for c in source_code_checks),'source_code_count':len(source_code_checks),'source_missing':source_missing,'detail_keys':checks[0]['detail_keys'],'search_keys':checks[0]['search_keys'],'release_diff_files':len(diff),'metrics':metrics},ensure_ascii=False))
