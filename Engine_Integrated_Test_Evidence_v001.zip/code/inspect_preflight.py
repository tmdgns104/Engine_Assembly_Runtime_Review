from pathlib import Path
import json
P=Path('D:/OneDevice_Team_project');W=P/'runs/config_ui_history_20261018';O=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text('utf-8'))
a=read(W/'field_ten/AFTER_20261018T092246_484843Z.json')
for p in [W/'transition/AFTER_REBOOT_PROOF.json',W/'ui_transition/DEPLOYMENT.json']:
 d=read(p);print(p.name,{k:d.get(k) for k in ('changed','release_id','change')})
 if 'release' in d:print('release',str(d['release'])[:1000])
r=a['records'][0];p=r['row']['package_json'];print('package fields',list(p)); print('config', {k:v for k,v in p['configuration'].items() if k!='values'})
print('request keys',list(r['row']['request_json']));print('backend',r['row']['result_json']['backend'])
for n in ('detail','search'):
 d=read(O/f'queries/{r["row"]["inspection_id"]}_{n}.json');print(n,'keys',list(d));print(n,'head',str(d)[:500])
print('inspection_ids_diff',len(set(a['inspection_ids'])-set(read(W/'field_ten/BEFORE.json')['inspection_ids'])))
print('recordings summaries')
inv=read(P/'docs/evaluation_assets/20261019/asset_inventory.json')
for key in ('recordings','field_evaluation','additional_evidence'):
 d=inv.get(key);print(key,str(d)[:2500])
print('selected manifest',p['manifest'])
print('m2 fields',[(k,v) for k,v in p.items() if 'envelope' in k or 'hash' in k])
print('frame keys',list(r['row']['result_json']['frames'][0]))
