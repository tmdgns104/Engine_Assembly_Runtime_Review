from pathlib import Path
import csv,json,zipfile
R=Path('D:/OneDevice_Team_project');O=Path(__file__).resolve().parents[1]
summary=json.loads((R/'runs/config_ui_history_20261018/field_ten/FINAL_SUMMARY.json').read_text('utf-8'))
ids={x['inspection_id'] for x in summary['records']}
with (R/'docs/evaluation_assets/20261019/inspection_assets_local_matches.csv').open(encoding='utf-8-sig',newline='') as f:
 matches=[x for x in csv.DictReader(f) if x['inspection_id'] in ids]
(O/'local_asset_candidates.json').write_text(json.dumps(matches,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'local_matches':len(matches),'examples':matches[:2]},ensure_ascii=False))
p=Path('D:/머신러닝_학습자료/비전검사 푸셔없는버전 4 .smc2')
print(json.dumps({'plc_bytes':p.stat().st_size,'is_zip':zipfile.is_zipfile(p)},ensure_ascii=False))
if zipfile.is_zipfile(p):
 with zipfile.ZipFile(p) as z:
  names=z.namelist(); hits=[]
  for n in names:
   info=z.getinfo(n)
   if info.file_size>15_000_000 or n.endswith('/'):continue
   b=z.read(n)
   if any(k in b for k in (b'Sensor_Ready',b'PhotoSensor')):hits.append({'name':n,'bytes':len(b),'prefix':b[:60].decode(errors='replace')})
  print(json.dumps({'plc_entries':len(names),'matching_entries':hits[:15]},ensure_ascii=False))
  (O/'plc_archive_index.json').write_text(json.dumps({'path':str(p),'entries':names,'matching_entries':hits},ensure_ascii=False,indent=2),encoding='utf-8')
