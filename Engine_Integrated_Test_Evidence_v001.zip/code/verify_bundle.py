"""파일 대조·관계 검증·ZIP 검증. 운영 장비에 접속하거나 상태를 바꾸지 않는다."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import csv,hashlib,json,re,zipfile,sys
from PIL import Image

O=Path(__file__).resolve().parents[1];ZIP=O.with_suffix('.zip')
now=lambda:datetime.now(timezone.utc).isoformat()
def read(rel):return json.loads((O/rel).read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def csv_read(rel):
    with (O/rel).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(rel,v):(O/rel).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
errors=[];checks={}
def check(name,condition,detail=None):
    checks[name]={'pass':bool(condition),'detail':detail}
    if not condition:errors.append(name)
data=read('db/selected_rows.json');results=csv_read('inspection_results.csv');ids=[r['inspection_id'] for r in results]
lookup={r['inspection_id']:r for r in data['inspections']};assets=csv_read('asset_manifest.csv');provenance=read('provenance_index.json')
check('seven_unique_inspections',len(ids)==len(set(ids))==7)
check('four_pass_three_fail',Counter(r['final_decision'] for r in results)=={'PASS':4,'FAIL':3})
image_rows=[r for r in assets if r['role'] in ('raw','overlay')]
check('twenty_one_originals_seven_overlays',Counter(r['role'] for r in image_rows)=={'raw':21,'overlay':7})
decoded=[];hashchecks=[]
for asset in assets:
    p=O/asset['bundle_path'];ok=p.is_file() and p.stat().st_size==int(asset['bytes']) and sha(p)==asset['sha256']
    if asset['ledger_sha256']:ok=ok and sha(p)==asset['ledger_sha256']
    hashchecks.append(ok)
    if asset['role'] in ('raw','overlay'):
        with Image.open(p) as im:
            dims=im.size;im.verify()
        decoded.append({'path':asset['bundle_path'],'dimensions':list(dims),'valid':dims==(int(asset['width']),int(asset['height']))})
check('all_asset_hashes_and_sizes',all(hashchecks),len(hashchecks))
check('images_decode_and_dimensions',all(x['valid'] for x in decoded),decoded)
check('raw_files_unique',len({x['sha256'] for x in assets if x['role']=='raw'})==21)
sourcechecks=[]
for rel,entry in provenance.items():
    p=O/rel
    if entry['method']=='BYTE_COPY':ok=Path(entry['source_path']).is_file() and sha(entry['source_path'])==sha(p)==entry['source_sha256']
    elif entry['method'] in ('REMOTE_BYTE_COPY','READ_ONLY_HTTP_GET'):ok=sha(p)==entry['source_sha256']
    else:continue
    sourcechecks.append({'path':rel,'method':entry['method'],'match':ok})
check('source_copy_hashes',all(x['match'] for x in sourcechecks),sourcechecks)
linked=[];frame_ids=[]
state={x['key']:json.loads(x['value']) for x in data['service_state']}
for r in results:
    ident=r['inspection_id'];row=lookup[ident];original=json.loads(row['result_json']);final=read(r['final_path'])
    detail=read(r['query_detail_path']);search=read(r['query_search_path'])
    own=[x for x in search['items'] if x['inspection_id']==ident]
    query_ok=(detail['inspection_id']==ident and detail['decision']==row['decision'] and detail['state']==row['state'] and detail['result']==original and len(own)==1 and own[0]['decision']==row['decision'])
    field_copy=read(r['result_path'])==original
    db_final=state.get('integrated_decision:'+ident)
    final_equal=(db_final==final)
    linked.append({'inspection_id':ident,'api_same_id_and_full_result_equals_snapshot':query_ok,'exported_result_equals_snapshot':field_copy,'historical_final_equals_db_final':final_equal,'plc_consumption_false_preserved':final['plc_consumption_confirmed'] is False,'raw_count':sum(x['role']=='raw' and x['inspection_id']==ident for x in assets)})
    frame_ids.extend(x['frame_id'] for x in original['frames'])
check('query_and_db_links',all(x['api_same_id_and_full_result_equals_snapshot'] and x['exported_result_equals_snapshot'] and x['historical_final_equals_db_final'] and x['plc_consumption_false_preserved'] and x['raw_count']==3 for x in linked),linked)
check('twenty_one_distinct_frame_ids',len(frame_ids)==len(set(frame_ids))==21)
recovery=read('remote_recovery_receipt.json')
check('fourteen_successful_gets',len(recovery['queries'])==14 and all(q.get('http_status')==200 for q in recovery['queries']))
refs=[]
ref_columns={'inspection_results.csv':['plc_evidence_path','raw_paths','overlay_paths','result_path','final_path','reference_path','query_detail_path','query_search_path','timing_definitions_path','device_observation_path'], 'asset_manifest.csv':['bundle_path'], 'evidence_map.csv':['bundle_paths'],'timing_summary.csv':['definition_path']}
for name,columns in ref_columns.items():
    for n,row in enumerate(csv_read(name),2):
        for col in columns:
            for rel in row[col].split('|'):
                p=(O/rel).resolve();ok=O in p.parents and p.is_file();refs.append({'csv':name,'row':n,'field':col,'path':rel,'exists':ok})
check('csv_references',all(x['exists'] for x in refs),{'count':len(refs),'missing':[x for x in refs if not x['exists']]})
# 본문의 상대 링크를 ZIP 내에서 검사한다. 외부 URL은 파일 검사 대상이 아니다.
md_missing=[];md_links=0
for p in O.glob('*.md'):
    for rel in re.findall(r'\]\(([^)]+)\)',p.read_text('utf-8')):
        if '://' in rel:continue
        md_links+=1
        if not (p.parent/rel.split('#',1)[0]).exists():md_missing.append({'file':p.name,'target':rel})
check('markdown_links',not md_missing,{'count':md_links,'missing':md_missing})
link=read('release_linkage.json');check('tested_runtime_hashes',all(x['match'] for x in link['trial_source_files']),len(link['trial_source_files']))
check('only_ui_release_diff',len(link['file_manifest_diff'])==2 and link['current_manifest_matches_ui_manifest'])
check('snapshot_unchanged_and_integrity',read('db/export_verification.json')['source_sha256_before']==read('db/export_verification.json')['source_sha256_after'] and read('db/export_verification.json')['source_integrity']=='ok')

# 인증값 후보 키를 확인한다. request_token은 PLC 거래 식별자이며 인증 토큰이 아니다.
sensitive_keys={'password','passwd','api_key','access_token','refresh_token','auth_token','authorization','session_token','private_key','cookie','session_cookie','client_secret'}
secret_candidates=[]
def scan(v,path,file):
    if isinstance(v,dict):
        for k,val in v.items():
            if k.lower() in sensitive_keys and val not in (None,'',False,[],{}):secret_candidates.append({'file':file,'key':path+'.'+k})
            scan(val,path+'.'+k,file)
    elif isinstance(v,list):
        for i,val in enumerate(v):scan(val,f'{path}[{i}]',file)
    elif isinstance(v,str) and v[:1] in ('{','['):
        try:scan(json.loads(v),path+'(json)',file)
        except (ValueError,RecursionError):pass
for p in O.rglob('*.json'):
    if p.name in ('bundle_manifest.json','verification.json'):continue
    scan(json.loads(p.read_text('utf-8-sig')),'$',p.relative_to(O).as_posix())
private_markers=[]
for p in O.rglob('*'):
    if p.suffix.lower() not in ('.txt','.json','.jsonl','.py','.md','.sql','.csv','.js','.html'):continue
    if re.search(rb'-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----',p.read_bytes()):private_markers.append(p.relative_to(O).as_posix())
check('no_nonempty_secret_keys_or_private_key_content',not secret_candidates and not private_markers,{'candidate_paths':secret_candidates,'private_key_markers':private_markers,'scope':'JSON keys including nested JSON TEXT and text private-key headers; semantic source review; not a universal secret detector'})
verification={'task':'EXISTING_INTEGRATION_EVIDENCE_COLLECTION','verified_at':now(),'status':'PASS' if not errors else 'FAIL','new_physical_test_performed':False,'user_observation_confirmed':'LED and conveyor operation; trial-level retrospective statement','independent_per_id_motion_video':'NOT_SECURED','checks':checks,'errors':errors,'zip_verification':{'status':'PENDING'}}
write('verification.json',verification)
if errors:
    print(json.dumps({'status':'FAIL','errors':errors,'secret_candidate_paths':secret_candidates,'link_checks':linked},ensure_ascii=False));raise SystemExit(1)
print(json.dumps({'status':'EVIDENCE_CHECKS_PASS','checks':len(checks),'csv_reference_count':len(refs),'source_copy_count':len(sourcechecks)},ensure_ascii=False))
if '--audit-only' in sys.argv:raise SystemExit(0)

excluded={'bundle_manifest.json','verification.json'}
manifest=[]
for p in sorted(O.rglob('*')):
    if not p.is_file() or p.name in excluded:continue
    rel=p.relative_to(O).as_posix();src=provenance.get(rel,{})
    manifest.append({'relative_path':rel,'source_path':src.get('source_path','generated:'+rel),'bytes':p.stat().st_size,'sha256':sha(p),'method':src.get('method','TASK_GENERATED'),'source_sha256':src.get('source_sha256')})
write('bundle_manifest.json',{'created_at':now(),'files':manifest,'excluded_self_describing_files':sorted(excluded),'note':'Excluded self files are still included in ZIP set/CRC/byte verification. Derived files retain original source references in their contents and build code.'})
def members():return sorted(p for p in O.rglob('*') if p.is_file())
def create_zip():
    with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in members():z.write(p,p.relative_to(O).as_posix())
def verify_zip():
    files={p.relative_to(O).as_posix():p for p in members()}
    with zipfile.ZipFile(ZIP) as z:
        assert len(z.namelist())==len(set(z.namelist()))
        assert set(z.namelist())==set(files)
        assert z.testzip() is None
        for name,p in files.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
    return len(files)
if ZIP.exists():raise FileExistsError('Existing ZIP preserved: '+str(ZIP))
create_zip();n=verify_zip()
verification['zip_verification']={'status':'PASS','members':n,'exact_file_set':True,'crc':True,'member_sha256_equals_folder':True,'includes_manifest_and_verification':True,'procedure':'Check provisional ZIP, embed receipt, rebuild ZIP, verify complete final bytes again. Final ZIP SHA and post-rebuild check are in sibling ZIP_RECEIPT.json.'}
write('verification.json',verification)
create_zip();assert verify_zip()==n
receipt={'zip_path':str(ZIP),'bytes':ZIP.stat().st_size,'mib':round(ZIP.stat().st_size/1048576,2),'files':n,'sha256':sha(ZIP),'verified_at':now(),'exact_file_set':True,'crc_pass':True,'all_member_sha256_match':True,'final_verification_json_sha256':sha(O/'verification.json'),'evidence_collection_complete':True,'new_field_test':False}
(O.parent/(O.name+'_ZIP_RECEIPT.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(receipt,ensure_ascii=False))
