"""선택된 7건의 기존 파일과 GET 이력만 회수한다. 장치 상태는 변경하지 않는다."""
from pathlib import Path
import hashlib, io, json, subprocess, tarfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
PROJECT = Path('D:/OneDevice_Team_project')
basis = json.loads((PROJECT/'runs/config_ui_history_20261018/field_ten/AFTER_20261018T092246_484843Z.json').read_text('utf-8'))
items = []
for rec in basis['records']:
    ident = rec['row']['inspection_id']
    for asset in rec['assets']:
        items.append({'relative': asset['relative_path'], 'output': asset['relative_path'], 'sha256': asset['sha256'], 'inspection_id': ident, 'kind': asset['kind']})
    items.append({'relative': f'assembly/{ident}/result.json', 'output': f'assets/{ident}/assembly/result.json', 'sha256': None, 'inspection_id': ident, 'kind': 'existing_assembly_json'})
ids = [r['row']['inspection_id'] for r in basis['records']]
remote = r'''
import pathlib, io, tarfile, json, hashlib, datetime, urllib.request, os
base=pathlib.Path('/home/jetson/oned_device_bench/data/engine_dynamic_pose_002').resolve()
now=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt={'observed_at':now(),'mode':'READ_ONLY_EXISTING_FILES_AND_HTTP_GET','files':[],'queries':[],'missing':[]}
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tf:
 def add(name,data):
  ti=tarfile.TarInfo(name); ti.size=len(data); tf.addfile(ti,io.BytesIO(data))
 for item in ITEMS:
  p=(base/item['relative']).resolve()
  if base not in p.parents: raise ValueError('Path outside allowlisted data root')
  if not p.is_file(): receipt['missing'].append({'path':str(p),'reason':'FILE_NOT_FOUND'}); continue
  if p.stat().st_size>15_000_000: raise ValueError('Unexpected asset size')
  data=p.read_bytes(); sha=hashlib.sha256(data).hexdigest()
  receipt['files'].append(dict(item,source=str(p),bytes=len(data),actual_sha256=sha,ledger_match=(sha==item['sha256']) if item['sha256'] else None))
  add(item['output'],data)
 for ident in IDS:
  for label,url in [('detail',f'http://127.0.0.1:18771/api/v1/history/{ident}'),('search',f'http://127.0.0.1:18771/api/v1/history?q={ident}&limit=10')]:
   q={'inspection_id':ident,'kind':label,'url':url,'queried_at':now(),'method':'GET'}
   try:
    with urllib.request.urlopen(url,timeout=8) as response:
     data=response.read(4_000_001);q['http_status']=response.status
    if len(data)>4_000_000: raise ValueError('Response too large')
    output=f'queries/{ident}_{label}.json';add(output,data);q.update(output=output,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
   except Exception as e:q['error']=type(e).__name__+': '+str(e)
   receipt['queries'].append(q)
 current=pathlib.Path('/home/jetson/oned_device_bench/current')
 receipt['current_release_path']=str(current.resolve())
 receipt['hostname']=pathlib.Path('/etc/hostname').read_text().strip()
 receipt['boot_id']=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()
 receipt['finished_at']=now()
 add('remote_recovery_receipt.json',json.dumps(receipt,ensure_ascii=False,indent=2).encode('utf-8'))
import sys
sys.stdout.buffer.write(buf.getvalue())
'''
source = 'ITEMS='+repr(items)+'\nIDS='+repr(ids)+'\n'+remote
ssh = ['ssh','-i',str(Path.home()/'.ssh/oned_device_jetson_bench_ed25519'),'-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=10','jetson@100.119.148.89','/home/jetson/oned_device_bench/envs/app_v1/bin/python','-B','-']
start=datetime.now(timezone.utc).isoformat()
proc=subprocess.run(ssh,input=source.encode('utf-8'),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
(ROOT/'logs').mkdir(exist_ok=True)
log={'started_at':start,'ended_at':datetime.now(timezone.utc).isoformat(),'returncode':proc.returncode,'stderr':proc.stderr.decode('utf-8',errors='replace'),'stdout_bytes':len(proc.stdout),'operations':['read existing files','HTTP GET history','read hostname/boot_id/current symlink']}
(ROOT/'logs/recovery_execution.json').write_text(json.dumps(log,ensure_ascii=False,indent=2),'utf-8')
if proc.returncode: raise SystemExit('Read-only recovery failed: '+log['stderr'][-1500:])
with tarfile.open(fileobj=io.BytesIO(proc.stdout),mode='r:') as tf:
    for member in tf.getmembers():
        dest=(ROOT/member.name).resolve()
        if ROOT not in dest.parents or not member.isfile(): raise ValueError('Invalid archive member')
        data=tf.extractfile(member).read()
        if dest.exists() and dest.read_bytes()!=data: raise FileExistsError(dest)
        dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data)
receipt=json.loads((ROOT/'remote_recovery_receipt.json').read_text('utf-8'))
assert all(f['ledger_match'] is not False for f in receipt['files'])
print(json.dumps({'files':len(receipt['files']),'ledger_hash_matches':sum(f['ledger_match'] is True for f in receipt['files']),'missing':receipt['missing'],'http_ok':sum(q.get('http_status')==200 for q in receipt['queries']),'current_release':receipt['current_release_path']},ensure_ascii=False))
