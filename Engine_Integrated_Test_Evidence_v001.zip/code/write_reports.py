"""검증 가능한 표와 한국어 안내를 생성한다. 새 평가/추론은 수행하지 않는다."""
from pathlib import Path
from datetime import datetime,timedelta,timezone
import csv,json
O=Path(__file__).resolve().parents[1]
def read(rel):return json.loads((O/rel).read_text('utf-8-sig'))
def rows(rel):
    with (O/rel).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(rel,text):(O/rel).write_text(text,encoding='utf-8')
def csv_write(rel,data):
    with (O/rel).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
r=rows('inspection_results.csv');rec=read('trial_reconciliation.json');link=read('release_linkage.json');db=read('db/selected_rows.json')
time_rows=rows('timing_summary.csv');q=read('remote_recovery_receipt.json');current=read('queries/current_operating_observation.json')
kst=lambda t:datetime.fromisoformat(t).astimezone(timezone(timedelta(hours=9))).isoformat(timespec='milliseconds')
table='\n'.join(f"| {x['number']} | `{x['inspection_id']}` | {'정상' if x['input_state']=='NORMAL' else '오른쪽 파이프 결품'} | {x['basic_decision']} / {x['final_decision']} | {x['basic_reason']} | {x['plc_result_value']} · 완료 | 3장 / 저장 완료 |" for x in r)
timing_labels={'journal_elapsed_ms':'기본 검사 원장 수락→기본 결과 완료 시각','request_to_three_frames_ms':'검사 요청 기준→새 원본 3장 확보','request_to_durable_result_ms':'검사 요청 기준→기본 결과 영속 저장 완료','storage_commit_ms':'기본 결과 저장 커밋 구간','integrated_elapsed_ms':'PLC 주기 수락→통합 최종판정 생성','request_to_publication_ms':'PLC 주기 수락→결과 게시 호출 직후','request_to_plc_completion_event_ms':'PLC 주기 수락→Result/Done·요청 해제 관측 이벤트'}
timing_table='\n'.join(f"| {timing_labels[x['field']]} | {float(x['min_ms'])/1000:.3f} | {float(x['mean_ms'])/1000:.3f} | {float(x['max_ms'])/1000:.3f} |" for x in time_rows)
write('README_KO.md',f'''# 엔진 모형 통합 테스트 — 기존 증빙 묶음

작성일: 2026-10-20. 대상 시험일: 2026-10-18. 이번 작업은 **기존 증빙 수집·대조·압축**이며 새 실물시험을 수행하지 않았다.

## 1. 확인된 성과

| 항목 | 확보 결과 | 근거와 확인 수준 |
|---|---|---|
| 실제 검사 연결 | 정상 투입 계획 4건 PASS, 오른쪽 파이프 결품 계획 3건 FAIL. 총 7건이 사전 순서와 일치 | 당시 순서표·검사 원장·최종 결과. **원문기록**. 정답은 예측에서 역산하지 않음 |
| 원본 보존 | 원본 PNG 21장 + 표시 JPG 7장, 28/28 원장 SHA-256 일치 | `assets/`, `asset_manifest.csv`. **실파일대조** |
| 저장·조회 | 7건 COMPLETE·storage_success=true. SQLite snapshot의 동일 ID·관련 이벤트와 대조. 현재 상세/검색 GET 14회 모두 HTTP 200 | `db/`, `queries/`. **원문기록·실파일대조** |
| PLC 연계 | 요청 1–7, Result 7·Done 7·완료 7, 요청 LOW 복귀. 7개의 완료 이벤트 연결 | 당시 전후 snapshot, 검사별 이벤트. **통신 기록** |
| 현장 작동 | 사용자가 실제 시험 중 LED와 컨베이어 동작을 모두 확인했다고 후속 확인 | [사용자 관찰 원문](user_observations.md). **사용자관찰** |
| 웹 표시 | 실제 저장된 2번 검사 ID의 부품 위치 사진·RIGHT_PIPE_MISSING·FAIL 화면 확보 | [기존 Jetson 화면](sources/screens/UI_CROP_JETSON.png). **화면 관찰**; 실물 이동영상은 아님 |

7건 중 제품 FAIL 3건은 결품 검출 결과이며 시험 실패 3건이 아니다. 기본 검사와 최종 판정의 REVIEW/ERROR는 0건이다. 참고 오조립 분석은 7건 모두 REVIEW로 남아 있고 최종 PASS/FAIL에 영향을 주지 않았다.

## 2. 시험 조건과 범위

- 시험 실행본: **`engine-integrated-4c4b935f8ab0404a`**. boot ID `{rec['checks'] and read('sources/field_ten/FINAL_SUMMARY.json')['boot_id']}`.
- 계획: 정상→오른쪽 파이프 결품 10회. 사용자가 조기 종료하여 **실제 7회**가 저장됐다. 10회·30회 또는 장시간 신뢰성 인증으로 표현하지 않는다.
- 기록 구간: 첫 검사 수락 **{kst(rec['window_start_utc'])}**, 마지막 PLC 주기 완료 이벤트 **{kst(rec['window_end_utc'])}** (한국 시각). 투입 시작/배출 종료의 별도 실물 타임코드는 없다.
- 단일 boot, 같은 실행본·카메라 Worker·PLC 연결의 7건이라는 당시 요약을 전후 ID 차이, 요청 번호 1–7, 누적 카운터 0→7, 동일 모델/설정값으로 대조했다. 선택 구간 7건 모두 COMPLETE이며 전후 rejected 증가는 0이다. 이 구간 밖 실패를 합산하거나 누락된 시도를 성공으로 추가하지 않았다.
- 투입 정답 근거: 사전 `EXPECTED_SEQUENCE.json`, 두 모형 준비에 대한 사용자 확인, 당시 결과 요약. 개별 ID별 실제 투입 상태를 독립 촬영한 영상/별도 확인표는 없다. 따라서 “7/7 계획 순서 일치”와 독립적인 일반 정확도 평가는 구분한다.
- 카메라 기록: 1280×720 원본, 기존 GStreamer/단일 Worker, 연속 원본 3장. 당시 설정 전체는 각 검사의 `package_json`과 `result_json`에 보존했다. 새 촬영·추론·평가·모델 변환은 하지 않았다.
- 운영 정책: `BASIC_PRESENCE_ASSEMBLY_REFERENCE_V2`. 미결합 검사가 최종판정을 결정하며 오조립은 참고 전용이다.

## 3. 검사별 결과

| 순번 | inspection_id | 사전 투입 상태 | 기본 / 최종 | 기본 사유 | PLC Result · 주기 | 원본 / DB |
|---|---|---|---|---|---|---|
{table}

전체 필드·정확한 시각·경로는 [inspection_results.csv](inspection_results.csv)에 있다. 각 `assets/<ID>/`에는 기존 원본 3장·표시 이미지 1장, 기존 참고 분석 `assembly/result.json`, DB 기본 결과 내보내기 `db_result.json`, 기존 최종판정 내보내기 `integrated_final.json`이 있다. 원본은 이름·바이트를 유지했으며 표시 이미지나 crop을 검사 원본으로 대체하지 않았다.

## 4. 운영본·모델·설정 연결

| 구분 | 식별 및 근거 |
|---|---|
| 7회 시험본 | `engine-integrated-4c4b935f8ab0404a`, `sources/transition/AFTER_REBOOT_PROOF.json`, 당시 field snapshot |
| 이후 UI 운영본 | `engine-integrated-32c484ac6aeb07f1`, `sources/ui_transition/DEPLOYMENT.json` |
| 변경 범위 | release manifest 대조 결과 `current/apps/edge_service/line_details.js`, `current/apps/edge_service/line_hmi.html` 2개만 변경. 저장 사진 crop, 미결합 강조, 참고 글씨 축소 |
| 현재 읽기 조회 | {current['observed_at']}에 `{current['release']['release_id']}` 관측. service active/running. release 파일 목록은 기존 UI 릴리스와 일치. 새 검사 성공을 의미하지 않음 |
| M1 | `dynamic_parts_005` / `CFA8507_original_PT_fp16_head32`, TensorRT artifact SHA `{r[0]['m1_model_sha256']}` |
| M2 | `envelope_v007_fp16`, TensorRT artifact SHA `{r[0]['m2_model_sha256']}` |
| 시험 시 유효 설정 | process settings SHA `{r[0]['configuration_effective_sha256']}`; 각 검사 결과의 package/configuration과 backend에 기록 |
| 현재 standalone.json 파일 | 바이트 SHA `{current['configuration_sha256']}`. process settings 해시와 입력 범위가 다르므로 해시 문자열 차이를 설정 변경으로 해석하지 않음 |

[release_linkage.json](release_linkage.json), [release_file_changes.csv](release_file_changes.csv)에 연결과 파일별 해시를 기록했다. 당시 운영 코드 8개도 release manifest 해시와 일치한다. **7회 실물시험을 32c4에서 다시 수행한 것으로 쓰지 않는다.** 기존 19일 Benchmark 후 원복·모델 해시 관측은 부록에 있고, 20일 조회만으로 모델 바이너리를 재측정했다고 하지 않는다.

## 5. DB·웹·PLC 증거 읽는 방법

`db/source_snapshot_receipt.json`의 기존 일관된 SQLite backup() snapshot을 `mode=ro&immutable=1`, `query_only=ON`으로 읽었다. 원본 94,973,952바이트 DB의 전후 SHA가 같고 integrity_check=ok다. 전체 DB 대신 선택된 검사 7행, 결품 3행, 자산 28행, 관련 이벤트 55행, outbox 55행, 주기 7행, service_state 14행 및 스키마·조회문을 넣었다. 관련 이벤트 안의 이전 검사 참조와 주대상 ID는 `db/event_links.json`에서 구분한다. 전체 DB 368건은 이 시험의 평가 분모가 아니다.

`queries/`는 **{q['observed_at']} 이후** 수행한 기존 이력의 GET 결과다. 검사일은 18일이며 조회일은 20일이다. 현재 화면을 과거 실물 영상으로 사용하지 않았다. `UI_CROP_JETSON.png`에는 2번 ID가 실제로 보인다. 기존 `UI_DETAIL_VERIFIED.txt`·`UI_FILTER_VERIFIED.txt`는 다른 검사 ID의 UI 기능 확인이므로 이번 7건의 조회 근거는 새 GET 응답으로 연결한다. PC 수집 상태가 PENDING인 필드도 원문대로 남기며, 이번 증빙 회수를 과거 자동 PC 수집 성공으로 바꾸지 않는다.

PLC 저장 소스 `비전검사 푸셔없는버전 4 .smc2`와 23 rung을 포함했다. `PLC_LINKAGE_KO.md`는 저장 소스상 기대 동작, 통신 기록, 사용자 현장 관찰을 분리한다. 온라인 PLC 전체 프로그램과 저장 소스가 완전히 같은지는 별도 미확인이다. 푸셔·자동 분리 장치는 가정하지 않는다.

원장 `plc_consumption_confirmed=false`는 자동 소비 피드백 미확인을 나타낸다. 이를 true로 바꾸지 않았으며, 사용자의 **“실제 테스트하면서 LED나 컨배이어밸트 운직이는거 다 확인했어”**라는 현장 관찰을 별도로 연결했다. 독립 전기 피드백이나 ID별 타임코드가 없다는 사실과 사람이 동작을 확인했다는 사실은 양립한다.

## 6. 응답시간 — 측정 구간별 구분

단위: 초. 기존 7건 기록만 집계. 아래 값은 모델 단독 추론 시간이 아니다.

| 측정 구간 | 최소 | 평균 | 최대 |
|---|---:|---:|---:|
{timing_table}

기본 원장 완료 시각과 실제 영속 저장 커밋은 다른 필드다. 통합판정 생성·게시·PLC 완료 이벤트도 분리했다. PLC 완료 이벤트까지의 시간은 저장된 같은 Jetson monotonic 시계 값으로 계산한 소프트웨어 관측 지연이며 LED/모터 작동 시각은 아니다. 실제 정의와 원문 필드는 [TIME_AND_FIELD_MAP_KO.md](TIME_AND_FIELD_MAP_KO.md)에 있다.

## 7. 적용 범위와 보완

이번 묶음으로 7건의 요청→사진→기본/최종판정→PLC 통신 완료→저장·조회와 사용자 현장 관찰을 설명할 수 있다. 해당 7회에 연결된 **실물 동작 영상은 미확보**다. 빈 벨트 220프레임, 다른 날짜 자료, Benchmark 저장사진을 7회 동작 영상으로 사용하지 않았다. 과거 오조립 참고 분석 REVIEW·제품 추적 진단도 그대로 보존했다. 반복 추적 경고가 있어도 해당 7건의 제품 검사 ERROR와 혼동하지 않는다.

이 자료는 모든 결품 유형, 다양한 위치·각도·조명, 장시간 안정성, 현재 운영본 재시험을 입증하지 않는다. 기존 조명·위치·복구 자료의 연결 범위는 [appendix/CONTEXT_KO.md](appendix/CONTEXT_KO.md), 최대 3개의 보완 제안은 [missing_evidence.md](missing_evidence.md)에 있다. 미확보 항목을 보완하기 위한 새 조작은 이번 작업에서 수행하지 않았다.

## 8. 파일 무결성과 재현

- `bundle_manifest.json`: 각 파일의 ZIP 상대경로·원본 경로·크기·SHA-256·복사/내보내기 방법.
- `asset_manifest.csv`: 7건별 원본·표시·결과 파일 연결 및 원장 해시 일치.
- `verification.json`: 원본 대조, 표 참조, DB/조회 연결, 이미지 디코드, ZIP 파일집합·CRC·SHA 검증 결과.
- `evidence_map.csv`: 주장별 원자료와 확인 수준. `logs/`와 `code/`는 이번 수집·집계·검증 방법이다. `sources/` 안의 과거 서비스 관련 코드는 읽기 증거로만 보존했으며 실행하지 않았다.
- manifest와 verification 자신은 순환 해시를 피하기 위해 manifest의 파일별 해시 대상에서 제외한다. ZIP 검증은 두 파일을 포함한 실제 전체 파일집합으로 수행한다. ZIP 자체 SHA는 폴더 밖 영수증에 별도 기록한다.

작업 경계: 새 현장시험·카메라 촬영·PLC 출력·서비스 재시작·운영본 변경·학습·추론·Benchmark 실행 없음.
''')

write('TIME_AND_FIELD_MAP_KO.md','''# 필드·시간의 출처

| 산출 필드 | 실제 원문 / 계산 | 시간 범위 |
|---|---|---|
| input_state, expected_decision | sources/field_ten/EXPECTED_SEQUENCE.json 순번 | 투입 계획 + 사용자 모형 준비 확인. AI 예측에서 추출하지 않음 |
| basic_decision, basic_reason | inspections.decision / result_json.reason_code | 필수 부품 미결합 검사 |
| reference_assembly | 기존 final.assembly_reported + assembly/result.json | 오조립 참고; assembly_affects_final=false |
| final_decision, plc_result_value | final.decision / final.plc_result_value | 당시 최종판정, PASS=0(OK), 나머지=1(NG) |
| cyclic_done_reset_observed | 당시 state.history의 동일 ID | Result/Done·요청 LOW 복귀의 소프트웨어 관측 |
| journal_elapsed_ms | inspections.completed_at - accepted_at, UTC wall clock | 원장 수락 시각→기본 결과 완료 시각. 이후 영속 커밋까지 포함한다고 단정하지 않음 |
| request_to_three_frames_ms | result_json.request_to_three_frames_ms | Worker가 기록한 요청 기준→세 번째 새 유효 원본 확보, monotonic |
| request_to_durable_result_ms | INSPECTION_DURABLE_TIMING.payload | 기본 요청→원본/결과 영속 저장 완료, edge_monotonic |
| storage_commit_ms | 같은 이벤트 payload.storage_commit_ms | 해당 기본 결과 영속 저장 커밋. 전체 검사시간 아님 |
| integrated_elapsed_ms | final.inspection_elapsed_ms = (completed_monotonic - cycle_admission_evidence.accepted_at)*1000 | PLC 주기 수락→기본+참고 분석을 포함한 통합 최종판정 생성 |
| request_to_publication_ms | 당시 state.history / INTEGRATED_INSPECTION_COMPLETED | _publish_committed의 handshake.publish 호출 직후. PLC 내부 소비 시각 아님 |
| request_to_plc_completion_event_ms | PLC_CYCLIC_COMPLETION_OBSERVED.payload.monotonic_s - final.cycle_admission_evidence.accepted_at | 같은 Jetson monotonic 시계의 주기 수락→통신 완료 관측 이벤트 |
| query_at | remote_recovery_receipt.json | 이번 읽기 전용 HTTP GET 시각. 18일의 시험 시각과 다름 |
| device_observation | user_observations.md | 실제 시험 후 사용자의 LED/컨베이어 확인. 자동 피드백 값 변경 없음 |

원장 JSON의 request_token은 비밀 인증 토큰이 아닌 PLC boot/connection/request 거래 식별자다. 같은 검사를 연결하기 위해 보존한다. 인증 비밀번호·개인키·인증 토큰은 포함하지 않는다.

일부 이벤트는 이전 검사의 ID를 previous_transaction 안에 참조한다. event_links.json의 primary_inspection_id를 현재 사건의 주대상으로 사용하고, referenced_selected_ids는 관계 추적에만 사용한다. 다른 요청의 이벤트를 중복 성공으로 세지 않는다.

원장 raw worker의 physical_output_enabled=false는 그 Worker의 직접 물리 출력 권한 필드다. 별도 통합 PLC 경로의 Result/Done 관측과 구분한다. 이 필드만으로 전체 시스템에서 PLC 전송이 없었다고 해석하지 않는다.
''')

write('PLC_LINKAGE_KO.md','''# PLC 기대 동작 · 통신 기록 · 실제 관찰

저장 소스: `sources/plc/비전검사 푸셔없는버전 4 .smc2`, SHA-256 `c0dff344cb815ae75cffe63c21454384393061abf4fa35e7d46405033c879137`.
기존 추출본 `PLC_SAVED_LADDER_v001.json`의 source_sha256과 원본 바이트를 대조했다. 23 rung. 온라인 다운로드된 전체 프로그램 동일성은 이번 읽기 작업에서 확인하지 않았다.

| 항목 | 저장 PLC의 기대 동작 | 이번 7건의 통신 기록 | 실제 장치 관찰 |
|---|---|---|---|
| START·STOP | rung1 Stop_PB·EStop_OK 정상 회로 및 Start_PB로 Mc_Run 자기유지. Stop_PB=true는 정상/해제된 회로 | Mc_Run 운전 및 종료 정지, 요청1–7; Start_PB 자체는 Jetson에 미노출 | 당시 사용자가 START. 종료는 기존 STOP 상태 기록 |
| 이송 | rung2 Mc_Run && !Inspecting → Cv_Run | Mc_Run·검사 단계는 수집; 별도 모터 피드백 없음 | 사용자가 실제 컨베이어 동작을 모두 확인했다고 20일 진술 |
| 제품 감지 | rung3 Mc_Run·PhotoSensor·Sensor_Ready·!Jetson_Done → Move_pending; rung4 Sensor_Ready 해제 | PhotoSensor/Sensor_Ready 내부값은 현재 Jetson 인터페이스에서 직접 수집하지 않음 | 센서 접점/타임코드별 독립 관찰 미확인 |
| 정지 후 요청 | rung21~23 4.5초 Move_Timer 이후 Inspecting; rung5 정지 상태 2초 Inspect_Delay_Timer 후 Inspection_Request | 유효 요청1–7과 원본3장·검사 기록 연결 | 저장 원본은 검사 위치의 엔진을 보여 줌. 전체 이송영상 아님 |
| OK | rung10 Cycle_Done·Jetson_Done·!Jetson_Result → Normal_Memory; rung14 운전 중 Normal_lamp | PASS 4건, Result=0 | 사용자 LED 확인. 개별 ID별 색상/타임코드 진술은 없음 |
| NG | rung11 Cycle_Done·Jetson_Done·Jetson_Result → Defect_Memory; rung15 Defect_lamp | 오른쪽 파이프 결품 FAIL 3건, Result=1 | 사용자 LED 확인. 푸셔·분리 장치 가정 없음 |
| 재이송·다음 준비 | rung6~7 Done이면 Cycle_Done 및 Inspecting 해제; rung2 재이송. rung12~13 센서/Done 해제 후 Sensor_Ready 복구. rung16~20 STOP 복구 | Result/Done/완료 각7, request LOW·7개 PLC_CYCLIC_COMPLETION_OBSERVED, 다음 요청 연결 | 사용자 실제 컨베이어 동작 확인. 자동 모터 소비 피드백은 별도 미확인 |

당시 기록의 ack_scope는 CYCLIC_SEND_AND_REQUEST_RESET_ONLY, plc_consumption_confirmed는 false다. 이를 보존하고 사용자 관찰을 별도 수준으로 연결했다. 저장 PLC상 NG도 Done으로 Inspecting을 해제하여 재이송하는 구조이며, 이 자료에 자동 불량 분리/푸셔 완료를 추가하지 않는다.

이 문서는 기존 소스·기록을 설명한다. 이번 작업에서 PLC 프로그램 접속·다운로드·강제 출력·START/STOP 조작을 수행하지 않았다.
''')

write('DB_AND_QUERY_KO.md','''# DB 내보내기와 웹 조회

`db/selected_rows.json`은 기존 SQLite snapshot의 선택된 7건 및 관련 테이블 행을 원래 열 이름/값으로 내보낸 JSON이다. JSON TEXT 열은 원문 문자열을 유지한다. `db/schema.sql`은 원래 스키마이며 JSON export를 자동 운영 DB로 복구하기 위한 실행 스크립트가 아니다.

조회는 mode=ro&immutable=1, query_only=ON, 단일 읽기 트랜잭션에서 수행했다. 기존 snapshot은 당시 sqlite3.Connection.backup()으로 생성됐고 방법은 sources/historical_snapshot_post7.py, 영수증은 db/source_snapshot_receipt.json이다. 이번에는 그 코드를 실행하지 않았다. 운영 DB 본체나 WAL을 복사하지 않았으며 전체 DB를 ZIP에 포함하지 않았다.

`db/queries.sql`과 `code/build_evidence.py`가 실제 조회 조건을 설명한다. per_inspection/<ID>.json은 동일 ID 행, 직접 관련 이벤트, 당시 웹/서비스 history, 원장 asset 행을 함께 읽기 쉽게 묶은 파생 자료다. dispositions는 선택된 7건 모두 0행이며, 이 테이블에서 실제 제품 처분을 확정하지 않는다. outbox와 frame_assets의 PENDING 상태를 자동 PC 수집 완료로 바꾸지 않았다.

이번 GET은 Jetson 자체 loopback의 `/api/v1/history/<ID>` 및 `/api/v1/history?q=<ID>&limit=10`을 이용했다. 수집 일시는 remote_recovery_receipt.json, 본문은 queries/<ID>_detail.json 및 _search.json이다. 서비스 상태를 바꾸는 POST나 신규 검사 요청은 하지 않았다. HTTP 200만으로 판정 일치를 단정하지 않고 응답 ID 및 저장 내용과 원장도 대조한다.
''')

write('appendix/CONTEXT_KO.md','''# 다른 시점 자료의 적용 범위

| 자료 | 릴리스/조건 | 확인된 내용 | 이번 7건과의 관계 |
|---|---|---|---|
| FIELD_v002_FINDINGS.md | 2026-10-18, engine-integrated-9488d93c4d69566e | 별도 PASS 1건과 빈 벨트 220프레임. 요청은 녹화 종료 약14초 뒤. RUN_CAPTURE_OWNER_CHANGED는 추적 ID 해석 진단 | 다른 릴리스·다른 ID. 7회 영상이나 7건의 실패로 쓰지 않음. 당시 후보/미적용 문장은 그 기록 시점의 상태 |
| sources/field_ten/AFTER_*.json | 이번 4c4b 시험 | 이전 제품 추적 진단 PRODUCT_PASSAGE_OCCLUSION_OR_AMBIGUITY가 남지만 선택7건은 COMPLETE, 기본/최종 REVIEW·ERROR 0 | 기록 보존. 추적 진단을 삭제하거나 부품검사 실패로 재명명하지 않음 |
| benchmark_operating_after_verification.json | 2026-10-19, 32c4 운영 복구 | 모델·운영 파일 해시 유지 및 기존 운영 준비 관측 | 저장 사진 Benchmark/복구 증거이며 새 실물 이송시험 아님 |
| restore_observation_174722.json | 같은 Benchmark 후 카메라 복구 | 당시 카메라·IPC/준비 상태 관측 | 그 시점 복구 범위. 오늘 재현된 카메라 장애라고 해석하지 않음 |
| sources/inventory_selected_sections.json | 기존 녹화·현장 자산 목록 | 빈 벨트·진단·다른 시점 경로 검색 근거 | 선택7건 ID와 연계된 동작영상 미확보. 전체 영상을 복사하거나 새 촬영하지 않음 |

조명 수치·거리·허용 위치/각도 분포는 이 7회에 연결되는 계측 근거가 없어 추정하지 않았다. 더 과거의 STATIC300 참고 분류나 다른 릴리스의 반복시험 결과는 이번 정상4/결품3의 성능 분모에 넣지 않았다. 오류 대응 코드·당시 재부팅 준비 확인이 존재해도 모든 현장 장애가 해결됐다는 포괄적 보증으로 사용하지 않는다.
''')

write('missing_evidence.md','''# 현재 작성 가능한 내용과 보완 범위

## 현재 자료로 작성 가능

7건의 실제 원본/표시 이미지·기본/참고/최종 판정·PLC Result/Done/요청 해제·DB 저장·동일 ID 이력 조회를 연결할 수 있다. LED와 컨베이어 동작은 사용자의 직접 현장 관찰로 기재할 수 있다. 원장 자동 소비 확인 false와 사람 관찰은 각각 유지한다. 기존 UI 캡처의 2번 ID도 연결했다.

## 미확인 자료와 검색 범위

| 항목 | 검색/대조 위치 | 결과 |
|---|---|---|
| 선택7회 실물 동작 영상·검사별 타임코드 | 기존 asset_inventory.recordings, runs/config_ui_history_20261018/field_ten 및 UI 기록, 기존 RUN220 찾기 결과 | **실물 동작 영상 미확보**. 빈 벨트/다른 날짜 영상은 제외. 사용자 관찰은 별도로 확보 |
| 개별 ID의 독립적인 실제 투입 정답 확인표 | EXPECTED_SEQUENCE, FINAL_SUMMARY, 당시 대화의 모형 준비/종료 답변 | 순서 계획과 준비 확인은 있음. 개별 ID별 별도 수기표/영상 미확보. 예측으로 정답 생성 안 함 |
| LED 색상·모터의 ID별 자동 피드백 | 선택7건 DB, 원문 state.history, PLC 완료 이벤트, 사용자 후속 답변 | 사람은 작동을 확인했음. ID별 색상·정확한 시각·plc_consumption 자동확인은 미확인 |
| 온라인 PLC 전체 프로그램 일치 | 사용자 저장 .smc2, 기존 ladder 추출, 저장 신호/통신 기록 | 저장 소스와 추출 해시는 일치. 온라인 장치 프로그램 전체 대조 미실행 |
| 32c4 릴리스에서 동일 조건 재시험 | UI 전환 기록, 19일 Benchmark 원복, 20일 GET | UI 변경 및 이력 조회 확인. 이 7건은 4c4b 실행 기록 |
| 여러 위치/각도/조명·모든 결품·장시간 신뢰성 | 선택7건 + 기존 자산 목록의 연결 범위 | 정상/오른쪽 파이프 결품 7건 밖의 일반화 근거로 확장하지 않음 |

## 향후 보완 제안 — 이번에는 실행하지 않음

1. **추가 실물시험 + 촬영이 필요한 증거**: 최신 운영본에서 정상→오른쪽 파이프 결품→정상 3회의 요청·LED·배출·다음 운전을 하나의 동영상으로 연결. 목적은 ID별 실제 투입 정답과 물리 동작의 동시 증명이다. 필요한 장비는 기존 PLC/Jetson/카메라와 외부 촬영기기다. 사용자는 안전한 위치에서 정해진 모형을 투입하고 촬영자는 검사 ID가 보이는 화면과 설비를 타임코드로 연결한다. 승인 후 별도 작업이며 3회 영상으로 장시간 안정성을 주장하지 않는다. 과거 7회를 새 영상으로 대체하지 않는다.
2. **촬영/읽기 확인만으로 보완 가능한 증거**: 운영자가 허용한 정지 상태에서 저장 PLC 프로젝트와 실제 온라인 프로그램 식별·비교 결과를 읽기 전용으로 확인하고 캡처. 목적은 현재 저장 .smc2와 장치 프로그램 동일성 확인이다. PLC 개발 도구가 있는 노트북과 운영자 읽기 접속이 필요하다. 다운로드/출력 강제 없이 비교 화면과 프로젝트 해시를 남긴다. 이것만으로 PLC 내부 소비 신호의 당시 타임코드가 새로 생기는 것은 아니다.

필요한 증거가 이미 확보되면 단순 횟수 채우기를 위해 기존 시험을 반복할 필요는 없다.
''')

evidence=[]
for x in r:
    ident=x['inspection_id']
    for claim,source,level,scope in [
      ('투입 기대 상태','sources/field_ten/EXPECTED_SEQUENCE.json','원문기록','순서 계획·준비 확인; 독립 ID별 정답 확인과 구분'),
      ('기본·최종 판정 및 저장',f'db/per_inspection/{ident}.json','원문기록','기본·참고·최종 역할 구분'),
      ('원본 3장 및 표시 이미지',x['raw_paths']+'|'+x['overlay_paths'],'실파일대조','원장 SHA와 회수본 일치'),
      ('PLC 통신 완료',f'db/per_inspection/{ident}.json','원문기록','Result/Done/request reset; 내부 소비 자동확인 false'),
      ('동일 ID 상세·검색 조회',x['query_detail_path']+'|'+x['query_search_path'],'원문기록','20일 GET, 18일 시험과 구분'),
      ('LED 및 컨베이어 실제 동작','user_observations.md','사용자관찰','시험 묶음 단위 진술; ID별 색상/타임코드로 확대 안 함')]:
        evidence.append({'claim':claim,'inspection_id':ident,'bundle_paths':source,'verification_level':level,'scope':scope})
evidence.extend([
 {'claim':'저장된 검사 UI 화면','inspection_id':r[1]['inspection_id'],'bundle_paths':'sources/screens/UI_CROP_JETSON.png','verification_level':'화면관찰','scope':'스크린샷의 ID·RIGHT_PIPE_MISSING·FAIL 직접 확인; 실물 이동영상 아님'},
 {'claim':'운영본 표시 변경 2파일','inspection_id':'ALL_7','bundle_paths':'release_linkage.json|release_file_changes.csv','verification_level':'실파일대조','scope':'release manifest와 당시 코드 해시; 새 릴리스 재시험 아님'},
 {'claim':'실물 동작 영상','inspection_id':'ALL_7','bundle_paths':'missing_evidence.md|sources/inventory_selected_sections.json','verification_level':'미확인','scope':'연결된 기존 영상 미확보; 사용자 관찰 있음'}])
csv_write('evidence_map.csv',evidence)
write('visual_review.json',json.dumps({'reviewed_originals':[{'inspection_id':r[0]['inspection_id'],'path':'assets/'+r[0]['inspection_id']+'/94dbb66f2fc14e879affbaa63964d2f0.png','observation':'엔진과 두 파이프·배기·문양이 보이는 정상 사례 원본'}, {'inspection_id':r[1]['inspection_id'],'path':'assets/'+r[1]['inspection_id']+'/1f6e714cd9de4e6b8672d730cd4cf70e.png','observation':'한쪽 파이프가 없는 원본. RIGHT_PIPE 명칭은 제품 설정·기존 기록과 연결'}],'screenshot':{'path':'sources/screens/UI_CROP_JETSON.png','visible_id':r[1]['inspection_id'],'visible_decision':'FAIL','visible_reason':'RIGHT_PIPE_MISSING'},'scope':'제출용 파일·연결 보조 확인. 새 평가, 독립 정답 승인, 실제 이동영상 관찰 아님'},ensure_ascii=False,indent=2))
print(json.dumps({'reports_written':9,'evidence_map_rows':len(evidence),'inspection_table_rows':len(r)},ensure_ascii=False))
