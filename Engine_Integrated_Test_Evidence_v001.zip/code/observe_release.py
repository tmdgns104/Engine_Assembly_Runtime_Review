"""현재 실행본의 식별 정보만 읽는다. 서비스 조작과 PLC 출력 없음."""
from pathlib import Path
import subprocess,json
O=Path(__file__).resolve().parents[1]
source="""from pathlib import Path
import json,hashlib,datetime,subprocess
b=Path('/home/jetson/oned_device_bench')
p=b/'current/release.json'
r={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'release_source':str(p),'release_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'release':json.loads(p.read_text()),'configuration_sha256':hashlib.sha256((b/'config/standalone.json').read_bytes()).hexdigest(),'service':subprocess.run(['systemctl','show','engine-inspector.service','--property=ActiveState,SubState,MainPID'],capture_output=True,text=True,check=True).stdout}
print(json.dumps(r))
"""
p=subprocess.run(['ssh','-i',str(Path.home()/'.ssh/oned_device_jetson_bench_ed25519'),'-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=10','jetson@100.119.148.89','/home/jetson/oned_device_bench/envs/app_v1/bin/python','-B','-'],input=source.encode(),capture_output=True,timeout=30)
if p.returncode:raise SystemExit(p.stderr.decode(errors='replace'))
d=json.loads(p.stdout);(O/'queries/current_operating_observation.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({k:v for k,v in d.items() if k!='release'},ensure_ascii=False));print('release_id',d['release'].get('release_id'))
