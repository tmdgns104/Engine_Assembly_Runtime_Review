"""Read only known sources for the seven historical field inspections."""
from pathlib import Path
import json,sqlite3

R=Path('D:/OneDevice_Team_project')
O=Path(__file__).resolve().parents[1]
W=R/'runs/config_ui_history_20261018'
def read(p): return json.loads(Path(p).read_text('utf-8'))
def show(label,value): print(label+': '+json.dumps(value,ensure_ascii=False))

after=read(W/'field_ten/AFTER_20261018T092246_484843Z.json')
before=read(W/'field_ten/BEFORE.json')
show('after_keys',list(after));show('before_keys',list(before))
show('expected',read(W/'field_ten/EXPECTED_SEQUENCE.json'))
item=after['records'][0]
show('record_keys',list(item));show('row_keys',list(item['row']))
for key in ('assets','events'):
 show(key,{'count':len(item.get(key,[])),'first':item.get(key,[])[:1]})
show('final_keys',list(item['final']))
show('row_basic',{k:v for k,v in item['row'].items() if not isinstance(v,(list,dict)) and not k.endswith('_json')})
show('request',item['row']['request_json'])
show('result_keys',list(item['row']['result_json']))
show('state_keys',list(after['state']))
show('plc_cycle',after['state'].get('plc_cycle'))
show('other_after',{k:v for k,v in after.items() if k not in ('state','records','release','environment')})
inv=read(R/'docs/evaluation_assets/20261019/asset_inventory.json')
show('inventory_keys',list(inv))
for key in inv:
 if any(x in key for x in ('database','inspection','record','video','remote')):
  value=inv[key]
  show('inventory_'+key, str(value)[:2800])
db=R/'database/snapshots/20261018_post7/journal.sqlite3'
show('db_exists',db.is_file())
if db.is_file():
 con=sqlite3.connect(db.as_uri()+'?mode=ro&immutable=1',uri=True)
 show('schema',list(con.execute("SELECT name,sql FROM sqlite_master WHERE type='table'")))
 con.close()
show('ui_transition_files',[p.name for p in (W/'ui_transition').iterdir() if p.is_file()])
show('transition_files',[p.name for p in (W/'transition').iterdir() if p.is_file()])
