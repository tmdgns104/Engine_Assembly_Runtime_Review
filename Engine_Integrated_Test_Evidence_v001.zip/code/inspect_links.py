from pathlib import Path
import csv,json,sqlite3
R=Path('D:/OneDevice_Team_project');W=R/'runs/config_ui_history_20261018'
def read(p):return json.loads(Path(p).read_text('utf-8'))
def out(k,v):
 text=json.dumps(v,ensure_ascii=False)
 print(k+': '+(text if len(text)<1500 else text[:1500]+' [bounded preview]'))
a=read(W/'field_ten/AFTER_20261018T092246_484843Z.json');i=a['records'][0];ident=i['row']['inspection_id']
out('package',{k:v for k,v in i['row']['package_json'].items() if k not in ('configuration','manifest','recipe')})
out('plc_snapshot',a['state']['plc']['snapshot'])
out('plc_keys',list(a['state']['plc']));out('plc_events_tail',a['state']['plc'].get('events',[])[-2:])
out('history_shape',{'type':type(a['state']['history']).__name__,'size':len(a['state']['history']),'first_keys':list(a['state']['history'][0]) if a['state']['history'] else []})
db=R/'database/snapshots/20261018_post7/journal.sqlite3';con=sqlite3.connect(db.as_uri()+'?mode=ro&immutable=1',uri=True);con.row_factory=sqlite3.Row
out('service_state_matches',[(x['key'],len(x['value'])) for x in con.execute('SELECT key,value FROM service_state WHERE instr(value,?)>0',(ident,))])
out('events',[(x['event_type'],x['occurred_at'],list(json.loads(x['payload_json']))) for x in con.execute('SELECT * FROM events WHERE instr(payload_json,?)>0',(ident,))])
out('dispositions',[dict(x) for x in con.execute('SELECT * FROM dispositions WHERE inspection_id=?',(ident,))])
for sub in ('transition','ui_transition'):
 d=read(W/sub/'DEPLOYMENT.json');out(sub+'_deployment',{k:v for k,v in d.items() if not isinstance(v,(dict,list))});out(sub+'_deployment_keys',list(d))
 d=read(W/sub/'AFTER_REBOOT_PROOF.json');out(sub+'_proof_keys',list(d))
for n in ('UI_DETAIL_VERIFIED.txt','UI_FILTER_VERIFIED.txt','UI_CROP_JETSON.json'):
 t=(W/n).read_text('utf-8');out(n,{'contains_selected_ids':[x['row']['inspection_id'] for x in a['records'] if x['row']['inspection_id'] in t],'chars':len(t),'sample':t[:350]})
out('local_sources',[(p.name,p.stat().st_size) for p in (R/'docs/evaluation_assets/20261019').glob('*.csv')])
out('plc_file_exists',Path('D:/머신러닝_학습자료/비전검사 푸셔없는버전 4 .smc2').is_file())
