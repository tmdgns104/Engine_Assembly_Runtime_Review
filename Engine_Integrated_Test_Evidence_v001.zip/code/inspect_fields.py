from pathlib import Path
import json,sqlite3
P=Path('D:/OneDevice_Team_project'); W=P/'runs/config_ui_history_20261018'
read=lambda p:json.loads(p.read_text('utf-8'))
a=read(W/'field_ten/AFTER_20261018T092246_484843Z.json');r=a['records'][0];ident=r['row']['inspection_id']
for name,v in [('row',r['row']),('result',r['row']['result_json']),('final',r['final']),('history',a['state']['history'][0])]:
 print(name,[(k,type(x).__name__) for k,x in v.items()])
print('history completion',[(x.get('inspection_id'),x.get('cyclic_done_reset_observed'),x.get('publication_status'),x.get('request_to_publication_ms')) for x in a['state']['history']])
for n in ('transition','ui_transition'):
 d=read(W/n/'DEPLOYMENT.json');print(n,'changes',d.get('changes',d.get('changed_files')),list(d))
 print('proofkeys',list(read(W/n/'AFTER_REBOOT_PROOF.json')))
print('beforeplc',read(W/'field_ten/BEFORE.json')['state']['plc']['snapshot'])
lad=read(P/'runs/inspection_reliability_20261018/run_capture_transition/PLC_SAVED_LADDER_v001.json')
for i,rung in enumerate(lad['rungs'],1):
 print('rung',i,[{k:v for k,v in x.items() if k not in ('Ix','X','Y')} for x in rung['CLs']])
con=sqlite3.connect((P/'database/snapshots/20261018_post7/journal.sqlite3').as_uri()+'?mode=ro&immutable=1',uri=True);con.row_factory=sqlite3.Row
for event in con.execute('SELECT event_type,payload_json FROM events WHERE instr(payload_json,?)>0',(ident,)):
 if event['event_type'] in ('PLC_CYCLIC_COMPLETION_OBSERVED','INSPECTION_DURABLE_TIMING','INTEGRATED_FINAL_DURABLE'):
  print(event['event_type'],event['payload_json'][:3000])
print('assets',[(x['kind'],x['relative_path']) for x in a['records'][0]['assets']])
