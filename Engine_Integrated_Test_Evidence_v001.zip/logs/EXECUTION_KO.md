# 기존 증빙 수집 실행 기록

작업일: 2026-10-20 (KST). Windows 개발 폴더의 `.venv/Scripts/python.exe -B -X utf8`로 실행했다. 아래 실행은 증빙 폴더에만 출력하며 운영 기능을 실행하지 않았다.

1. 사용자 요청문, 기존 인벤토리, field_ten 전후 기록 및 일관된 SQLite snapshot 확인. 제한된 관련 경로만 검색했다.
2. `recover_existing.py`: 기본 샌드박스에서 SSH 네트워크 접근이 거부되어 승인된 읽기 전용 범위로 다시 실행. 기존 파일 35개(원본21·표시7·참고 JSON7) 회수, 원장 해시 28/28 일치. GET 14/14 성공. 상세 실행 시각/종료코드는 `recovery_execution.json`, 파일·조회별 영수증은 `../remote_recovery_receipt.json`.
3. `observe_release.py`: 현재 release.json과 설정 파일 해시, systemctl show 상태만 읽음. 결과 `../queries/current_operating_observation.json`. 서비스를 시작/정지/재시작하지 않음.
4. `build_evidence.py`: 기존 DB를 읽기 전용으로 집계. 첫 검증에서 field snapshot의 축약 release 정보와 완전한 release manifest 스키마가 달라 중단. 기존 AFTER_REBOOT_PROOF의 완전한 manifest를 사용하도록 수정. 이어 manifest 경로의 `current/` 접두사를 반영해 재검증. 이는 수집 코드의 스키마 수정이며 장치 오류/운영 코드 변경이 아님.
5. 집계 완료: 검사7, 결품3, 원본·표시28, 관련 이벤트55, outbox55, cycles7, service_state14. 기존 DB 전후 SHA 일치 및 integrity_check=ok. 원장 결과와 당시 수집 JSON 모든 열 일치.
6. UI 변경본 두 파일은 `ui_transition/runtime`이 아닌 실제 `ui_transition/candidate`에서 발견. `complete_sources.py`가 해당 두 파일만 복사·릴리스 해시 검증. 기존 경로 검색 결과와 해결 경로는 trial_reconciliation.json에 보존.
7. `write_reports.py`: README, 시간/DB/PLC 설명, 사용자 관찰, 보완 목록 및 evidence_map 작성. 사용자의 실제 LED·컨베이어 관찰을 기록하고 시스템 `plc_consumption_confirmed=false`는 변경하지 않음.
8. `verify_bundle.py --audit-only`: 16개 검증 항목 PASS, CSV 참조215개, 원본/복사본 대조88개. 이미지 디코드28개, 고유 원본21개, 같은 ID의 API 본문 및 기존 DB 결과 일치. 최종 ZIP 검증은 verification.json 및 폴더 밖 ZIP_RECEIPT.json에 기록.

원격에서 수행한 작업은 기존 파일 읽기, 이력 HTTP GET, release/config 해시 및 서비스 상태 조회뿐이다. PLC 출력·운전, 카메라 촬영, 신규 검사, 서비스 재시작, 코드/설정 배포, 학습/추론/평가를 수행하지 않았다. 새 시험의 PASS 기록을 만들지 않았다.
