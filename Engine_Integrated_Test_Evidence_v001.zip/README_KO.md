# 엔진 모형 통합 테스트 — 기존 증빙 묶음

작성일: 2026-10-20. 대상 시험일: 2026-10-18. 이번 작업은 **기존 증빙 수집·대조·압축**이며 새 실물시험을 수행하지 않았다.

## 1. 확인된 성과

| 항목 | 확보 결과 | 근거와 확인 수준 |
|---|---|---|
| 실제 검사 연결 | 정상 투입 계획 4건 PASS, 오른쪽 파이프 결품 계획 3건 FAIL. 총 7건이 사전 순서와 일치 | 당시 순서표·검사 원장·최종 결과. **원문기록**. 정답은 예측에서 역산하지 않음 |
| 원본 보존 | 원본 PNG 21장 + 표시 JPG 7장, 28/28 원장 SHA-256 일치 | `assets/`, `asset_manifest.csv`. **실파일대조** |
| 저장·조회 | 7건 COMPLETE·storage_success=true. SQLite snapshot의 동일 ID·관련 이벤트와 대조. 현재 상세/검색 GET 14회 모두 HTTP 200 | `db/`, `queries/`. **원문기록·실파일대조** |
| PLC 연계 | 요청 1–7, Result 7·Done 7·완료 7, 요청 LOW 복귀. 7개의 완료 이벤트 연결 | 당시 전후 snapshot, 검사별 이벤트. **통신 기록** |
| 현장 작동 | 사용자가 실제 시험 중 LED와 컨베이어 동작을 모두 확인했다고 후속 확인 | [사용자 관찰 원문](user_observations.md). **사용자관찰** |
| 웹 표시 | 실제 저장된 2번 검사 ID의 부품 위치 사진·RIGHT_PIPE_MISSING·FAIL 화면 확보 | [기존 Jetson 화면](sources/screens/UI_CROP_JETSON.png). **화면 관찰**; 실물 이동영상은 아님 |

7건 중 제품 FAIL 3건은 결품 검출 결과이며 시험 실패 3건이 아니다. 기본 검사와 최종 판정의 REVIEW/ERROR는 0건이다. 참고 오조립 분석은 7건 모두 REVIEW로 남아 있고 최종 PASS/FAIL에 영향을 주지 않았다.

## 2. 시험 조건과 범위

- 시험 실행본: **`engine-integrated-4c4b935f8ab0404a`**. boot ID `f1d09fb4-1a23-4b59-a6eb-7289248d8701`.
- 계획: 정상→오른쪽 파이프 결품 10회. 사용자가 조기 종료하여 **실제 7회**가 저장됐다. 10회·30회 또는 장시간 신뢰성 인증으로 표현하지 않는다.
- 기록 구간: 첫 검사 수락 **2026-10-18T18:19:50.320+09:00**, 마지막 PLC 주기 완료 이벤트 **2026-10-18T18:21:55.124+09:00** (한국 시각). 투입 시작/배출 종료의 별도 실물 타임코드는 없다.
- 단일 boot, 같은 실행본·카메라 Worker·PLC 연결의 7건이라는 당시 요약을 전후 ID 차이, 요청 번호 1–7, 누적 카운터 0→7, 동일 모델/설정값으로 대조했다. 선택 구간 7건 모두 COMPLETE이며 전후 rejected 증가는 0이다. 이 구간 밖 실패를 합산하거나 누락된 시도를 성공으로 추가하지 않았다.
- 투입 정답 근거: 사전 `EXPECTED_SEQUENCE.json`, 두 모형 준비에 대한 사용자 확인, 당시 결과 요약. 개별 ID별 실제 투입 상태를 독립 촬영한 영상/별도 확인표는 없다. 따라서 “7/7 계획 순서 일치”와 독립적인 일반 정확도 평가는 구분한다.
- 카메라 기록: 1280×720 원본, 기존 GStreamer/단일 Worker, 연속 원본 3장. 당시 설정 전체는 각 검사의 `package_json`과 `result_json`에 보존했다. 새 촬영·추론·평가·모델 변환은 하지 않았다.
- 운영 정책: `BASIC_PRESENCE_ASSEMBLY_REFERENCE_V2`. 미결합 검사가 최종판정을 결정하며 오조립은 참고 전용이다.

## 3. 검사별 결과

| 순번 | inspection_id | 사전 투입 상태 | 기본 / 최종 | 기본 사유 | PLC Result · 주기 | 원본 / DB |
|---|---|---|---|---|---|---|
| 1 | `05f8aac3b2cb42c8a03b2d5c8ae32f86` | 정상 | PASS / PASS | ALL_REQUIRED_PARTS_PRESENT_3_FRAMES | 0 · 완료 | 3장 / 저장 완료 |
| 2 | `a8dc2303a68a4e6aa3611413d7f67df2` | 오른쪽 파이프 결품 | FAIL / FAIL | RIGHT_PIPE_MISSING | 1 · 완료 | 3장 / 저장 완료 |
| 3 | `62c1161f90064603b7ce9c3993af8f72` | 정상 | PASS / PASS | ALL_REQUIRED_PARTS_PRESENT_3_FRAMES | 0 · 완료 | 3장 / 저장 완료 |
| 4 | `05fc9abc7e894f7d9dda34c823336d1b` | 오른쪽 파이프 결품 | FAIL / FAIL | RIGHT_PIPE_MISSING | 1 · 완료 | 3장 / 저장 완료 |
| 5 | `51f92dcc3f7843f180b2a848cd63a5c3` | 정상 | PASS / PASS | ALL_REQUIRED_PARTS_PRESENT_3_FRAMES | 0 · 완료 | 3장 / 저장 완료 |
| 6 | `182c8e66347f43359d6b18e06519fd1d` | 오른쪽 파이프 결품 | FAIL / FAIL | RIGHT_PIPE_MISSING | 1 · 완료 | 3장 / 저장 완료 |
| 7 | `cd3833068e9842a68ece7922bbf2a09c` | 정상 | PASS / PASS | ALL_REQUIRED_PARTS_PRESENT_3_FRAMES | 0 · 완료 | 3장 / 저장 완료 |

전체 필드·정확한 시각·경로는 [inspection_results.csv](inspection_results.csv)에 있다. 각 `assets/<ID>/`에는 기존 원본 3장·표시 이미지 1장, 기존 참고 분석 `assembly/result.json`, DB 기본 결과 내보내기 `db_result.json`, 기존 최종판정 내보내기 `integrated_final.json`이 있다. 원본은 이름·바이트를 유지했으며 표시 이미지나 crop을 검사 원본으로 대체하지 않았다.

## 4. 운영본·모델·설정 연결

| 구분 | 식별 및 근거 |
|---|---|
| 7회 시험본 | `engine-integrated-4c4b935f8ab0404a`, `sources/transition/AFTER_REBOOT_PROOF.json`, 당시 field snapshot |
| 이후 UI 운영본 | `engine-integrated-32c484ac6aeb07f1`, `sources/ui_transition/DEPLOYMENT.json` |
| 변경 범위 | release manifest 대조 결과 `current/apps/edge_service/line_details.js`, `current/apps/edge_service/line_hmi.html` 2개만 변경. 저장 사진 crop, 미결합 강조, 참고 글씨 축소 |
| 현재 읽기 조회 | 2026-10-19T23:56:28.850396+00:00에 `engine-integrated-32c484ac6aeb07f1` 관측. service active/running. release 파일 목록은 기존 UI 릴리스와 일치. 새 검사 성공을 의미하지 않음 |
| M1 | `dynamic_parts_005` / `CFA8507_original_PT_fp16_head32`, TensorRT artifact SHA `743ce54b4d5c7b8a36addf3dbff50fa693ec4a509b31b476f68efc69f1bf2d6c` |
| M2 | `envelope_v007_fp16`, TensorRT artifact SHA `c82f2658ac20d06985a647c15e551c681e394451cfa1c53baed64f639bcebf83` |
| 시험 시 유효 설정 | process settings SHA `82673f9ea8914ea7ec2c96c4d15a98ee202fc6384a6c0974b6c8fa96e2ef0bdb`; 각 검사 결과의 package/configuration과 backend에 기록 |
| 현재 standalone.json 파일 | 바이트 SHA `f128f7999c9bdec4a973a22eade5e1042c15436e3b9e6a91f6ebd834bf240a91`. process settings 해시와 입력 범위가 다르므로 해시 문자열 차이를 설정 변경으로 해석하지 않음 |

[release_linkage.json](release_linkage.json), [release_file_changes.csv](release_file_changes.csv)에 연결과 파일별 해시를 기록했다. 당시 운영 코드 8개도 release manifest 해시와 일치한다. **7회 실물시험을 32c4에서 다시 수행한 것으로 쓰지 않는다.** 기존 19일 Benchmark 후 원복·모델 해시 관측은 부록에 있고, 20일 조회만으로 모델 바이너리를 재측정했다고 하지 않는다.

## 5. DB·웹·PLC 증거 읽는 방법

`db/source_snapshot_receipt.json`의 기존 일관된 SQLite backup() snapshot을 `mode=ro&immutable=1`, `query_only=ON`으로 읽었다. 원본 94,973,952바이트 DB의 전후 SHA가 같고 integrity_check=ok다. 전체 DB 대신 선택된 검사 7행, 결품 3행, 자산 28행, 관련 이벤트 55행, outbox 55행, 주기 7행, service_state 14행 및 스키마·조회문을 넣었다. 관련 이벤트 안의 이전 검사 참조와 주대상 ID는 `db/event_links.json`에서 구분한다. 전체 DB 368건은 이 시험의 평가 분모가 아니다.

`queries/`는 **2026-10-19T23:54:06.707552+00:00 이후** 수행한 기존 이력의 GET 결과다. 검사일은 18일이며 조회일은 20일이다. 현재 화면을 과거 실물 영상으로 사용하지 않았다. `UI_CROP_JETSON.png`에는 2번 ID가 실제로 보인다. 기존 `UI_DETAIL_VERIFIED.txt`·`UI_FILTER_VERIFIED.txt`는 다른 검사 ID의 UI 기능 확인이므로 이번 7건의 조회 근거는 새 GET 응답으로 연결한다. PC 수집 상태가 PENDING인 필드도 원문대로 남기며, 이번 증빙 회수를 과거 자동 PC 수집 성공으로 바꾸지 않는다.

PLC 저장 소스 `비전검사 푸셔없는버전 4 .smc2`와 23 rung을 포함했다. `PLC_LINKAGE_KO.md`는 저장 소스상 기대 동작, 통신 기록, 사용자 현장 관찰을 분리한다. 온라인 PLC 전체 프로그램과 저장 소스가 완전히 같은지는 별도 미확인이다. 푸셔·자동 분리 장치는 가정하지 않는다.

원장 `plc_consumption_confirmed=false`는 자동 소비 피드백 미확인을 나타낸다. 이를 true로 바꾸지 않았으며, 사용자의 **“실제 테스트하면서 LED나 컨배이어밸트 운직이는거 다 확인했어”**라는 현장 관찰을 별도로 연결했다. 독립 전기 피드백이나 ID별 타임코드가 없다는 사실과 사람이 동작을 확인했다는 사실은 양립한다.

## 6. 응답시간 — 측정 구간별 구분

단위: 초. 기존 7건 기록만 집계. 아래 값은 모델 단독 추론 시간이 아니다.

| 측정 구간 | 최소 | 평균 | 최대 |
|---|---:|---:|---:|
| 기본 검사 원장 수락→기본 결과 완료 시각 | 2.283 | 2.507 | 3.026 |
| 검사 요청 기준→새 원본 3장 확보 | 1.815 | 1.929 | 2.361 |
| 검사 요청 기준→기본 결과 영속 저장 완료 | 2.316 | 2.586 | 3.061 |
| 기본 결과 저장 커밋 구간 | 0.313 | 0.470 | 1.018 |
| PLC 주기 수락→통합 최종판정 생성 | 10.183 | 11.151 | 14.324 |
| PLC 주기 수락→결과 게시 호출 직후 | 10.237 | 11.226 | 14.378 |
| PLC 주기 수락→Result/Done·요청 해제 관측 이벤트 | 10.580 | 11.567 | 14.707 |

기본 원장 완료 시각과 실제 영속 저장 커밋은 다른 필드다. 통합판정 생성·게시·PLC 완료 이벤트도 분리했다. PLC 완료 이벤트까지의 시간은 저장된 같은 Jetson monotonic 시계 값으로 계산한 소프트웨어 관측 지연이며 LED/모터 작동 시각은 아니다. 실제 정의와 원문 필드는 [TIME_AND_FIELD_MAP_KO.md](TIME_AND_FIELD_MAP_KO.md)에 있다.

## 7. 적용 범위와 보완

이번 묶음으로 7건의 요청→사진→기본/최종판정→PLC 통신 완료→저장·조회와 사용자 현장 관찰을 설명할 수 있다. 해당 7회에 연결된 **실물 동작 영상은 미확보**다. 빈 벨트 220프레임, 다른 날짜 자료, Benchmark 저장사진을 7회 동작 영상으로 사용하지 않았다. 과거 오조립 참고 분석 REVIEW·제품 추적 진단도 그대로 보존했다. 반복 추적 경고가 있어도 해당 7건의 제품 검사 ERROR와 혼동하지 않는다.

이 자료는 모든 결품 유형, 다양한 위치·각도·조명, 장시간 안정성, 현재 운영본 재시험을 입증하지 않는다. 기존 조명·위치·복구 자료의 연결 범위는 [appendix/CONTEXT_KO.md](appendix/CONTEXT_KO.md), 최대 3개의 보완 제안은 [missing_evidence.md](missing_evidence.md)에 있다. 미확보 항목을 보완하기 위한 새 조작은 이번 작업에서 수행하지 않았다.

## 8. 파일 무결성과 재현

- `bundle_manifest.json`: 각 파일의 ZIP 상대경로·원본 경로·크기·SHA-256·복사/내보내기 방법.
- `asset_manifest.csv`: 7건별 원본·표시·결과 파일 연결 및 원장 해시 일치.
- `verification.json`: 원본 대조, 표 참조, DB/조회 연결, 이미지 디코드, ZIP 파일집합·CRC·SHA 검증 결과.
- `evidence_map.csv`: 주장별 원자료와 확인 수준. `logs/`와 `code/`는 이번 수집·집계·검증 방법이다. `sources/` 안의 과거 서비스 관련 코드는 읽기 증거로만 보존했으며 실행하지 않았다.
- manifest와 verification 자신은 순환 해시를 피하기 위해 manifest의 파일별 해시 대상에서 제외한다. ZIP 검증은 두 파일을 포함한 실제 전체 파일집합으로 수행한다. ZIP 자체 SHA는 폴더 밖 영수증에 별도 기록한다.

작업 경계: 새 현장시험·카메라 촬영·PLC 출력·서비스 재시작·운영본 변경·학습·추론·Benchmark 실행 없음.
