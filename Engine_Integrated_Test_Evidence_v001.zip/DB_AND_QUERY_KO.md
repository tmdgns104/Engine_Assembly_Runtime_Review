# DB 내보내기와 웹 조회

`db/selected_rows.json`은 기존 SQLite snapshot의 선택된 7건 및 관련 테이블 행을 원래 열 이름/값으로 내보낸 JSON이다. JSON TEXT 열은 원문 문자열을 유지한다. `db/schema.sql`은 원래 스키마이며 JSON export를 자동 운영 DB로 복구하기 위한 실행 스크립트가 아니다.

조회는 mode=ro&immutable=1, query_only=ON, 단일 읽기 트랜잭션에서 수행했다. 기존 snapshot은 당시 sqlite3.Connection.backup()으로 생성됐고 방법은 sources/historical_snapshot_post7.py, 영수증은 db/source_snapshot_receipt.json이다. 이번에는 그 코드를 실행하지 않았다. 운영 DB 본체나 WAL을 복사하지 않았으며 전체 DB를 ZIP에 포함하지 않았다.

`db/queries.sql`과 `code/build_evidence.py`가 실제 조회 조건을 설명한다. per_inspection/<ID>.json은 동일 ID 행, 직접 관련 이벤트, 당시 웹/서비스 history, 원장 asset 행을 함께 읽기 쉽게 묶은 파생 자료다. dispositions는 선택된 7건 모두 0행이며, 이 테이블에서 실제 제품 처분을 확정하지 않는다. outbox와 frame_assets의 PENDING 상태를 자동 PC 수집 완료로 바꾸지 않았다.

이번 GET은 Jetson 자체 loopback의 `/api/v1/history/<ID>` 및 `/api/v1/history?q=<ID>&limit=10`을 이용했다. 수집 일시는 remote_recovery_receipt.json, 본문은 queries/<ID>_detail.json 및 _search.json이다. 서비스 상태를 바꾸는 POST나 신규 검사 요청은 하지 않았다. HTTP 200만으로 판정 일치를 단정하지 않고 응답 ID 및 저장 내용과 원장도 대조한다.
