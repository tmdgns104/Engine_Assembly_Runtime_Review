# PLC 기대 동작 · 통신 기록 · 실제 관찰

저장 소스: `sources/plc/비전검사 푸셔없는버전 4 .smc2`, SHA-256 `c0dff344cb815ae75cffe63c21454384393061abf4fa35e7d46405033c879137`.
기존 추출본 `PLC_SAVED_LADDER_v001.json`의 source_sha256과 원본 바이트를 대조했다. 23 rung. 온라인 다운로드된 전체 프로그램 동일성은 이번 읽기 작업에서 확인하지 않았다.

| 항목 | 저장 PLC의 기대 동작 | 이번 7건의 통신 기록 | 실제 장치 관찰 |
|---|---|---|---|
| START·STOP | rung1 Stop_PB·EStop_OK 정상 회로 및 Start_PB로 Mc_Run 자기유지. Stop_PB=true는 정상/해제된 회로 | Mc_Run 운전 및 종료 정지, 요청1–7; Start_PB 자체는 Jetson에 미노출 | 당시 사용자가 START. 종료는 기존 STOP 상태 기록 |
| 이송 | rung2 Mc_Run && !Inspecting → Cv_Run | Mc_Run·검사 단계는 수집; 별도 모터 피드백 없음 | 사용자가 실제 컨베이어 동작을 모두 확인했다고 20일 진술 |
| 제품 감지 | rung3 Mc_Run·PhotoSensor·Sensor_Ready·!Jetson_Done → Move_pending; rung4 Sensor_Ready 해제 | PhotoSensor/Sensor_Ready 내부값은 현재 Jetson 인터페이스에서 직접 수집하지 않음 | 센서 접점/타임코드별 독립 관찰 미확인 |
| 정지 후 요청 | rung21~23 4.5초 Move_Timer 이후 Inspecting; rung5 정지 상태 2초 Inspect_Delay_Timer 후 Inspection_Request | 유효 요청1–7과 원본3장·검사 기록 연결 | 저장 원본은 검사 위치의 엔진을 보여 줌. 전체 이송영상 아님 |
| OK | rung10 Cycle_Done·Jetson_Done·!Jetson_Result → Normal_Memory; rung14 운전 중 Normal_lamp | PASS 4건, Result=0 | 사용자 LED 확인. 개별 ID별 색상/타임코드 진술은 없음 |
| NG | rung11 Cycle_Done·Jetson_Done·Jetson_Result → Defect_Memory; rung15 Defect_lamp | 오른쪽 파이프 결품 FAIL 3건, Result=1 | 사용자 LED 확인. 푸셔·분리 장치 가정 없음 |
| 재이송·다음 준비 | rung6~7 Done이면 Cycle_Done 및 Inspecting 해제; rung2 재이송. rung12~13 센서/Done 해제 후 Sensor_Ready 복구. rung16~20 STOP 복구 | Result/Done/완료 각7, request LOW·7개 PLC_CYCLIC_COMPLETION_OBSERVED, 다음 요청 연결 | 사용자 실제 컨베이어 동작 확인. 자동 모터 소비 피드백은 별도 미확인 |

당시 기록의 ack_scope는 CYCLIC_SEND_AND_REQUEST_RESET_ONLY, plc_consumption_confirmed는 false다. 이를 보존하고 사용자 관찰을 별도 수준으로 연결했다. 저장 PLC상 NG도 Done으로 Inspecting을 해제하여 재이송하는 구조이며, 이 자료에 자동 불량 분리/푸셔 완료를 추가하지 않는다.

이 문서는 기존 소스·기록을 설명한다. 이번 작업에서 PLC 프로그램 접속·다운로드·강제 출력·START/STOP 조작을 수행하지 않았다.
