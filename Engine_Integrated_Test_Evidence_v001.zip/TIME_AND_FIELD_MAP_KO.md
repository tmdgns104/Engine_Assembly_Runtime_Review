# 필드·시간의 출처

| 산출 필드 | 실제 원문 / 계산 | 시간 범위 |
|---|---|---|
| input_state, expected_decision | sources/field_ten/EXPECTED_SEQUENCE.json 순번 | 투입 계획 + 사용자 모형 준비 확인. AI 예측에서 추출하지 않음 |
| basic_decision, basic_reason | inspections.decision / result_json.reason_code | 필수 부품 미결합 검사 |
| reference_assembly | 기존 final.assembly_reported + assembly/result.json | 오조립 참고; assembly_affects_final=false |
| final_decision, plc_result_value | final.decision / final.plc_result_value | 당시 최종판정, PASS=0(OK), 나머지=1(NG) |
| cyclic_done_reset_observed | 당시 state.history의 동일 ID | Result/Done·요청 LOW 복귀의 소프트웨어 관측 |
| journal_elapsed_ms | inspections.completed_at - accepted_at, UTC wall clock | 원장 수락 시각→기본 결과 완료 시각. 이후 영속 커밋까지 포함한다고 단정하지 않음 |
| request_to_three_frames_ms | result_json.request_to_three_frames_ms | Worker가 기록한 요청 기준→세 번째 새 유효 원본 확보, monotonic |
| request_to_durable_result_ms | INSPECTION_DURABLE_TIMING.payload | 기본 요청→원본/결과 영속 저장 완료, edge_monotonic |
| storage_commit_ms | 같은 이벤트 payload.storage_commit_ms | 해당 기본 결과 영속 저장 커밋. 전체 검사시간 아님 |
| integrated_elapsed_ms | final.inspection_elapsed_ms = (completed_monotonic - cycle_admission_evidence.accepted_at)*1000 | PLC 주기 수락→기본+참고 분석을 포함한 통합 최종판정 생성 |
| request_to_publication_ms | 당시 state.history / INTEGRATED_INSPECTION_COMPLETED | _publish_committed의 handshake.publish 호출 직후. PLC 내부 소비 시각 아님 |
| request_to_plc_completion_event_ms | PLC_CYCLIC_COMPLETION_OBSERVED.payload.monotonic_s - final.cycle_admission_evidence.accepted_at | 같은 Jetson monotonic 시계의 주기 수락→통신 완료 관측 이벤트 |
| query_at | remote_recovery_receipt.json | 이번 읽기 전용 HTTP GET 시각. 18일의 시험 시각과 다름 |
| device_observation | user_observations.md | 실제 시험 후 사용자의 LED/컨베이어 확인. 자동 피드백 값 변경 없음 |

원장 JSON의 request_token은 비밀 인증 토큰이 아닌 PLC boot/connection/request 거래 식별자다. 같은 검사를 연결하기 위해 보존한다. 인증 비밀번호·개인키·인증 토큰은 포함하지 않는다.

일부 이벤트는 이전 검사의 ID를 previous_transaction 안에 참조한다. event_links.json의 primary_inspection_id를 현재 사건의 주대상으로 사용하고, referenced_selected_ids는 관계 추적에만 사용한다. 다른 요청의 이벤트를 중복 성공으로 세지 않는다.

원장 raw worker의 physical_output_enabled=false는 그 Worker의 직접 물리 출력 권한 필드다. 별도 통합 PLC 경로의 Result/Done 관측과 구분한다. 이 필드만으로 전체 시스템에서 PLC 전송이 없었다고 해석하지 않는다.
