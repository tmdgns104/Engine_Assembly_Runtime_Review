"""Run read-only preflight through existing SSH authentication and retain evidence."""
from pathlib import Path
import json
import subprocess

O = Path(__file__).resolve().parents[1]
logs = O/'logs'
logs.mkdir(exist_ok=True)
cmd = ['ssh', '-i', 'C:/Users/user/.ssh/oned_device_jetson_bench_ed25519',
       '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes', '-o', 'ConnectTimeout=10',
       'jetson@100.119.148.89', '/home/jetson/oned_device_bench/envs/app_v1/bin/python -B -']
r = subprocess.run(cmd, input=(O/'code/read_environment.py').read_bytes(), capture_output=True, timeout=120)
(logs/'preflight_command.json').write_text(json.dumps(cmd, indent=2), encoding='utf-8')
(logs/'preflight_stdout.json').write_bytes(r.stdout)
(logs/'preflight_stderr.txt').write_bytes(r.stderr)
if r.returncode:
    print(r.stderr.decode('utf-8', errors='replace')[-2000:])
    raise SystemExit(r.returncode)
d = json.loads(r.stdout)
(O/'environment.json').write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding='utf-8')
s = d['runtime_status']
print(json.dumps({'release': d['release'].get('release_id', d['release'].get('release')),
                 'release_keys': list(d['release']), 'packages': d['packages'], 'cuda_query': d['cuda_query'],
                 'model_sha': {k: v['model.plan']['sha256'] for k,v in d['files'].items() if 'model.plan' in v},
                 'plc': s.get('plc', {}).get('snapshot'),
                 'inspection_service': {k: s.get('inspection_service', {}).get(k) for k in ('state','error','ready','camera_ready','worker_pid','storage_pending','active_inspection_id')},
                 'commands': [x for x in d['commands'] if x['command'][0] != 'ps'],
                 'thermal': d['thermal']}, ensure_ascii=False, indent=2))
