"""Unprivileged sequential benchmark. No camera, PLC or service controls."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

O=Path(__file__).resolve().parents[1]
os.environ.update(YOLO_AUTOINSTALL='false',YOLO_CONFIG_DIR=str(O/'ultralytics_config'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')

def main():
    protocol=json.loads((O/'protocol.json').read_text())
    sys.path.insert(0,protocol['pythonpath'])
    os.environ['PYTHONPATH']=protocol['pythonpath']
    (O/'ultralytics_config').mkdir(exist_ok=True)
    assert json.loads((O/'adapter_tests.json').read_text())['status']=='PASS'
    for name,expected in protocol['code_hashes'].items():
        assert hashlib.sha256((O/'code'/name).read_bytes()).hexdigest()==expected,name
    for relative,expected in protocol['runtime_source_hashes'].items():
        assert hashlib.sha256((Path(protocol['runtime_root'])/relative).read_bytes()).hexdigest()==expected,relative
    import inspect
    import ultralytics
    from ultralytics.engine.validator import BaseValidator
    from ultralytics.utils.metrics import ap_per_class,box_iou
    assert ultralytics.__version__==protocol['accuracy']['evaluator_version']
    for function in (BaseValidator.match_predictions,ap_per_class,box_iou):
        assert hashlib.sha256(Path(inspect.getfile(function)).read_bytes()).hexdigest()==protocol['accuracy']['evaluator_function_hashes'][function.__qualname__]
    receipts=[]
    (O/'results').mkdir(exist_ok=True);(O/'logs').mkdir(exist_ok=True)
    for run in protocol['measurement']['order']:
        command=[sys.executable,'-B',str(O/'code/benchmark_worker.py'),run['run_id']]
        with (O/'logs'/f"{run['run_id']}.stdout.txt").open('w') as stdout,(O/'logs'/f"{run['run_id']}.stderr.txt").open('w') as stderr:
            start=time.monotonic();result=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=600)
        receipt={'run_id':run['run_id'],'command':command,'returncode':result.returncode,'wall_seconds':time.monotonic()-start}
        receipts.append(receipt);(O/'suite_progress.json').write_text(json.dumps(receipts,indent=2))
        print(json.dumps(receipt),flush=True)
        if result.returncode:break
        time.sleep(protocol['measurement']['cooldown_seconds_between_processes'])
    success=len(receipts)==12 and all(r['returncode']==0 for r in receipts)
    (O/'suite_result.json').write_text(json.dumps({'status':'PASS' if success else 'INCOMPLETE','runs':receipts},indent=2))
    return 0 if success else 1

if __name__=='__main__':raise SystemExit(main())
