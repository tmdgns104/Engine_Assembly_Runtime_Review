from pathlib import Path
import json
import subprocess
O=Path(__file__).resolve().parents[1]
cmd=['ssh','-i','C:/Users/user/.ssh/oned_device_jetson_bench_ed25519','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=10','jetson@100.119.148.89','/home/jetson/oned_device_bench/envs/app_v1/bin/python -B -']
r=subprocess.run(cmd,input=(O/'code/read_evaluator.py').read_bytes(),capture_output=True,timeout=60)
(O/'logs/evaluator_stderr.txt').write_bytes(r.stderr)
(O/'logs/evaluator_stdout.txt').write_bytes(r.stdout)
if r.returncode: raise SystemExit(r.returncode)
# Ultralytics can print a settings notice before JSON; retain complete stdout as evidence.
text=r.stdout.decode('utf-8'); start=text.index('{"ultralytics_version"')
d=json.loads(text[start:]); (O/'evaluator_source.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
for relative,v in d['runtime_sources'].items():
    p=O/'source_snapshot'/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(v['text'],encoding='utf-8',newline='')
print(json.dumps({k:v for k,v in d.items() if k!='runtime_sources'},ensure_ascii=False,indent=2))
