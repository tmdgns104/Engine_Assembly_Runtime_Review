"""Approved bounded service stop/measure/restore. Launched once by operator sudo.

Only service control needs root. The benchmark child runs as jetson, and this
controller always attempts to restart the same service in its finally block.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback
import urllib.request

O=Path(__file__).resolve().parents[1]
UNIT='engine-inspector.service'
PYTHON='/home/jetson/oned_device_bench/envs/app_v1/bin/python'

def status():
    with urllib.request.urlopen('http://127.0.0.1:18771/api/v1/runtime/status',timeout=8) as r:return json.load(r)

def validate_stop(s):
    p=s['plc']['snapshot'];h=s['inspection_service'];c=p['controls']
    assert p['connected'] and p['fresh'] and p['bool_valid']
    assert 0<=time.monotonic()-p['received']<.5,'PLC snapshot stale'
    assert c=={'Inspection_Request':False,'EStop_OK':True,'Mc_Run':False,'Stop_PB':True},c
    assert p['raw100']=='00000000' and p['phase'] in ('SYNC_LOW','DISARMED'),p['phase']
    assert h['state']=='IDLE' and not h.get('active_inspection_id') and not h.get('storage_pending'),h['state']
    assert not s.get('final_commit_pending') and not s.get('completion_audit_pending') and not s.get('request_start_pending')
    assert not s.get('assembly_component',{}).get('outstanding')

def main():
    assert os.geteuid()==0,'Run with sudo once; no password is stored.'
    assert str(O)=='/home/jetson/oned_device_bench/tmp/benchmark_m1_m2_20261019_v001'
    assert json.loads((O/'adapter_tests.json').read_text())['status']=='PASS'
    protocol=json.loads((O/'protocol.json').read_text())
    for name,h in protocol['code_hashes'].items():assert hashlib.sha256((O/'code'/name).read_bytes()).hexdigest()==h
    before=status();validate_stop(before)
    release=json.loads(Path('/home/jetson/oned_device_bench/current/release.json').read_text())
    assert release['release_id']==protocol['expected_release']
    record={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before':before,'state':'PREPARING',
            'protocol_sha256':hashlib.sha256((O/'protocol.json').read_bytes()).hexdigest()}
    with (O/'window_started.json').open('x') as f:json.dump(record,f,indent=2)
    child=None;stop_attempted=False
    def interrupted(signum,frame):raise InterruptedError('Signal '+str(signum))
    for sig in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):signal.signal(sig,interrupted)
    try:
        stop_attempted=True
        subprocess.run(['systemctl','stop',UNIT],check=True,timeout=120)
        check=subprocess.run(['systemctl','show',UNIT,'-p','ActiveState','-p','MainPID'],capture_output=True,text=True,check=True)
        assert 'ActiveState=inactive' in check.stdout and 'MainPID=0' in check.stdout,check.stdout
        record['state']='SERVICE_STOPPED';record['stopped_service']=check.stdout
        (O/'window_state.json').write_text(json.dumps(record,indent=2))
        print('SERVICE_STOPPED_BENCHMARK_STARTING',flush=True)
        command=['runuser','-u','jetson','--',PYTHON,'-B',str(O/'code/run_suite.py')]
        record['suite_command']=command
        with (O/'logs/suite.stdout.txt').open('w') as stdout,(O/'logs/suite.stderr.txt').open('w') as stderr:
            child=subprocess.Popen(command,stdout=stdout,stderr=stderr,start_new_session=True)
            record['suite_returncode']=child.wait(timeout=1800)
    except Exception as e:
        record['error']=str(e);record['traceback']=traceback.format_exc()
    finally:
        if child and child.poll() is None:
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=15)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
        if stop_attempted:
            restored=subprocess.run(['systemctl','start',UNIT],capture_output=True,text=True,timeout=120)
            record['restore_command_returncode']=restored.returncode;record['restore_stderr']=restored.stderr
            record['state']='RESTORE_CHECK'
            for _ in range(90):
                try:
                    after=status();record['after']=after
                    h=after['inspection_service'];p=after['plc']['snapshot']
                    if h.get('ready') and h.get('camera_ready') and p.get('connected') and p.get('fresh'):
                        record['state']='RESTORED_READY';break
                except Exception as e:record['last_status_error']=str(e)
                time.sleep(2)
        record['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        (O/'window_result.json').write_text(json.dumps(record,indent=2))
        print(json.dumps({k:record.get(k) for k in ('state','suite_returncode','error','restore_command_returncode')},ensure_ascii=False),flush=True)
    return 0 if record.get('suite_returncode')==0 and record['state']=='RESTORED_READY' else 1

if __name__=='__main__':raise SystemExit(main())
