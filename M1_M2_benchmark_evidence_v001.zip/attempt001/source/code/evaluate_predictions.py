"""CPU adapter to the installed, fingerprinted Ultralytics evaluator."""
from types import SimpleNamespace
import numpy as np
import torch
from ultralytics.engine.validator import BaseValidator
from ultralytics.utils.metrics import ap_per_class, box_iou

def match(predictions, labels, thresholds):
    predicted=torch.tensor([p['class_id'] for p in predictions],dtype=torch.float32)
    targets=torch.tensor([p['class_id'] for p in labels],dtype=torch.float32)
    a=torch.tensor([p['bbox'] for p in labels],dtype=torch.float32).reshape(-1,4)
    b=torch.tensor([p['bbox'] for p in predictions],dtype=torch.float32).reshape(-1,4)
    context=SimpleNamespace(iouv=torch.tensor(thresholds,dtype=torch.float32))
    return BaseValidator.match_predictions(context,predicted,targets,box_iou(a,b),use_scipy=False).numpy()

def evaluate(rows,ground_truth,names):
    assert set(r['image_id'] for r in rows)==set(ground_truth) and len(rows)==len(ground_truth)
    counts=[{'class_id':i,'class_name':name,'gt':0,'tp':0,'fp':0,'fn':0} for i,name in enumerate(names)]
    stats=[]; errors=[]
    for r in rows:
        labels=ground_truth[r['image_id']]; pred=r['operating']
        correct=match(pred,labels,[0.5])[:,0]
        for c in counts:
            cid=c['class_id'];n=sum(x['class_id']==cid for x in labels)
            tp=sum(bool(ok) for p,ok in zip(pred,correct) if p['class_id']==cid)
            fp=sum(p['class_id']==cid for p in pred)-tp
            c['gt']+=n;c['tp']+=tp;c['fp']+=fp;c['fn']+=n-tp
            if fp or n-tp:errors.append({'image_id':r['image_id'],'class_id':cid,'fp':fp,'fn':n-tp})
        low=r['map']
        stats.append((match(low,labels,np.linspace(.5,.95,10)),
                      np.array([p['confidence'] for p in low]),np.array([p['class_id'] for p in low]),
                      np.array([g['class_id'] for g in labels])))
    for c in counts:
        c['precision']=c['tp']/(c['tp']+c['fp']) if c['tp']+c['fp'] else None
        c['recall']=c['tp']/c['gt'] if c['gt'] else None
    correct,conf,pc,tc=[np.concatenate([s[i] for s in stats],axis=0) for i in range(4)]
    apresult=ap_per_class(correct,conf,pc,tc,plot=False,names=dict(enumerate(names)))
    # Do not consume the evaluator's interpolated TP/FP counts or mix max-F1 P/R with fixed-cutoff counts.
    ap,classes=apresult[5],apresult[6]
    by_class=[{'class_id':int(cid),'class_name':names[int(cid)],'map50':float(a[0]),'map50_95':float(a.mean()),'ap_by_iou':a.tolist()} for cid,a in zip(classes,ap)]
    return {'images':len(rows),'fixed_confidence':0.25,'nms_iou':0.45,'matching_iou':0.5,'operating':counts,
            'map_confidence':0.001,'map50':float(ap[:,0].mean()),'map50_95':float(ap.mean()),'ap_per_class':by_class,'errors':errors}
