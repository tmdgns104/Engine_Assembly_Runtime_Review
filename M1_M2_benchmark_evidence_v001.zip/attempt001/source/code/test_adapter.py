"""Fixed CPU cases; no GPU inference, camera, service or PLC activation."""
import hashlib
import inspect
import json
from pathlib import Path
import sys
import unittest

O=Path(__file__).resolve().parents[1]
if (O/'protocol.json').exists():
    overlay=json.loads((O/'protocol.json').read_text()).get('pythonpath')
    if overlay:sys.path.insert(0,overlay)
import numpy as np
sys.path.insert(0,str(O/'source_snapshot'))
from evaluate_predictions import match,evaluate
from src.vision.tensorrt_preprocess import preprocess
from src.vision.tensorrt_postprocess import postprocess

def box(cid=0,confidence=.9):return {'class_id':cid,'confidence':confidence,'bbox':[100.,100.,200.,200.]}

class AdapterTest(unittest.TestCase):
    def test_exact(self):
        self.assertTrue(match([box()],[box()],np.linspace(.5,.95,10)).all())
    def test_empty(self):
        self.assertEqual(match([],[box()],[.5]).shape,(0,1))
        result=evaluate([{'image_id':'x','operating':[],'map':[]}],{'x':[box()]},['part'])
        self.assertEqual(result['operating'][0]['fn'],1);self.assertEqual(result['map50'],0)
    def test_duplicate(self):
        self.assertEqual(int(match([box(),box(confidence=.8)],[box()],[.5]).sum()),1)
        result=evaluate([{'image_id':'x','operating':[box(),box()],'map':[box(),box()]}],{'x':[box()]},['part'])
        self.assertEqual((result['operating'][0]['tp'],result['operating'][0]['fp']), (1,1))
    def test_wrong_class(self):
        self.assertFalse(match([box(1)],[box(0)],[.5]).any())
    def test_no_ground_truth(self):
        self.assertFalse(match([box()],[],[.5]).any())
    def test_perfect_ap(self):
        result=evaluate([{'image_id':'x','operating':[box()],'map':[box()]}],{'x':[box()]},['part'])
        self.assertAlmostEqual(result['map50'],.995,places=6)
        self.assertEqual(result['operating'][0]['precision'],1.)
    def test_letterbox_and_inverse(self):
        image=np.zeros((720,1280,3),dtype=np.uint8);image[:,:,2]=255
        tensor,t=preprocess(image);self.assertEqual(tensor.shape,(1,3,640,640));self.assertEqual(t.padding,(0,140,0,140))
        self.assertEqual(float(tensor[0,0,150,10]),1.);self.assertEqual(float(tensor[0,2,150,10]),0.)
        manifest=json.loads((O/'provenance/M1/manifest.json').read_text())
        output=np.zeros((1,7,8400),np.float32);output[0,:4,0]=[75,215,50,50];output[0,4,0]=.9
        detections=postprocess({'output0':output},manifest['detector']['output'],['gray_pipe','exhaust_top','symbol_module'],.25,.45,t)
        b=detections[0].bounding_box
        self.assertEqual([b.x1,b.y1,b.x2,b.y2],[100.,100.,200.,200.])
    def test_class_aware_nms(self):
        manifest=json.loads((O/'provenance/M1/manifest.json').read_text())
        _,t=preprocess(np.zeros((720,1280,3),np.uint8));output=np.zeros((1,7,8400),np.float32)
        output[0,:4,:3]=np.array([[75,215,50,50]]*3).T
        output[0,4,:2]=[.9,.8];output[0,5,2]=.85
        d=postprocess({'output0':output},manifest['detector']['output'],['a','b','c'],.25,.45,t)
        self.assertEqual([x.class_id for x in d],[0,1])

if __name__=='__main__':unittest.main(verbosity=2)
