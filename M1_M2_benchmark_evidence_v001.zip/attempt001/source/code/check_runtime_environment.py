from pathlib import Path
import json
import os
import subprocess
import sys
B=Path('/home/jetson/oned_device_bench')
pid=int(subprocess.check_output(['systemctl','show','engine-inspector.service','-p','MainPID','--value'],text=True))
allowed=('PYTHONPATH','PYTHONNOUSERSITE','PATH','LD_LIBRARY_PATH','VIRTUAL_ENV','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','YOLO_AUTOINSTALL','YOLO_CONFIG_DIR')
env=dict(v.split('=',1) for v in Path(f'/proc/{pid}/environ').read_bytes().decode().split('\0') if '=' in v)
cfg=json.loads((B/'config/standalone.json').read_text())
print(json.dumps({'allowed_environment':{k:env.get(k) for k in allowed},'configured_pythonpath':cfg.get('pythonpath'),
                  'sys_path_direct':sys.path},indent=2))
