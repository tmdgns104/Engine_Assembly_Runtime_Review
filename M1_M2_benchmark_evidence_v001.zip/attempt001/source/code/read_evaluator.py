"""Inspect the installed evaluator and runtime dependency sources without GPU work."""
import hashlib
import inspect
import json
from pathlib import Path
import subprocess
import sys

import ultralytics
from ultralytics.engine.validator import BaseValidator
from ultralytics.utils.metrics import ap_per_class, box_iou

B = Path('/home/jetson/oned_device_bench/current')
paths = ['src/__init__.py', 'src/vision/__init__.py', 'src/recipe/__init__.py',
         'src/contracts/__init__.py', 'src/contracts/interfaces.py', 'src/contracts/models.py',
         'src/vision/cuda_runtime_ctypes.py', 'src/recipe/package.py',
         'src/vision/tensorrt_native.py', 'src/vision/tensorrt_preprocess.py', 'src/vision/tensorrt_postprocess.py']
sources = {}
for relative in paths:
    p = B/relative
    if p.is_file():
        data = p.read_bytes()
        sources[relative] = {'sha256': hashlib.sha256(data).hexdigest(), 'text': data.decode('utf-8')}
functions = {}
for f in (BaseValidator.match_predictions, ap_per_class, box_iou):
    p = Path(inspect.getfile(f))
    functions[f.__qualname__] = {'path': str(p), 'module_sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
                               'source': inspect.getsource(f)}
owners=[]
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        nodes = sorted({str(fd.resolve()) for fd in (proc/'fd').iterdir() if any(x in str(fd.resolve()) for x in ('/dev/nvhost-gpu', '/dev/nvidia', '/dev/nvmap'))})
        if nodes:
            owners.append({'pid': int(proc.name), 'command': (proc/'cmdline').read_text().replace('\0',' '), 'nodes': nodes})
    except (OSError, PermissionError):
        pass
sudo = subprocess.run(['sudo','-n','-l'],capture_output=True,text=True)
print(json.dumps({'ultralytics_version':ultralytics.__version__, 'functions':functions, 'runtime_sources':sources,
                  'gpu_device_owners_visible_to_user':owners, 'sudo_noninteractive':{'returncode':sudo.returncode,'stdout':sudo.stdout,'stderr':sudo.stderr}},ensure_ascii=False))
