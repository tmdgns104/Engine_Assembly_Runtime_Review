"""Read-only Jetson preflight. Does not start inference or change a service."""
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import time
import urllib.request

B = Path('/home/jetson/oned_device_bench')

def sha(path):
    p = Path(path)
    if not p.is_file():
        return {'path': str(p), 'exists': False}
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': h.hexdigest()}

def run(args, timeout=15):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return {'command': args, 'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}
    except Exception as e:
        return {'command': args, 'error': str(e)}

def read(path):
    try:
        return Path(path).read_text(errors='replace').strip()
    except Exception as e:
        return {'error': str(e)}

def get_status():
    try:
        with urllib.request.urlopen('http://127.0.0.1:18771/api/v1/runtime/status', timeout=10) as response:
            return json.load(response)
    except Exception as e:
        return {'error': str(e)}

out = {'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'hostname': platform.node(), 'machine': platform.machine(), 'python': platform.python_version(),
       'boot_id': read('/proc/sys/kernel/random/boot_id'), 'board': read('/proc/device-tree/model'),
       'l4t': read('/etc/nv_tegra_release'), 'os_release': read('/etc/os-release'),
       'meminfo': read('/proc/meminfo'), 'packages': {}, 'files': {}, 'commands': []}
for name in ('torch', 'torchvision', 'ultralytics', 'tensorrt', 'numpy', 'opencv-python', 'psutil'):
    try:
        out['packages'][name] = importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        out['packages'][name] = None
out['release'] = json.loads((B/'current/release.json').read_text())
for pkg in ('dynamic_parts_005', 'envelope_v007_fp16'):
    base = B/'assets/products/ENGINE_Z3005_5'/pkg
    out['files'][pkg] = {name: sha(base/name) for name in ('model.plan', 'manifest.json', 'preprocessing.json', 'classes.json')}
    for name in ('manifest.json', 'preprocessing.json'):
        out['files'][pkg][name]['content'] = json.loads((base/name).read_text())
out['files']['m2_pt'] = sha(B/'assets/misassembly_runtime/runs/engine_dynamic_pose_002/training/envelope_v004/weights/best.pt')
for rel in ('src/vision/tensorrt_preprocess.py', 'src/vision/tensorrt_postprocess.py', 'src/vision/tensorrt_native.py', 'src/vision/cuda_runtime.py', 'src/contracts.py', 'src/recipe/package.py'):
    out['files'][rel] = sha(B/'current'/rel)
for args in (
    ['systemctl', 'show', 'engine-inspector.service', '-p', 'ActiveState', '-p', 'SubState', '-p', 'MainPID', '-p', 'User', '-p', 'NRestarts'],
    ['df', '-h', str(B)], ['nvpmodel', '-q'], ['jetson_clocks', '--show'],
    ['dpkg-query', '-W', 'nvidia-jetpack', 'nvidia-l4t-core'],
    ['ps', '-eo', 'pid,ppid,comm,args'],
):
    result = run(args)
    if args[0] == 'ps' and 'stdout' in result:
        result['stdout'] = '\n'.join(line for line in result['stdout'].splitlines() if any(token in line for token in ('python', 'tegrastats', 'jtop', 'OpENer')))
    out['commands'].append(result)
out['thermal'] = [{ 'name': read(p/'type'), 'millidegrees_C': read(p/'temp') } for p in Path('/sys/class/thermal').glob('thermal_zone*')]
# Availability/property query only: no tensor allocation, model load or GPU inference.
try:
    import torch
    import cv2
    out['cuda_query'] = {'available': torch.cuda.is_available(), 'torch_version': torch.__version__,
                         'cuda_version': torch.version.cuda, 'cudnn_version': torch.backends.cudnn.version(),
                         'opencv_version': cv2.__version__, 'no_inference_executed': True}
    if torch.cuda.is_available():
        properties = torch.cuda.get_device_properties(0)
        out['cuda_query'].update(name=properties.name, capability=list(torch.cuda.get_device_capability(0)),
                                 total_memory_bytes=properties.total_memory)
except Exception as e:
    out['cuda_query'] = {'error': str(e)}
out['status_observed_monotonic'] = time.monotonic()
out['runtime_status'] = get_status()
print(json.dumps(out, ensure_ascii=False, indent=2))
