"""Freeze only E03 inputs and existing model provenance; no model execution."""
from pathlib import Path
import csv
import datetime
import hashlib
import json
import shutil
import tarfile

O=Path(__file__).resolve().parents[1]
R=Path('D:/OneDevice_Team_project')
P=Path('D:/OneDevice_Worktrees/jetson-p0-004c0/runs/manual_tracking_dev/engine_parts_CFA8507_v001/outputs/run_20260921T082749Z_709634')
D=R/'runs/engine_dynamic_pose_002'
REMOTE='/home/jetson/oned_device_bench/tmp/benchmark_m1_m2_20261019_v001'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x): Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    if (O/'protocol.json').exists(): raise RuntimeError('Protocol already frozen; preserve it.')
    stage=O/'_transport'; stage.mkdir(exist_ok=True)
    source_rows=json.loads((P/'annotations_used.json').read_text('utf-8'))['items']
    rows=sorted((x for x in source_rows if x['split']=='val'),key=lambda x:x['review_id'])
    assert len(rows)==72 and [x['review_id'] for x in rows]==[f'D{i:03}' for i in range(145,217)]
    assert all(x['round_id']=='E03' for x in rows)
    env=json.loads((O/'environment.json').read_text('utf-8'))
    assert env['release']['release_id']=='engine-integrated-32c484ac6aeb07f1'
    models={}
    definitions=[('M1','dynamic_parts_005',P/'models/engine_parts_best.pt',D/'engine_parts.onnx',D/'parts_fp16_head32_v001/build_manifest.json',R/'runs/engine_package_integration_001/controlled_export.json'),
                 ('M2','envelope_v007_fp16',D/'training/envelope_v004/weights/best.pt',D/'envelope_export_v004/envelope_best.onnx',D/'envelope_fp16_backbone32_v007/build_manifest.json',D/'envelope_export.json')]
    for name,pkg,pt,onnx,build,export in definitions:
        package=R/'jetson/products/ENGINE_Z3005_5'/pkg
        manifest=json.loads((package/'manifest.json').read_text('utf-8'))
        names=[x['name'] for x in json.loads((package/'classes.json').read_text('utf-8'))['classes']]
        plan=package/'model.plan'; b=json.loads(build.read_text('utf-8'))
        hashes={k:{'source_path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for k,p in [('pt',pt),('onnx',onnx),('trt',plan)]}
        assert hashes['trt']['sha256']==env['files'][pkg]['model.plan']['sha256']==b['plan_sha256']
        assert hashes['onnx']['sha256']==b['onnx_sha256']
        assert sha(package/'manifest.json')==env['files'][pkg]['manifest.json']['sha256']
        target=O/'provenance'/name;target.mkdir(parents=True,exist_ok=True)
        copies=[(package/n,n) for n in ('manifest.json','classes.json','preprocessing.json')]+[(build,'build_manifest.json'),(export,'export.json')]
        for src,dst in copies: shutil.copyfile(src,target/dst)
        pt_stage=stage/'weights'/f'{name}.pt';pt_stage.parent.mkdir(exist_ok=True);shutil.copyfile(pt,pt_stage)
        models[name]={'package':pkg,'names':names,'hashes':hashes,'pt_path':f'{REMOTE}/weights/{name}.pt',
                      'plan_path':f'/home/jetson/oned_device_bench/assets/products/ENGINE_Z3005_5/{pkg}/model.plan',
                      'manifest':manifest,'precision_note':'FP16 enabled with explicit FP32 '+('head' if name=='M1' else 'backbone')+' layers; see build_manifest.json'}
    input_rows=[];ground_truth={k:{} for k in models}
    for r in rows:
        ident=r['review_id']; img=P/'dataset/images/val'/f'{ident}.png';other=D/'dataset_v004/images/val'/f'{ident}.png'
        assert sha(img)==r['image_sha256']==sha(other)
        image_out=stage/'images'/img.name;image_out.parent.mkdir(exist_ok=True);shutil.copyfile(img,image_out)
        item={'image_id':ident,'split':'val','round_id':'E03','scenario':r['scenario_capture_truth'],
              'image_path':str(img),'m2_image_path':str(other),'image_sha256':sha(img),'image_bytes':img.stat().st_size,
              'remote_image':f'{REMOTE}/images/{img.name}','width':1280,'height':720}
        for name,base in [('M1',P/'dataset'),('M2',D/'dataset_v004')]:
            label=base/'labels/val'/f'{ident}.txt'
            boxes=[]
            for line in label.read_text('utf-8').splitlines():
                if not line.strip():continue
                cid,cx,cy,w,h=map(float,line.split())
                assert cid==int(cid) and 0<=cid<len(models[name]['names']) and 0<=cx<=1 and 0<=cy<=1 and 0<w<=1 and 0<h<=1
                boxes.append({'class_id':int(cid),'bbox':[(cx-w/2)*1280,(cy-h/2)*720,(cx+w/2)*1280,(cy+h/2)*720]})
            ground_truth[name][ident]=boxes
            item[name.lower()+'_label_path']=str(label);item[name.lower()+'_label_sha256']=sha(label);item[name.lower()+'_boxes']=len(boxes)
            dest=O/'ground_truth'/name/label.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(label,dest)
        input_rows.append(item)
    assert len({x['image_sha256'] for x in input_rows})==72
    assert sum(x['m1_boxes'] for x in input_rows)==192 and sum(x['m2_boxes'] for x in input_rows)==72
    with (O/'input_manifest.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(input_rows[0]));w.writeheader();w.writerows(input_rows)
    save(O/'ground_truth.json',ground_truth);save(O/'model_hashes.json',models)
    observed=json.loads((O/'evaluator_source.json').read_text('utf-8'))
    runtime_hashes={k:v['sha256'] for k,v in observed['runtime_sources'].items()}
    # Include the enums imported by contracts, preserving exactly the operating source hash from release.
    p=R/'jetson/src/contracts/enums.py'
    source=O/'source_snapshot/src/contracts/enums.py';shutil.copyfile(p,source);runtime_hashes['src/contracts/enums.py']=sha(p)
    for relative,v in observed['runtime_sources'].items(): assert sha(O/'source_snapshot'/relative)==v['sha256']
    order=[]
    for repetition in (1,2,3):
        for model in ('M1','M2'):
            for backend in (('PT','TRT') if repetition!=2 else ('TRT','PT')):
                order.append({'run_id':f'{model}_{backend}_r{repetition}','model':model,'backend':backend,'repetition':repetition})
    protocol={'schema_version':1,'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'scope':'same Jetson, E03 development validation; not independent final test or PLC/camera pipeline',
      'remote_root':REMOTE,'runtime_root':'/home/jetson/oned_device_bench/current','expected_release':env['release']['release_id'],
      'models':models,'inputs':input_rows,'ground_truth_sha256':sha(O/'ground_truth.json'),'runtime_source_hashes':runtime_hashes,
      'environment_sha256':sha(O/'environment.json'),'power_mode':'25W mode 1, unchanged, no clock lock changes',
      'preprocess':{'reuse':'src.vision.tensorrt_preprocess.preprocess','shape':[1,3,640,640],'dtype':'float32','BGR_to_RGB':True,'normalization':'/255','letterbox':'center, linear,114,auto=False,scaleup=True'},
      'postprocess':{'reuse':'src.vision.tensorrt_postprocess.postprocess','confidence':0.25,'map_confidence':0.001,'comparison':'>','nms_iou':0.45,'class_aware':True,'max_det':300,'multiple_labels_per_candidate':False,'inverse':'saved gain/padding, clip to original'},
      'pt':{'dtype':'float32','eval':True,'inference_mode':True,'fuse':True,'AMP':False,'TF32':False,'cudnn_benchmark':False,'torch_num_threads':1,'cv2_num_threads':1},
      'measurement':{'warmup_calls':50,'iterations':360,'cycles':5,'repetitions':3,'order':order,
                     'timing':'perf_counter_ns immediately before shared preprocess through completed GPU inference, CPU output and shared postprocess; excludes file I/O/decode/logging',
                     'throughput':'completed image count / measured loop wall time (includes small in-memory timing-bookkeeping cost); count/sum(per-call intervals) retained separately',
                     'synchronization':'PT cuda.synchronize before/after full call; TRT native stream synchronize after enqueue and D2H',
                     'gpu_kernel_only':'UNMEASURED: no common verified CUDA event instrumentation',
                     'accuracy':'one additional 72-image sweep in repetition 1 of each condition; reuse raw output for both thresholds, no timing claims for sweep',
                     'discard_outliers':False,'cooldown_seconds_between_processes':5,'stop_on_first_run_failure':True},
      'memory':{'sample_interval_seconds':0.1,'source':'/proc/self/status VmRSS and /proc/meminfo MemTotal-MemAvailable','baseline':'inputs decoded and libraries imported; before model construction','phases':['baseline','load','first_call','warmup','measure','accuracy','cleanup'],'sampled_max_not_instantaneous_peak':True,'tegrastats_interval_ms':100,'no_summing_memory_domains':True},
      'accuracy':{'evaluator_version':observed['ultralytics_version'],'evaluator_function_hashes':{k:v['module_sha256'] for k,v in observed['functions'].items()},
                  'matching':'Ultralytics BaseValidator.match_predictions use_scipy=False: class-compatible IoU descending, unique prediction then unique GT per threshold',
                  'operating_gt_iou':0.5,'map_gt_ious':[round(.5+.05*i,2) for i in range(10)],'ap':'ultralytics.utils.metrics.ap_per_class; fixed-cutoff TP/FP/FN counted directly, not AP-derived'},
      'invalid_run_policy':'keep all errors/logs; no selective repeats or dropping unfavorable values; failed run prevents full completion',
      'approval':'User: STOP 유지, 정지·측정·복구 승인. No model/config/power/PLC changes.',
      'code_hashes':{p.name:sha(p) for p in (O/'code').glob('*.py') if p.name not in ('prepare_protocol.py','remote_tools.py')}}
    save(O/'protocol.json',protocol)
    save(O/'preparation_verification.json',{'status':'PASS','e03_images':72,'m1_boxes':192,'m2_boxes':72,'protected_images_used':0,'unique_images':72,'model_hashes_match_operating_observation':True})
    print(json.dumps({'inputs':72,'M1_boxes':192,'M2_boxes':72,'order':order,'protocol_sha256':sha(O/'protocol.json')},ensure_ascii=False))

if __name__=='__main__':main()
