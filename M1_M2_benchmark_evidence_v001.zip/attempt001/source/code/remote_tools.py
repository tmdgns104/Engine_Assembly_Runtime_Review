"""Copy only benchmark artifacts; run CPU checks; inspect/retrieve this task's files."""
from pathlib import Path
import argparse
import io
import json
import subprocess
import tarfile
import hashlib

O=Path(__file__).resolve().parents[1]
REMOTE='/home/jetson/oned_device_bench/tmp/benchmark_m1_m2_20261019_v001'
SSH=['ssh','-i','C:/Users/user/.ssh/oned_device_jetson_bench_ed25519','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=10','jetson@100.119.148.89']
PY='/home/jetson/oned_device_bench/envs/app_v1/bin/python'

def remote(script,label,timeout=120):
    cmd=SSH+[PY+' -B -'];r=subprocess.run(cmd,input=script.encode(),capture_output=True,timeout=timeout)
    (O/'logs'/f'{label}.stdout.txt').write_bytes(r.stdout);(O/'logs'/f'{label}.stderr.txt').write_bytes(r.stderr)
    (O/'logs'/f'{label}.command.json').write_text(json.dumps(cmd,indent=2))
    if r.returncode:print(r.stderr.decode(errors='replace')[-1800:]);raise SystemExit(r.returncode)
    return r.stdout

def main(mode):
    if mode=='stage':
        archive=O/'_transport'/'benchmark_inputs.tar'
        with tarfile.open(archive,'w') as tf:
            for directory in ('code','source_snapshot','provenance'):
                for p in (O/directory).rglob('*'):
                    if p.is_file():tf.add(p,arcname=p.relative_to(O),recursive=False)
            for name in ('protocol.json','ground_truth.json','model_hashes.json','input_manifest.csv'):
                tf.add(O/name,arcname=name,recursive=False)
            for directory in ('images','weights'):
                for p in (O/'_transport'/directory).iterdir():tf.add(p,arcname=directory+'/'+p.name,recursive=False)
        setup=f"from pathlib import Path\np=Path({REMOTE!r})\np.mkdir(exist_ok=False)\n(p/'logs').mkdir()\nprint(p)\n"
        print(remote(setup,'stage_mkdir').decode().strip())
        cmd=SSH+[f'tar -xf - -C {REMOTE}']
        with archive.open('rb') as f:r=subprocess.run(cmd,stdin=f,capture_output=True,timeout=180)
        (O/'logs/stage_tar.stderr.txt').write_bytes(r.stderr)
        if r.returncode:raise SystemExit(r.returncode)
        print(json.dumps({'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
    elif mode=='tests':
        script=f'''import subprocess,json,os,hashlib
from pathlib import Path
p=Path({REMOTE!r})
os.environ.update(YOLO_AUTOINSTALL='false',YOLO_CONFIG_DIR=str(p/'ultralytics_config'),CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
r=subprocess.run([{PY!r},'-B',str(p/'code/test_adapter.py')],capture_output=True,text=True)
(p/'logs/adapter.stdout.txt').write_text(r.stdout);(p/'logs/adapter.stderr.txt').write_text(r.stderr)
result={{'status':'PASS' if r.returncode==0 else 'FAIL','returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'GPU_inference':False}}
(p/'adapter_tests.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
'''
        data=remote(script,'adapter_cpu');(O/'adapter_tests.json').write_bytes(data);print(data.decode())
    elif mode=='status':
        script=f'''from pathlib import Path
import json
p=Path({REMOTE!r})
for name in ('suite_progress.json','suite_result.json','window_result.json'):
 if (p/name).exists():
  d=json.loads((p/name).read_text())
  if name=='window_result.json':d={{k:d.get(k) for k in ('state','suite_returncode','error','restore_command_returncode')}}
  print(json.dumps({{'file':name,'value':d}}))
'''
        print(remote(script,'progress').decode())
    elif mode=='collect':
        script=f'''from pathlib import Path
import sys,tarfile
p=Path({REMOTE!r})
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|') as tf:
 for folder in ('results','logs'):
  for f in (p/folder).rglob('*'):
   if f.is_file():tf.add(f,arcname=str(f.relative_to(p)),recursive=False)
 for name in ('suite_progress.json','suite_result.json','window_started.json','window_result.json','adapter_tests.json'):
  if (p/name).is_file():tf.add(p/name,arcname=name,recursive=False)
'''
        data=remote(script,'results_archive',timeout=180)
        with tarfile.open(fileobj=io.BytesIO(data)) as tf:
            for m in tf.getmembers():
                target=(O/'remote_results'/m.name).resolve()
                if not target.is_relative_to((O/'remote_results').resolve()) or not m.isfile():raise ValueError(m.name)
                target.parent.mkdir(parents=True,exist_ok=True)
                if target.exists():raise RuntimeError('Preserve previous collection: '+str(target))
                target.write_bytes(tf.extractfile(m).read())
        print(json.dumps({'retrieved_bytes':len(data),'files':len(tf.getmembers())}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['stage','tests','status','collect']);main(p.parse_args().mode)
