"""Reuse the already configured runtime overlay; no package installation."""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile
import subprocess
from remote_tools import remote,SSH,REMOTE,O

payload='''import json,sys,hashlib,inspect,os
from pathlib import Path
B=Path('/home/jetson/oned_device_bench')
config=json.loads((B/'config/standalone.json').read_text())
overlay=(B/'config'/config['pythonpath']).resolve()
sys.path.insert(0,str(overlay))
os.environ['CUDA_VISIBLE_DEVICES']=''
os.environ['YOLO_AUTOINSTALL']='false'
import numpy as np,torch,cv2,ultralytics
from ultralytics.engine.validator import BaseValidator
from ultralytics.utils.metrics import ap_per_class,box_iou
a=np.array([1,2],dtype=np.float32)
assert np.array_equal(torch.from_numpy(a).numpy(),a)
print(json.dumps({'pythonpath':str(overlay),'config_sha256':hashlib.sha256((B/'config/standalone.json').read_bytes()).hexdigest(),
 'versions':{m.__name__:{'version':m.__version__,'path':m.__file__} for m in (np,torch,cv2,ultralytics)},
 'evaluator_hashes':{f.__qualname__:hashlib.sha256(Path(inspect.getfile(f)).read_bytes()).hexdigest() for f in (BaseValidator.match_predictions,ap_per_class,box_iou)},
 'numpy_torch_cpu_roundtrip':'PASS','no_inference':True}))
'''
data=remote(payload,'effective_environment')
effective=json.loads(data);(O/'environment_effective.json').write_bytes(data)
history=O/'protocol_revisions';history.mkdir(exist_ok=True)
shutil.copyfile(O/'protocol.json',history/'000_preflight_before_overlay.json')
shutil.copyfile(O/'adapter_tests.json',history/'000_adapter_tests_failed.json')
p=json.loads((O/'protocol.json').read_text('utf-8'))
p['pythonpath']=effective['pythonpath'];p['effective_environment_sha256']=hashlib.sha256(data).hexdigest()
p['accuracy']['evaluator_function_hashes']=effective['evaluator_hashes']
p['pre_execution_revision']={'number':1,'reason':'Reuse existing runtime numpy compatibility overlay; initial CPU adapter failed due to direct-shell NumPy2. No GPU benchmark yet.'}
p['code_hashes']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (O/'code').glob('*.py') if f.name not in ('prepare_protocol.py','remote_tools.py','fix_overlay_preflight.py')}
(O/'protocol.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
archive=O/'_transport/overlay_fix.tar'
with tarfile.open(archive,'w') as tf:
    for f in (O/'code').glob('*.py'):tf.add(f,arcname='code/'+f.name,recursive=False)
    tf.add(O/'protocol.json',arcname='protocol.json',recursive=False)
preserve=f'''from pathlib import Path
import shutil
p=Path({REMOTE!r});(p/'protocol_revisions').mkdir(exist_ok=True)
for a,b in [('protocol.json','000_preflight_before_overlay.json'),('adapter_tests.json','000_adapter_tests_failed.json')]:
 shutil.copyfile(p/a,p/'protocol_revisions'/b)
(p/'ultralytics_config').mkdir(exist_ok=True)
'''
remote(preserve,'preserve_preflight_revision')
with archive.open('rb') as f:r=subprocess.run(SSH+[f'tar -xf - -C {REMOTE}'],stdin=f,capture_output=True,timeout=60)
if r.returncode:raise RuntimeError(r.stderr.decode())
print(json.dumps(effective,ensure_ascii=False,indent=2))
