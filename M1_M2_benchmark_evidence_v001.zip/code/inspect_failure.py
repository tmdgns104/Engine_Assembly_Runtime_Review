from remote_tools import remote,O,REMOTE
import json
script=f'''from pathlib import Path
import json,subprocess
p=Path({REMOTE!r})
d={{}}
for name in ('results/M2_PT_r1/run.json','window_result.json'):
 if (p/name).exists():
  v=json.loads((p/name).read_text())
  if name=='window_result.json':v={{k:v.get(k) for k in ('state','suite_returncode','error','restore_command_returncode','last_status_error')}}
  d[name]=v
d['stderr']=(p/'logs/M2_PT_r1.stderr.txt').read_text()[-4000:]
d['service']=subprocess.run(['systemctl','show','engine-inspector.service','-p','ActiveState','-p','SubState','-p','MainPID','-p','NRestarts'],capture_output=True,text=True).stdout
print(json.dumps(d))
'''
d=json.loads(remote(script,'failure_inspection'));(O/'first_suite_failure.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(d,ensure_ascii=False,indent=2))
