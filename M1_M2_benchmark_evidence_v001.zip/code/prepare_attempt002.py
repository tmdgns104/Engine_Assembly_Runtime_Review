"""Preserve aborted attempt; add a symmetric evaluation-only zero-area adapter."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess
import tarfile
from remote_tools import remote,SSH,O
OLD='/home/jetson/oned_device_bench/tmp/benchmark_m1_m2_20261019_v001'
NEW=OLD+'_attempt002'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

source=(O/'source_snapshot/src/vision/tensorrt_postprocess.py').read_text('utf-8')
old='if not np.isfinite(box).all() or box[0] >= box[2] or box[1] >= box[3]:'
assert source.count(old)==1
source=source.replace(old,'if not np.isfinite(box).all():')
source='# Evaluation-only: retain clipped zero-area candidates as FP, never suppress them.\n# All NMS, ordering, clipping and coordinates otherwise unchanged from source_snapshot.\n'+source
(O/'code/evaluation_postprocess.py').write_text(source,encoding='utf-8',newline='')
history=O/'protocol_revisions';shutil.copyfile(O/'protocol.json',history/'001_initial_gpu_attempt.json')
first=O/'attempt001';first.mkdir(exist_ok=False)
shutil.move(str(O/'remote_results'),str(first/'remote_results'))
save_old=f'''from pathlib import Path
import tarfile,sys
p=Path({OLD!r})
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|') as tf:
 for f in (p/'code').glob('*.py'):tf.add(f,arcname='code/'+f.name,recursive=False)
 for n in ('protocol.json','adapter_tests.json'):tf.add(p/n,arcname=n,recursive=False)
'''
data=remote(save_old,'initial_code_archive')
import io
with tarfile.open(fileobj=io.BytesIO(data)) as tf:
    for member in tf.getmembers():
        target=(first/'source'/member.name).resolve()
        assert target.is_relative_to((first/'source').resolve()) and member.isfile()
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(tf.extractfile(member).read())
p=json.loads((O/'protocol.json').read_text('utf-8'))
p['remote_root']=NEW
for m in p['models'].values():m['pt_path']=m['pt_path'].replace(OLD,NEW)
for r in p['inputs']:r['remote_image']=r['remote_image'].replace(OLD,NEW)
p['frozen_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
p['pre_execution_revision']={'number':2,'reason':'M2 low cutoff produced zero-area clipped prediction. Preserve it as FP in evaluation-only shared adapter; production/latency postprocessing unchanged. Full balanced suite repeated, all initial attempts retained.'}
p['accuracy']['zero_area_policy']='For mAP only, cloned native postprocess retains zero-area candidates after clipping. IoU=0, counted FP. Same PT/TRT function, no candidate deletion. Native rejection and raw output preserved.'
p['accuracy']['adapter_original_sha256']=sha(O/'source_snapshot/src/vision/tensorrt_postprocess.py')
p['accuracy']['adapter_sha256']=sha(O/'code/evaluation_postprocess.py')
p['code_hashes']={f.name:sha(f) for f in (O/'code').glob('*.py') if f.name in ('benchmark_worker.py','evaluate_predictions.py','evaluation_postprocess.py','test_adapter.py','run_suite.py','service_window.py')}
(O/'protocol.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
newmodels=json.loads((O/'model_hashes.json').read_text('utf-8'))
for m in newmodels.values():m['pt_path']=m['pt_path'].replace(OLD,NEW)
(O/'model_hashes.json').write_text(json.dumps(newmodels,ensure_ascii=False,indent=2),encoding='utf-8')
setup=f'''from pathlib import Path
import os,shutil
old=Path({OLD!r});new=Path({NEW!r});new.mkdir(exist_ok=False)
for n in ('logs','ultralytics_config'): (new/n).mkdir()
for folder in ('images','weights'):
 (new/folder).mkdir()
 for f in (old/folder).iterdir():os.link(f,new/folder/f.name)
for folder in ('source_snapshot','provenance'):shutil.copytree(old/folder,new/folder)
for name in ('ground_truth.json','input_manifest.csv'):shutil.copyfile(old/name,new/name)
'''
remote(setup,'setup_attempt002')
archive=O/'_transport/attempt002_code.tar'
with tarfile.open(archive,'w') as tf:
    for f in (O/'code').glob('*.py'):tf.add(f,arcname='code/'+f.name,recursive=False)
    for name in ('protocol.json','model_hashes.json'):tf.add(O/name,arcname=name,recursive=False)
with archive.open('rb') as f:r=subprocess.run(SSH+[f'tar -xf - -C {NEW}'],stdin=f,capture_output=True,timeout=60)
assert r.returncode==0,r.stderr
# Controller helpers now address the new attempt; the old remote folder remains untouched.
path=O/'code/remote_tools.py';text=path.read_text('utf-8');text=text.replace("REMOTE='"+OLD+"'","REMOTE='"+NEW+"'");path.write_text(text,encoding='utf-8')
print(json.dumps({'new_remote_root':NEW,'protocol_sha256':sha(O/'protocol.json'),'initial_attempt_preserved':True}))
