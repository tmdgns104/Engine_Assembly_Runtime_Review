"""Read-only post-benchmark check; no model load, camera open, or PLC writes."""
from pathlib import Path
import datetime
import json

from remote_tools import O, remote

protocol = json.loads((O / 'protocol.json').read_text('utf-8'))
before = json.loads((O / 'environment.json').read_text('utf-8'))
effective = json.loads((O / 'environment_effective.json').read_text('utf-8'))
expected = {}
for package in ('dynamic_parts_005', 'envelope_v007_fp16'):
    for name, item in before['files'][package].items():
        expected[item['path']] = item['sha256']
for relative, digest in protocol['runtime_source_hashes'].items():
    expected[protocol['runtime_root'] + '/' + relative] = digest

payload = '''import datetime,hashlib,json,subprocess,os
from pathlib import Path
expected = EXPECTED
files=[]
for name,digest in expected.items():
 p=Path(name); actual=hashlib.sha256(p.read_bytes()).hexdigest()
 files.append({'path':name,'before_sha256':digest,'after_sha256':actual,'unchanged':actual==digest})
base=Path('/home/jetson/oned_device_bench')
active=[]
for p in Path('/proc').glob('[0-9]*/cmdline'):
 try: cmd=p.read_bytes().decode(errors='replace').replace(chr(0),' ')
 except (OSError,ProcessLookupError): continue
 if any(x in cmd for x in ('/code/benchmark_worker.py','/code/run_suite.py','/code/service_window.py')):
  active.append({'pid':int(p.parent.name),'command':cmd})
service=subprocess.run(['systemctl','show','engine-inspector.service','-p','ActiveState','-p','MainPID','-p','NRestarts'],capture_output=True,text=True)
power=subprocess.run(['nvpmodel','-q'],capture_output=True,text=True)
print(json.dumps({'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'files':files,'release':json.loads((base/'current/release.json').read_text()),
 'config_sha256':hashlib.sha256((base/'config/standalone.json').read_bytes()).hexdigest(),
 'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
 'active_benchmark_processes':active,'service':service.stdout,'power_mode':power.stdout}))
'''.replace('EXPECTED', repr(expected))
result = json.loads(remote(payload, 'operating_after'))
# Existing effective-environment evidence stores the exact config digest.
config_before = 'f128f7999c9bdec4a973a22eade5e1042c15436e3b9e6a91f6ebd834bf240a91'
checks = {
    'model_package_and_reused_source_hashes_unchanged': all(x['unchanged'] for x in result['files']),
    'release_unchanged': result['release']['release_id'] == before['release']['release_id'],
    'config_unchanged': result['config_sha256'] == config_before,
    'no_reboot': result['boot_id'] == before['boot_id'],
    'no_remaining_benchmark_processes': not result['active_benchmark_processes'],
    'same_service_active': 'ActiveState=active' in result['service'],
}
result.update(checks=checks, config_before_sha256=config_before)
result['status'] = 'PASS' if all(checks.values()) else 'FAIL'
out = O / 'operating_after_verification.json'
if out.exists():
    raise RuntimeError('Preserve existing evidence: ' + str(out))
out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'status':result['status'], 'checks':checks, 'release':result['release']['release_id'],
                  'files_checked':len(result['files']), 'service':result['service'],
                  'power_mode':result['power_mode']}, ensure_ascii=False))
assert all(checks.values()), checks
