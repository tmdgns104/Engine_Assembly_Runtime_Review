"""Build Korean evidence report and independently verify each ZIP member."""
from pathlib import Path
import csv
import datetime
import hashlib
import json
import re
import zipfile
import io
import sys

O=Path(__file__).resolve().parents[1]
def load(p):return json.loads(Path(p).read_text('utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def rows(p):return list(csv.DictReader(Path(p).open(encoding='utf-8-sig',newline='')))
def mdtable(head,data):return '| '+' | '.join(head)+' |\n|'+'|'.join('---' for _ in head)+'|\n'+'\n'.join('| '+' | '.join(str(x) for x in r)+' |' for r in data)+'\n'

def main():
    summary=load(O/'measurement_summary.json');protocol=load(O/'protocol.json');env=load(O/'environment_effective.json')
    assert summary['status']=='MEASUREMENT_COMPLETE'
    lat=summary['latency_totals'];acc=summary['accuracy'];memory=rows(O/'memory_summary.csv')
    initial=load(O/'environment.json');window=load(O/'remote_results/window_result.json')
    after=load(O/'operating_after_verification.json')
    audit=load(O/'collected_evidence_verification.json')
    assert audit['status']=='PASS'
    restore_files=sorted(O.glob('restore_observation_*.json'),key=lambda p:p.stat().st_mtime)
    restore=load(restore_files[-1]);current=restore['observations'][-1]
    live=current['ipc_health_latest']['IPC_HEALTH_SENT']
    service_restored=(current['inspection_service']['camera_ready'] and current['inspection_service']['worker_alive'] and live['ready'] and current['monotonic']-live['monotonic_s']<.5)
    frames=[x['latest_frame']['frame_id'] for x in restore['observations']]
    service_restored=bool(service_restored and len(set(frames))==3 and after['status']=='PASS' and window['state']=='RESTORED_READY')
    checks={'measurement_complete':True,'operating_service_restored_ready':service_restored,'four_accuracy_conditions':len(acc)==4,
            'latency_rows_4320':len(rows(O/'latency_raw.csv'))==4320,'class_rows_8':len(rows(O/'accuracy_by_class.csv'))==8,
            'protected_test_images_used':0,'protocol_sha256':sha(O/'protocol.json')}
    # The export documents must connect original PT -> ONNX -> actual plan, not merely names.
    model_hash_checks=[]
    for model in ('M1','M2'):
        m=protocol['models'][model];export=load(O/'provenance'/model/'export.json');build=load(O/'provenance'/model/'build_manifest.json')
        source_pt=export['source_pt_sha256'] if model=='M1' else export['pt_sha256']
        if model=='M1':
            # Export structure is retained; require the exact ONNX hash somewhere in its JSON tree.
            export_has_onnx=m['hashes']['onnx']['sha256'] in json.dumps(export)
        else:export_has_onnx=export['source_onnx']['sha256']==m['hashes']['onnx']['sha256']
        ok=source_pt==m['hashes']['pt']['sha256'] and export_has_onnx and build['onnx_sha256']==m['hashes']['onnx']['sha256'] and build['plan_sha256']==m['hashes']['trt']['sha256']
        assert ok
        model_hash_checks.append({'model':model,'hash_chain_verified':ok,**{k:v['sha256'] for k,v in m['hashes'].items()}})
    save(O/'model_hash_verification.json',model_hash_checks)
    # Ensure every example reference resolves and its original and GT copies match provenance.
    examples=rows(O/'examples.csv')
    for r in examples:
        for key in ('original','m1_ground_truth','m2_ground_truth','predictions','comparison'):assert (O/r[key]).is_file(),r[key]
        assert sha(O/r['original'])==r['source_image_sha256']==sha(r['source_image'])
        source=next(x for x in protocol['inputs'] if x['image_id']==r['image_id'])
        for model in ('m1','m2'):assert sha(O/r[model+'_ground_truth'])==source[model+'_label_sha256']
    inputrows=protocol['inputs']
    # The explicit input manifest reflects the paths actually used in this final campaign.
    with (O/'input_manifest.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(inputrows[0]));w.writeheader();w.writerows(inputrows)
    for r in inputrows:
        assert r['round_id']=='E03' and r['split']=='val'
        assert sha(r['image_path'])==sha(r['m2_image_path'])==r['image_sha256']
        for k in ('m1','m2'):assert sha(r[k+'_label_path'])==r[k+'_label_sha256']
    native_rejections=[]
    for model in ('M1','M2'):
        for backend in ('PT','TRT'):
            pr=load(O/f'remote_results/results/{model}_{backend}_r1/predictions.json')['rows']
            for r in pr:
                if r.get('native_low_cutoff_error'):native_rejections.append({'model':model,'backend':backend,'image_id':r['image_id'],'error':r['native_low_cutoff_error'],'retained_zero_area_predictions':r['map_zero_area_predictions']})
    save(O/'low_cutoff_native_rejections.json',native_rejections)
    text='# M1·M2 최적화 전후 Benchmark 증빙\n\n'
    text+='같은 Jetson Orin Nano에서 원본 PT FP32와 현재 운영 TensorRT를 비교한 **E03 개발 검증 Benchmark**입니다. 독립 최종시험, 카메라 FPS, PLC 응답시간, 전체 검사 시스템 성능을 뜻하지 않습니다.\n\n'
    text+='## 1. 실제 완료 범위\n\n'
    text+=f'- 네 조건 × 새 프로세스 3회 = **12회**, 각 예열50회·본 측정360회, 총 **4,320개 지연시간**. 서로 다른 원본은 **72장**입니다.\n'
    text+='- 각 조건의 첫 반복에서 별도로 72장 전체를 추론해 confidence0.25 고정 지표와 confidence0.001 mAP를 계산했습니다.\n'
    text+=f'- 최초 중단 시도 3회(1,080개 시간 측정 포함)는 `attempt001/`에 모두 보존했습니다. 두 번째 프로토콜은 낮은 cutoff 평가 연결을 수정한 뒤 전체 12회를 사전에 고정했으며, 불리한 시간값을 제거하지 않았습니다.\n'
    text+=f'- 모델·운영코드·config.py·서비스 설정·전력 모드 변경, 새 학습·변환·PLC 운전은 수행하지 않았습니다. 운영 서비스 복구 준비 확인: **{"PASS" if service_restored else "UNVERIFIED / 복구 확인 필요"}**.\n\n'
    text+='## 2. 장치와 비교 조건\n\n'
    text+=mdtable(['항목','실제 조건'],[
      ['장치',f"{initial['hostname']} / {initial['board'].replace(chr(0),'')} / aarch64"],
      ['릴리스',protocol['expected_release']],['OS/L4T','Ubuntu 22.04, L4T 36.4.7; nvidia-jetpack 메타 패키지 미설치로 해당 패키지 버전은 미확인'],
      ['라이브러리','Python '+initial['python']+' / torch2.8.0 / CUDA12.6 / TensorRT10.3.0 / Ultralytics8.4.118 / NumPy1.26.4 / OpenCV5.0.0'],
      ['호환 환경',protocol['pythonpath']+' (기존 운영 경로 재사용, 설치 없음)'],
      ['전력·클록','기존25W mode1 유지. 클록 고정 변경 없음; jetson_clocks --show는 비root 권한 제한. 실제 tegrastats 원문 제공'],
      ['동시 작업','운영 service 정지 후 Python/CUDA 점유자 검사. 기존 GNOME 데스크톱 유지; 다른 ML backend 동시 적재 없음'],
      ['입력','E03 D145–D216, 72장, 1280×720, batch1 → [1,3,640,640]'],
      ['전처리','기존 letterbox, linear, padding114, BGR→RGB, /255, float32, crop/증강 없음'],
      ['PT','원본가중치 eval + fuse + inference_mode, float32, AMP OFF, TF32 OFF'],
      ['TRT','기존 native .plan. M1 FP16+head FP32 / M2 FP16+backbone FP32. 순수 FP16 아님'],
      ['후처리','기존 class-aware NMS0.45, max_det300, argmax 단일 클래스, 동일 역좌표 변환'],
      ['시간 경계','메모리 원본 → 전처리 → GPU 완료 → CPU 출력·NMS 완료. 파일읽기/디코딩/그림저장 제외'],
      ['동기화','PT torch.cuda.synchronize, TRT 기존 executor stream sync와 D2H 완료. 순수 GPU 커널 시간 미측정'],
      ['처리량','완료 건수 / 측정 루프 실제 경과시간. 개별 구간 합 기반 보조 처리량은 run.json에 별도'],
      ['메모리','100ms /proc RSS·MemTotal-MemAvailable 및 tegrastats. 모델 로드 전 입력·라이브러리 준비 기준. 서로 합산하지 않음']])
    text+='\n## 3. 지연시간·처리량\n\n'
    text+=mdtable(['모델','Backend','개수','평균 ms','p50 ms','p95 ms','최소/최대 ms','처리량 image/s'],[
      [x['model'],x['backend'],x['completed_images'],f"{x['mean_ms']:.3f}",f"{x['p50_ms']:.3f}",f"{x['p95_ms']:.3f}",f"{x['min_ms']:.3f} / {x['max_ms']:.3f}",f"{x['throughput_images_s']:.2f}"] for x in lat])
    for model in ('M1','M2'):
        pt=next(x for x in lat if x['model']==model and x['backend']=='PT');trt=next(x for x in lat if x['model']==model and x['backend']=='TRT')
        text+=f"\n- {model}: 평균 지연 {100*(1-trt['mean_ms']/pt['mean_ms']):.1f}% 변화(감소가 양수), 처리량 비율 TRT/PT {trt['throughput_images_s']/pt['throughput_images_s']:.2f}배.\n"
    text+='\n이번 전처리·후처리 포함 경로에서 **큰 속도 향상은 확인되지 않았습니다**. M1 평균은 약1% 감소했으나 p95는 증가했고, M2 평균은 약2.7% 증가했습니다. 작은 평균 차이를 통계적으로 유의한 개선이라고 주장하지 않습니다. GPU 커널 단독시간을 측정하지 않아 원인을 특정 연산이나 메모리 전송으로 단정할 수 없습니다.\n'
    text+='\n각 반복과 전체 원본은 `latency_summary.csv`, `latency_raw.csv`에 있습니다. 로드·첫 호출은 CSV의 별도 열이며 정상상태 평균에 합치지 않습니다. 전체값은 세 반복 전체를 합친 값이며 평균 p95가 아닙니다.\n\n'
    text+='## 4. 메모리\n\n'
    memtable=[]
    for model in ('M1','M2'):
        for backend in ('PT','TRT'):
            subset=[r for r in memory if r['model']==model and r['backend']==backend and r['phase']=='measure']
            memtable.append([model,backend,f"{max(int(r['sampled_max_rss_bytes']) for r in subset)/2**20:.1f}",f"{max(int(r['rss_increase_bytes']) for r in subset)/2**20:.1f}",f"{max(int(r['sampled_max_system_used_bytes']) for r in subset)/2**20:.1f}"])
    text+=mdtable(['모델','Backend','측정구간 RSS 관측 최대 MiB','각 실행 기준 대비 RSS 최대 증가 MiB','시스템 사용량 추정 관측 최대 MiB'],memtable)
    text+='\n세 반복의 관측 최대를 표시했습니다. RSS와 시스템 RAM은 다른 관측 범위이며 합산하지 않습니다. 샘플 간 순간 최대는 보증하지 않습니다. 모델 로드·첫 호출·예열·측정 단계별 수치와 기준값은 `memory_summary.csv`, 전체 샘플은 `memory_raw.csv`에 있습니다. GPU 전용 메모리와 커널 단독 시간은 미측정이며 0으로 표시하지 않았습니다.\n\n'
    text+='기준값은 각 backend의 라이브러리와 동일72장 이미지를 준비한 뒤 기록했습니다. 따라서 절대 RSS에는 PyTorch와 TensorRT의 서로 다른 라이브러리 비용도 포함됩니다. 단계가100ms보다 짧아 샘플이 없는 경우 메모리0을 뜻하지 않으며, 해당 구간의 최대값은 미관측입니다.\n\n'
    text+='## 5. 이번 Jetson 추론 정확도\n\n'
    text+=mdtable(['모델','Backend','TP/FP/FN','P@0.25','R@0.25','mAP50@0.001','mAP50–95@0.001'],[
      [x['model'],x['backend'],f"{x['tp']}/{x['fp']}/{x['fn']}",f"{x['fixed_precision']:.6f}",f"{x['fixed_recall']:.6f}",f"{x['map50']:.6f}",f"{x['map50_95']:.6f}"] for x in acc])
    text+='\n정답 매칭은 Ultralytics8.4.118 `BaseValidator.match_predictions(use_scipy=False)`의 클래스 일치·IoU 내림차순·예측/정답 일대일 매칭입니다. 고정 P/R은 IoU0.50의 실제 TP/FP/FN에서 계산합니다. mAP는 동일 평가기의 `ap_per_class`와 IoU0.50:0.05:0.95를 사용합니다. max-F1 보간 P/R을 고정 cutoff P/R로 사용하지 않았습니다. 클래스별 표는 `accuracy_by_class.csv`입니다.\n\n'
    text+=f'**낮은 cutoff의 평가 연결 차이:** 운영 native 후처리는 clip 후 면적0 박스를 오류로 거부합니다. 최초 M2 PT 실행은 이 단계에서 중단됐습니다. 평가 전용 사본은 해당 박스를 제거하지 않고 IoU0인 FP 후보로 유지합니다. NMS·점수·정렬·좌표는 동일하며 PT/TRT 모두 같은 사본을 썼습니다. 정상 박스 일치 및 면적0 처리 고정 사례 검증을 통과했습니다. 이번 native 거부 기록 {len(native_rejections)}건은 `low_cutoff_native_rejections.json`, 해당 raw 출력은 각 실행 폴더의 NPZ로 보존했습니다. 이 보완은 운영 코드 또는 운영 PASS/FAIL 조건 변경이 아닙니다.\n\n'
    rejection_counts=[f'{m}/{b}: '+str(sum(x['model']==m and x['backend']==b for x in native_rejections))+'장' for m in ('M1','M2') for b in ('PT','TRT')]
    text+='낮은 cutoff 연결 진단의 분포: '+', '.join(rejection_counts)+'. 이 숫자는 confidence0.001 평가 연결에서의 native 거부 횟수이며, confidence0.25 본 측정 또는 현장 검사 ERROR 횟수가 아닙니다.\n\n'
    text+='M1 정답은 사용자 승인 라벨, M2는 기존 AI 검토 라벨이라는 출처 차이가 있습니다. M2 AP는 엔진 전체 박스 정확도이며 자세·회전각 정확도가 아닙니다. E03의 `MISSING_ALL_TARGETS`는 필수 부품 전체 누락이며 엔진 몸체는 존재합니다. 빈 벨트 성능으로 해석하지 않습니다.\n\n'
    text+='## 6. 모델 연결·사례·기존 평가와의 차이\n\n'
    text+=mdtable(['모델','PT SHA256','ONNX SHA256','운영 plan SHA256'],[[x['model'],x['pt'],x['onnx'],x['trt']] for x in model_hash_checks])
    text+=f'\nPT→ONNX→plan 해시는 원문 export/build/manifest와 대조했습니다. `provenance/`, `model_hashes.json`, `model_hash_verification.json` 참조. 현재 Jetson이 사용하는 두 plan과 일치합니다. 모델 바이너리 및 전체 학습 데이터는 중복 포함하지 않았습니다.\n\n'
    text+=f'설명 사례 {len(examples)}개는 PT/TRT 좌표·개수 차이가 큰 사례와 촬영 상태 범위를 기준으로 선정했습니다. `examples.csv`와 `examples/`의 원본·두 정답 라벨·정답/PT/TRT 비교 그림·전체 좌표 JSON을 연결했습니다. PT/TRT 차이를 곧바로 정답 오류로 부르지 않으며, 정답 기준 오탐/미탐은 각 `accuracy.json`의 errors 항목입니다. 전체144 이미지/모델 비교와 동일 입력 텐서 SHA는 `prediction_comparison.csv`에 있습니다.\n\n'
    text+='기존 Windows PT 개발 검증·과거 NMS0.70 parity·실물 PLC 결과를 이번 값으로 재사용하지 않았습니다. 이번 수치는 Jetson에서 공통 고정640·NMS0.45로 새로 추론한 값입니다. 초기 직접 Python 실행에서 NumPy2 ABI 문제가 났으나, 운영에 이미 존재하는 NumPy1.26.4 overlay를 재사용해 해결했습니다. 최초 실패와 프로토콜 변경 이력은 `protocol_revisions/`에 보존했습니다.\n\n'
    text+='## 7. 재실행 방법과 운영 상태\n\n'
    text+='1. 기존 모델·E03 72장·GT를 `model_hashes.json`과 `input_manifest.csv`의 원본 경로/해시로 준비합니다. 보호 최종시험 자료는 사용하지 않습니다.\n2. 별도 새 측정 폴더에 이 코드와 원문 source_snapshot/provenance를 준비하고 protocol 경로와 SHA를 사전에 고정합니다. 기존 결과 폴더를 재사용하거나 덮어쓰지 않습니다.\n3. 기존 numpy overlay와 Python을 사용해 `code/test_adapter.py`를 CPU에서 실행합니다. 서비스·카메라·PLC를 시작하는 import는 사용하지 않습니다.\n4. 실제 STOP 및 요청LOW·검사/저장유휴를 확인하고 운영 영향 승인을 받은 뒤 운영 service를 정지합니다. 본 작업의 실제 명령은 `remote_results/window_result.json`과 `suite_result.json`에 보존했습니다.\n5. `code/run_suite.py`는 프로토콜 순서대로 새 자식 프로세스를 실행합니다. 사용자 권한으로 GPU 추론하며 `.plan`은 native executor로 읽습니다.\n6. 같은 service를 다시 시작하고 새 프레임·실제 IPC 준비 신호·모델/릴리스 해시를 확인합니다. 자동 복구가 막히면 해결 완료로 쓰지 않습니다.\n\n'
    text+=f'작업 전: 서비스 active(MainPID1078), PLC 운전OFF·요청LOW, 운영 {protocol["expected_release"]}. 최초 복구에서 CAMERA_FRAME_TIMEOUT이 발생했고, 사용자의 같은 USB 포트 재연결 후 새 영상·실제 IPC READY를 확인했습니다. 웹의 오래된 ready=false와 구분했습니다. 마지막 관측: {restore_files[-1].name}; 프레임 {" → ".join(frames)}; 실제 IPC {live.get("reason")}; 운영 준비 복구 {service_restored}. 전체 과정에서 운영 파일 교체·재부팅·PLC START/STOP 전송은 하지 않았습니다. 현장 검사 요청을 새로 실행한 검증은 아닙니다.\n\n'
    text+='작업 후 `operating_after_verification.json`에서 운영 릴리스, 모델 패키지·재사용 소스 합계19파일, standalone 설정 해시가 작업 전과 같은 것을 확인했습니다. 동일 boot ID·25W mode1이며 벤치마크 프로세스는 모두 종료됐습니다. 두 번째 측정 후에는 추가 USB 조작 없이 서비스가 복귀했습니다.\n\n'
    text+='## 8. 해석 한계와 무결성\n\n'
    text+='- 72장은 이미 개발에 사용된 E03이며 독립 최종시험·다양한 현장 환경·빈 벨트·낯선 물체 성능을 보증하지 않습니다.\n- 고정 전체 프레임 모델별 호출을 비교했습니다. 현재 제품의 자세 정렬·slot 판정·3장 확보·저장·PLC 처리 전체를 측정한 것이 아닙니다.\n- 25W의 실제 열/동적 클록 조건이며 GNOME 등 시스템 부하는 남아 있습니다. tegrastats 원문으로 확인할 수 있습니다.\n- GPU 커널 단독시간·전용 GPU 메모리·노이즈 없는 최악 지연 보증·통계적 유의성 검정은 미측정입니다.\n- `verification.json`은 측정/참조/복구 검증이며, ZIP 자체 크기·SHA256·CRC·파일집합 검증은 ZIP 옆의 `*_zip_verification.json`으로 별도 제공합니다.\n'
    (O/'README_KO.md').write_text(text,encoding='utf-8')
    (O/'TASK_STATE.md').write_text('현재 Task: M1/M2 Benchmark 증빙\n측정12회 완료. 운영 복구 확인: '+str(service_restored)+'\n후속 작업 실행 없음.\n',encoding='utf-8')
    checks.update(status='PASS' if service_restored else 'MEASUREMENTS_PASS_RESTORE_UNVERIFIED',examples=len(examples),input_reference_hashes='PASS',model_hash_chain='PASS',backend_tensor_identity='PASS',adapter_tests=load(O/'adapter_tests.json')['status'],collected_evidence_audit=audit['status'],operating_after_checks=after['checks'],optional_unmeasured=['GPU kernel-only latency','dedicated GPU memory','instantaneous memory peak between samples','independent final-test accuracy','PLC request-to-Done latency'])
    save(O/'verification.json',checks)
    if '--report-only' in sys.argv:
        print(json.dumps({'report':str(O/'README_KO.md'),'verification':checks},ensure_ascii=False))
        return
    source_map={}
    project=Path('D:/OneDevice_Team_project')
    dynamic=project/'runs/engine_dynamic_pose_002'
    for model in ('M1','M2'):
        package=project/'jetson/products/ENGINE_Z3005_5'/protocol['models'][model]['package']
        for name in ('manifest.json','classes.json','preprocessing.json'):
            source_map[f'provenance/{model}/{name}']=package/name
        source_map[f'provenance/{model}/build_manifest.json']=dynamic/('parts_fp16_head32_v001' if model=='M1' else 'envelope_fp16_backbone32_v007')/'build_manifest.json'
        source_map[f'provenance/{model}/export.json']=project/'runs/engine_package_integration_001/controlled_export.json' if model=='M1' else dynamic/'envelope_export.json'
    for item in inputrows:
        for model in ('M1','M2'):
            source_map[f'ground_truth/{model}/{item["image_id"]}.txt']=Path(item[model.lower()+'_label_path'])
    for item in examples:
        source_map[item['original']]=Path(item['source_image'])
        original=next(x for x in inputrows if x['image_id']==item['image_id'])
        for model in ('m1','m2'):
            source_map[item[model+'_ground_truth']]=Path(original[model+'_label_path'])
    excluded=[];files=[]
    for path in sorted(O.rglob('*')):
        if not path.is_file():continue
        relative=path.relative_to(O).as_posix()
        if relative.startswith('_transport/') or '__pycache__' in path.parts or relative.endswith('_archive.stdout.txt') or relative=='bundle_manifest.json':excluded.append(relative);continue
        assert not any(part.upper() in ('E04','B04') for part in path.parts)
        source=str(path);kind='generated'
        if relative in source_map:
            source=str(source_map[relative]);kind='local_original_copy'
            assert sha(path)==sha(source_map[relative]),relative
        elif relative.startswith('remote_results/'):source=protocol['remote_root']+'/'+relative[len('remote_results/'):];kind='remote_original_copy'
        elif relative.startswith('attempt001/remote_results/'):source='/home/jetson/oned_device_bench/tmp/benchmark_m1_m2_20261019_v001/'+relative[len('attempt001/remote_results/'):];kind='remote_aborted_attempt_copy'
        elif relative.startswith('source_snapshot/'):source=protocol['runtime_root']+'/'+relative[len('source_snapshot/'):];kind='runtime_source_copy'
        files.append({'relative_path':relative,'original_path':source,'origin_kind':kind,'bytes':path.stat().st_size,'sha256':sha(path)})
    manifest={'schema_version':1,'files':files,'excluded_transport_or_redundant_archive_files':excluded,'manifest_self_hash':'recorded by external ZIP verification to avoid self-reference'}
    save(O/'bundle_manifest.json',manifest)
    zip_path=O.with_suffix('.zip')
    if zip_path.exists():raise RuntimeError('Preserve existing ZIP: '+str(zip_path))
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for item in files:z.write(O/item['relative_path'],item['relative_path'])
        z.write(O/'bundle_manifest.json','bundle_manifest.json')
    with zipfile.ZipFile(zip_path) as z:
        assert z.testzip() is None
        expected={x['relative_path']:x for x in files}
        expected['bundle_manifest.json']={'bytes':(O/'bundle_manifest.json').stat().st_size,'sha256':sha(O/'bundle_manifest.json')}
        assert set(z.namelist())==set(expected) and len(z.namelist())==len(expected)
        for name,entry in expected.items():
            data=z.read(name);assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
        # Inspect archive CSVs, not just the directory before packaging.
        for row in csv.DictReader(io.StringIO(z.read('examples.csv').decode('utf-8-sig'))):
            for k in ('original','m1_ground_truth','m2_ground_truth','predictions','comparison'):assert row[k] in expected
        count=len(expected)
    receipt={'zip_integrity':'PASS','benchmark_measurement_status':'COMPLETE','operating_restore_verified':service_restored,
      'zip_path':str(zip_path),'bytes':zip_path.stat().st_size,'sha256':sha(zip_path),'files':count,
      'checks':{'exact_file_set':'PASS','uncompressed_sizes':'PASS','all_member_sha256':'PASS','all_member_CRC':'PASS','example_CSV_references':'PASS','input_source_hashes':'PASS'},
      'readme_path':str(O/'README_KO.md'),'readme_bytes':(O/'README_KO.md').stat().st_size,'bundle_verification':str(O/'verification.json')}
    save(O.parent/(O.name+'_zip_verification.json'),receipt);print(json.dumps(receipt,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
