from remote_tools import remote,O
import datetime
import json
payload='''import json,time,urllib.request,subprocess
from pathlib import Path
observations=[]
for n in range(3):
 with urllib.request.urlopen('http://127.0.0.1:18771/api/v1/runtime/status',timeout=10) as r:s=json.load(r)
 observations.append({'monotonic':time.monotonic(),'inspection_service':{k:s['inspection_service'].get(k) for k in ('state','error','ready','camera_ready','worker_pid','worker_alive','active_inspection_id','storage_pending')},
  'plc':s.get('plc'),'plc_cycle':s.get('plc_cycle'),'latest_frame':s.get('latest_frame'),
  'ipc_health_latest':s.get('ipc_health',{}).get('latest'),
  'pending':{k:s.get(k) for k in ('final_commit_pending','completion_audit_pending','request_start_pending')}})
 if n<2:time.sleep(2)
print(json.dumps({'observations':observations,'service':subprocess.run(['systemctl','show','engine-inspector.service','-p','ActiveState','-p','MainPID','-p','NRestarts'],capture_output=True,text=True).stdout},ensure_ascii=False))
'''
stamp=datetime.datetime.now().strftime('%H%M%S');d=json.loads(remote(payload,'restore_'+stamp))
(O/f'restore_observation_{stamp}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
for x in d['observations']:
    live=(x['ipc_health_latest'] or {}).get('IPC_HEALTH_SENT',{})
    print(json.dumps({'monotonic':x['monotonic'],'service':x['inspection_service'],
                     'frame_id':(x['latest_frame'] or {}).get('frame_id'),
                     'ipc_ready':live.get('ready'),'ipc_reason':live.get('reason'),
                     'ipc_age_s':x['monotonic']-live.get('monotonic_s',0)},ensure_ascii=False))
print(d['service'])
