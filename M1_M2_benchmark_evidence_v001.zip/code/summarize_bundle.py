"""Summarize retained measurements, not a new inference or evaluation run."""
from collections import defaultdict
import csv
import hashlib
import json
from pathlib import Path
import re
import shutil
import statistics

import numpy as np
from PIL import Image,ImageDraw,ImageFont

O=Path(__file__).resolve().parents[1]
R=O/'remote_results'
def read(p):return json.loads(Path(p).read_text('utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def table(p,rows,fields=None):
    with Path(p).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields or list(rows[0]));w.writeheader();w.writerows(rows)
def percentile(values,q):return float(np.percentile(values,q))
def iou(a,b):
    a=np.array(a);b=np.array(b);intersection=np.maximum(0,np.minimum(a[2:],b[2:])-np.maximum(a[:2],b[:2])).prod()
    return float(intersection/((a[2:]-a[:2]).prod()+(b[2:]-b[:2]).prod()-intersection))

def main():
    p=read(O/'protocol.json');models=read(O/'model_hashes.json');gt=read(O/'ground_truth.json')
    runs=[read(R/'results'/r['run_id']/'run.json') for r in p['measurement']['order']]
    assert all(r['status']=='PASS' for r in runs) and len(runs)==12
    assert all(r['protocol_sha256']==sha(O/'protocol.json') and r['measured_images']==360 for r in runs)
    latency=[];memory=[];telemetry=[];summaries=[];memory_summary=[]
    for run in runs:
        ident=run['run']['run_id'];folder=R/'results'/ident
        lr=list(csv.DictReader((folder/'latency_raw.csv').open(encoding='utf-8')))
        assert len(lr)==360 and [x['image_id'] for x in lr]==[x['image_id'] for x in p['inputs']]*5
        latency+=lr
        values=[float(r['latency_ms']) for r in lr]
        summaries.append({'run_id':ident,'model':run['run']['model'],'backend':run['run']['backend'],'repetition':run['run']['repetition'],
            'completed_images':360,'mean_ms':statistics.mean(values),'p50_ms':percentile(values,50),'p95_ms':percentile(values,95),'min_ms':min(values),'max_ms':max(values),
            'measured_wall_s':run['measure_wall_seconds'],'throughput_images_s':360/run['measure_wall_seconds'],
            'interval_sum_s':run['interval_seconds'],'load_ms':run['load_ms'],'first_call_ms':run['first_call_ms']})
        mr=list(csv.DictReader((folder/'memory_raw.csv').open(encoding='utf-8')))
        baseline=run['baseline_memory']
        for row in mr:memory.append({'run_id':ident,'model':run['run']['model'],'backend':run['run']['backend'],**row})
        for phase in p['memory']['phases']:
            subset=[x for x in mr if x['phase']==phase]
            if not subset:continue
            rss=max(int(x['rss_bytes']) for x in subset);system=max(int(x['system_used_estimate_bytes']) for x in subset)
            memory_summary.append({'run_id':ident,'model':run['run']['model'],'backend':run['run']['backend'],'phase':phase,'samples':len(subset),
                 'baseline_rss_bytes':baseline['rss_bytes'],'sampled_max_rss_bytes':rss,'rss_increase_bytes':rss-baseline['rss_bytes'],
                 'baseline_system_used_bytes':baseline['system_used_estimate_bytes'],'sampled_max_system_used_bytes':system,
                 'system_used_increase_bytes':system-baseline['system_used_estimate_bytes'],'sample_interval_s':.1})
        for line in (folder/'telemetry.jsonl').read_text().splitlines():telemetry.append({'run_id':ident,**json.loads(line)})
    for model in ('M1','M2'):
        for backend in ('PT','TRT'):
            subset=[x for x in latency if x['model']==model and x['backend']==backend]
            v=[float(x['latency_ms']) for x in subset];rs=[x for x in runs if x['run']['model']==model and x['run']['backend']==backend]
            elapsed=sum(x['measure_wall_seconds'] for x in rs)
            summaries.append({'run_id':f'{model}_{backend}_ALL','model':model,'backend':backend,'repetition':'ALL','completed_images':len(subset),
                'mean_ms':statistics.mean(v),'p50_ms':percentile(v,50),'p95_ms':percentile(v,95),'min_ms':min(v),'max_ms':max(v),
                'measured_wall_s':elapsed,'throughput_images_s':len(subset)/elapsed,'interval_sum_s':sum(v)/1000,'load_ms':'','first_call_ms':''})
    table(O/'latency_raw.csv',latency);table(O/'latency_summary.csv',summaries);table(O/'memory_raw.csv',memory);table(O/'memory_summary.csv',memory_summary)
    (O/'telemetry_raw.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in telemetry),encoding='utf-8')
    accuracy=[];classes=[];predictions={}
    for model in ('M1','M2'):
        for backend in ('PT','TRT'):
            ident=f'{model}_{backend}_r1';a=read(R/'results'/ident/'accuracy.json');pred=read(R/'results'/ident/'predictions.json')
            assert a['images']==72 and len(pred['rows'])==72 and pred['model_sha256']==models[model]['hashes']['pt' if backend=='PT' else 'trt']['sha256']
            predictions[(model,backend)]={r['image_id']:r for r in pred['rows']}
            sums={k:sum(c[k] for c in a['operating']) for k in ('tp','fp','fn','gt')}
            accuracy.append({'model':model,'backend':backend,'images':72,**sums,'fixed_confidence':.25,'nms_iou':.45,'gt_match_iou':.5,
                             'fixed_precision':sums['tp']/(sums['tp']+sums['fp']),'fixed_recall':sums['tp']/sums['gt'],
                             'map_confidence':.001,'map50':a['map50'],'map50_95':a['map50_95'],'source':f'remote_results/results/{ident}/accuracy.json'})
            byid={x['class_id']:x for x in a['ap_per_class']}
            for c in a['operating']:classes.append({'model':model,'backend':backend,**c,'map50':byid[c['class_id']]['map50'],'map50_95':byid[c['class_id']]['map50_95']})
    table(O/'accuracy_summary.csv',accuracy);table(O/'accuracy_by_class.csv',classes)
    comparisons=[]
    for model in ('M1','M2'):
        for row in p['inputs']:
            ident=row['image_id'];left=predictions[(model,'PT')][ident];right=predictions[(model,'TRT')][ident]
            assert left['input_tensor_sha256']==right['input_tensor_sha256'] and left['image_sha256']==right['image_sha256']==row['image_sha256']
            available=set(range(len(right['operating'])));pairs=[]
            for a in left['operating']:
                candidates=[(iou(a['bbox'],b['bbox']),j) for j,b in enumerate(right['operating']) if j in available and b['class_id']==a['class_id']]
                if not candidates:continue
                overlap,j=max(candidates);available.remove(j);b=right['operating'][j]
                pairs.append({'iou':overlap,'confidence_abs_diff':abs(a['confidence']-b['confidence']),
                              'max_coordinate_abs_diff_px':max(abs(x-y) for x,y in zip(a['bbox'],b['bbox']))})
            comparisons.append({'model':model,'image_id':ident,'scenario':row['scenario'],'pt_count':len(left['operating']),'trt_count':len(right['operating']),
                 'unmatched_pt':len(left['operating'])-len(pairs),'unmatched_trt':len(available),'paired_min_iou':min((x['iou'] for x in pairs),default=None),
                 'max_confidence_abs_diff':max((x['confidence_abs_diff'] for x in pairs),default=None),
                 'max_coordinate_abs_diff_px':max((x['max_coordinate_abs_diff_px'] for x in pairs),default=None),
                 'tensor_sha256':left['input_tensor_sha256']})
    table(O/'prediction_comparison.csv',comparisons)
    examples=[];original_by_id={x['image_id']:x for x in p['inputs']}
    font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',14)
    for model in ('M1','M2'):
        ranked=sorted([x for x in comparisons if x['model']==model],key=lambda x:(x['unmatched_pt']+x['unmatched_trt'],x['max_coordinate_abs_diff_px'] or 0),reverse=True)
        selected=[]
        # Three largest backend differences, then one per previously uncovered capture scenario.
        for item in ranked:
            if len(selected)<3:selected.append(item)
        for scenario in dict.fromkeys(x['scenario'] for x in p['inputs']):
            if not any(x['scenario']==scenario for x in selected):selected.append(next(x for x in ranked if x['scenario']==scenario))
        for item in selected:
            ident=item['image_id'];src=original_by_id[ident];dest=O/'examples'/model/ident;dest.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(src['image_path'],dest/'original.png')
            for k in ('M1','M2'):shutil.copyfile(src[k.lower()+'_label_path'],dest/f'{k}_ground_truth.txt')
            pt=predictions[(model,'PT')][ident];trt=predictions[(model,'TRT')][ident]
            save(dest/'predictions.json',{'model':model,'ground_truth':gt[model][ident],'PT':pt,'TRT':trt})
            original=Image.open(src['image_path']).convert('RGB')
            panel=Image.new('RGB',(1920,420),(20,25,35));draw=ImageDraw.Draw(panel)
            for index,(title,detections,color) in enumerate([('GROUND TRUTH',gt[model][ident],'lime'),('PT FP32',pt['operating'],'cyan'),('OPERATING TRT',trt['operating'],'orange')]):
                panel.paste(original.resize((640,360)),(640*index,40));draw.text((640*index+10,8),f'{model} {ident} | {title}',font=font,fill='white')
                for b in detections:
                    coordinates=[b['bbox'][0]/2+index*640,b['bbox'][1]/2+40,b['bbox'][2]/2+index*640,b['bbox'][3]/2+40]
                    draw.rectangle(coordinates,outline=color,width=2)
                    label=models[model]['names'][b['class_id']]+(f" {b['confidence']:.3f}" if 'confidence' in b else '')
                    draw.text((coordinates[0],max(40,coordinates[1]-16)),label,font=font,fill=color,stroke_width=1,stroke_fill='black')
            panel.save(dest/'comparison.png')
            examples.append({'model':model,'image_id':ident,'scenario':src['scenario'],'source_image':src['image_path'],
                'source_image_sha256':src['image_sha256'],'original':str((dest/'original.png').relative_to(O)).replace('\\','/'),
                'm1_ground_truth':str((dest/'M1_ground_truth.txt').relative_to(O)).replace('\\','/'),
                'm2_ground_truth':str((dest/'M2_ground_truth.txt').relative_to(O)).replace('\\','/'),
                'predictions':str((dest/'predictions.json').relative_to(O)).replace('\\','/'),
                'comparison':str((dest/'comparison.png').relative_to(O)).replace('\\','/'),
                'selection_reason':'largest observed PT/TRT coordinate/count differences or capture scenario coverage; not independent test'})
    table(O/'examples.csv',examples)
    telemetry_summary={}
    for run in runs:
        ident=run['run']['run_id'];lines=[x['text'] for x in telemetry if x['run_id']==ident and x['phase']=='measure']
        temperatures=[float(m) for line in lines for m in re.findall(r'gpu@([0-9.]+)C',line)]
        rates=[float(m) for line in lines for m in re.findall(r'GR3D_FREQ\s+([0-9.]+)%',line)]
        telemetry_summary[ident]={'samples':len(lines),'gpu_temperature_min_C':min(temperatures) if temperatures else None,
            'gpu_temperature_max_C':max(temperatures) if temperatures else None,'gpu_utilization_sample_max_percent':max(rates) if rates else None}
    save(O/'telemetry_summary.json',telemetry_summary)
    outcome={'status':'MEASUREMENT_COMPLETE','runs':12,'unique_images':72,'measured_intervals':4320,'accuracy_conditions':4,
             'same_input_tensor_sha256_pairs':144,'examples':len(examples),'latency_totals':[x for x in summaries if x['repetition']=='ALL'],
             'accuracy':accuracy,'service_window_state':read(R/'window_result.json')['state'],'protocol_sha256':sha(O/'protocol.json')}
    save(O/'measurement_summary.json',outcome)
    print(json.dumps(outcome,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
