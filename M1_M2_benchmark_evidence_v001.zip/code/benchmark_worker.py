"""One condition, one fresh Jetson process. Reuses the untouched native runtime."""
import argparse
import csv
import dataclasses
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import traceback
from types import SimpleNamespace

O=Path(__file__).resolve().parents[1]
os.environ.update(YOLO_AUTOINSTALL='false',YOLO_CONFIG_DIR=str(O/'ultralytics_config'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def csv_write(p,rows):
    if not rows:return
    with Path(p).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

class MemorySampler:
    """Sample in memory; disk writes only after measured workload ends."""
    def __init__(self):
        self.phase='baseline';self.rows=[];self.done=threading.Event();self.thread=threading.Thread(target=self.loop,daemon=True)
    def sample(self):
        values={}
        for name in ('/proc/self/status','/proc/meminfo'):
            for line in Path(name).read_text().splitlines():
                fields=line.split()
                if fields and fields[0].rstrip(':') in ('VmRSS','VmHWM','MemTotal','MemAvailable','SwapTotal','SwapFree'):
                    values[fields[0].rstrip(':')]=int(fields[1])*1024
        self.rows.append({'monotonic_ns':time.monotonic_ns(),'phase':self.phase,
                          'rss_bytes':values['VmRSS'],'process_lifetime_hwm_bytes':values['VmHWM'],
                          'system_total_bytes':values['MemTotal'],'system_available_bytes':values['MemAvailable'],
                          'system_used_estimate_bytes':values['MemTotal']-values['MemAvailable'],
                          'swap_used_bytes':values['SwapTotal']-values['SwapFree']})
    def loop(self):
        while not self.done.is_set():
            self.sample();self.done.wait(.1)
    def start(self):self.sample();self.thread.start()
    def stop(self):self.done.set();self.thread.join(timeout=3);self.sample()

def require_idle_service():
    r=subprocess.run(['systemctl','is-active','engine-inspector.service'],capture_output=True,text=True)
    if r.stdout.strip()!='inactive':raise RuntimeError('Operating service must be inactive, got '+r.stdout.strip())
    # Keep the graphical desktop; reject other Python/CUDA owners observable by this user.
    owners=[]
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
        try:
            cmd=(proc/'cmdline').read_text().replace('\0',' ')
            if not ('python' in cmd or 'trtexec' in cmd):continue
            nodes=[str(f.resolve()) for f in (proc/'fd').iterdir()]
            if any(any(tag in n for tag in ('/dev/nvmap','/dev/nvidia','/dev/nvhost-gpu')) for n in nodes):owners.append({'pid':int(proc.name),'command':cmd})
        except (OSError,PermissionError):continue
    if owners:raise RuntimeError('Competing GPU process: '+json.dumps(owners))

def main(run_id):
    protocol=json.loads((O/'protocol.json').read_text())
    run=next(r for r in protocol['measurement']['order'] if r['run_id']==run_id)
    destination=O/'results'/run_id;destination.mkdir(parents=True,exist_ok=False)
    result={'run':run,'status':'STARTED','pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'protocol_sha256':sha(O/'protocol.json'),'latency_scope':protocol['measurement']['timing']}
    latencies=[];memory=None;telemetry=None;telemetry_rows=[];engine=None
    try:
        require_idle_service()
        runtime=Path(protocol['runtime_root'])
        sys.path.insert(0,protocol['pythonpath'])
        release=json.loads((runtime/'release.json').read_text())
        assert release['release_id']==protocol['expected_release']
        for p,h in protocol['runtime_source_hashes'].items():assert sha(runtime/p)==h,(p,'runtime changed')
        sys.path.insert(0,str(runtime))
        import cv2
        import numpy as np
        from src.vision.tensorrt_preprocess import preprocess
        from src.vision.tensorrt_postprocess import postprocess
        from evaluation_postprocess import postprocess as evaluation_postprocess
        cv2.setNumThreads(1)
        cfg=protocol['models'][run['model']]
        artifact=Path(cfg['pt_path'] if run['backend']=='PT' else cfg['plan_path'])
        expected=cfg['hashes']['pt' if run['backend']=='PT' else 'trt']['sha256']
        assert sha(artifact)==expected
        images=[]
        for row in protocol['inputs']:
            p=Path(row['remote_image']);assert sha(p)==row['image_sha256']
            image=cv2.imread(str(p));assert image is not None and image.shape==(720,1280,3)
            images.append(image)
        result['unique_images']=len(images);result['model_sha256']=expected
        result['numpy']={'version':np.__version__,'path':np.__file__}
        result['opencv']={'version':cv2.__version__,'path':cv2.__file__}
        if run['backend']=='PT':
            import torch
            from ultralytics import YOLO
            torch.set_num_threads(1);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
            torch.backends.cudnn.benchmark=False
        else:
            from src.vision.tensorrt_native import NativeTensorRTExecutor
            import tensorrt
        memory=MemorySampler();memory.start()
        result['baseline_memory']=memory.rows[0]
        try:
            telemetry=subprocess.Popen(['tegrastats','--interval','100'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
            def collect_telemetry():
                for line in telemetry.stdout:
                    telemetry_rows.append({'monotonic_ns':time.monotonic_ns(),'phase':memory.phase,'text':line.rstrip()})
            telemetry_thread=threading.Thread(target=collect_telemetry,daemon=True);telemetry_thread.start()
        except Exception as e:result['telemetry_error']=str(e)
        memory.phase='load';start=time.perf_counter_ns()
        if run['backend']=='PT':
            assert torch.cuda.is_available()
            yolo=YOLO(str(artifact));assert list(yolo.names.values())==cfg['names']
            network=yolo.model.to('cuda:0').float().eval();network.fuse()
            torch.cuda.synchronize()
            result['backend']={'name':'pytorch','device':'cuda:0','device_name':torch.cuda.get_device_name(0),
                               'parameter_dtypes':sorted({str(p.dtype) for p in network.parameters()}),'AMP':False,
                               'matmul_tf32':torch.backends.cuda.matmul.allow_tf32,'cudnn_tf32':torch.backends.cudnn.allow_tf32,
                               'training':network.training,'fused':True,'torch':torch.__version__}
            assert result['backend']['parameter_dtypes']==['torch.float32'] and not network.training
            def execute(tensor):
                with torch.inference_mode():
                    raw=network(torch.from_numpy(tensor).to('cuda:0'))
                    raw=(raw[0] if isinstance(raw,tuple) else raw).float().cpu().numpy()
                    torch.cuda.synchronize()
                return {'output0':raw}
            def sync():torch.cuda.synchronize()
        else:
            engine=NativeTensorRTExecutor(SimpleNamespace(manifest=cfg['manifest'],model_path=artifact))
            result['backend']={'name':'native_tensorrt','device':'cuda:0','tensorrt':tensorrt.__version__,'precision':cfg['precision_note']}
            execute=engine.execute
            def sync():engine.cuda.synchronize(engine.stream)
        result['load_ms']=(time.perf_counter_ns()-start)/1e6
        contract=cfg['manifest']['detector']['output']
        def call(image):
            tensor,transform=preprocess(image,'float32')
            raw=execute(tensor)
            detections=postprocess(raw,contract,cfg['names'],.25,.45,transform)
            return detections
        memory.phase='first_call';sync();t=time.perf_counter_ns();call(images[0]);sync()
        result['first_call_ms']=(time.perf_counter_ns()-t)/1e6
        memory.phase='warmup'
        for n in range(protocol['measurement']['warmup_calls']):call(images[n%72])
        sync();memory.phase='measure';wall=time.perf_counter_ns()
        for n in range(protocol['measurement']['iterations']):
            sync();start=time.perf_counter_ns();detections=call(images[n%72]);sync();end=time.perf_counter_ns()
            latencies.append({'run_id':run_id,'model':run['model'],'backend':run['backend'],'repetition':run['repetition'],
                              'iteration':n+1,'image_id':protocol['inputs'][n%72]['image_id'],'start_monotonic_ns':start,'end_monotonic_ns':end,
                              'latency_ms':(end-start)/1e6,'detections':len(detections)})
        result['measure_wall_seconds']=(time.perf_counter_ns()-wall)/1e9
        result['measured_images']=len(latencies);result['interval_seconds']=sum(x['latency_ms'] for x in latencies)/1000
        result['throughput_images_per_second']=len(latencies)/result['measure_wall_seconds']
        result['interval_only_throughput']=len(latencies)/result['interval_seconds']
        if run['repetition']==1:
            memory.phase='accuracy';prediction_rows=[]
            for row,image in zip(protocol['inputs'],images):
                tensor,transform=preprocess(image,'float32');raw=execute(tensor)
                output={'image_id':row['image_id'],'image_sha256':row['image_sha256'],'scenario':row['scenario'],
                        'input_tensor_sha256':hashlib.sha256(tensor.tobytes()).hexdigest(),'transform':dataclasses.asdict(transform)}
                for key,threshold in [('operating',.25),('map',.001)]:
                    if key=='operating':
                        detections=postprocess(raw,contract,cfg['names'],threshold,.45,transform)
                    else:
                        detections=evaluation_postprocess(raw,contract,cfg['names'],threshold,.45,transform)
                        try:
                            native=postprocess(raw,contract,cfg['names'],threshold,.45,transform)
                            assert native==detections
                            output['native_low_cutoff_error']=None
                        except Exception as e:
                            if 'degenerate restored box' not in str(e):raise
                            output['native_low_cutoff_error']=str(e)
                            np.savez_compressed(destination/(row['image_id']+'_native_rejected_raw.npz'),**raw)
                        output['map_zero_area_predictions']=sum(d.bounding_box.x1>=d.bounding_box.x2 or d.bounding_box.y1>=d.bounding_box.y2 for d in detections)
                    output[key]=[{'class_id':d.class_id,'class_name':d.class_name,'confidence':d.confidence,
                                  'bbox':[d.bounding_box.x1,d.bounding_box.y1,d.bounding_box.x2,d.bounding_box.y2]} for d in detections]
                prediction_rows.append(output)
            save(destination/'predictions.json',{'model_sha256':expected,'run':run,'rows':prediction_rows})
            from evaluate_predictions import evaluate
            gt=json.loads((O/'ground_truth.json').read_text())[run['model']]
            save(destination/'accuracy.json',evaluate(prediction_rows,gt,cfg['names']))
        if engine:result['native_metadata']=engine.runtime_metadata()
        result['status']='PASS'
    except Exception as e:
        result['status']='FAILED';result['error']=str(e);result['traceback']=traceback.format_exc()
        print(result['traceback'],file=sys.stderr)
    finally:
        if memory:memory.phase='cleanup'
        if engine:
            try:engine.close()
            except Exception as e:result['cleanup_error']=str(e);result['status']='FAILED'
        if telemetry:
            telemetry.terminate()
            try:telemetry.wait(timeout=5)
            except subprocess.TimeoutExpired:telemetry.kill();telemetry.wait()
            telemetry_thread.join(timeout=3)
        if memory:memory.stop();csv_write(destination/'memory_raw.csv',memory.rows)
        csv_write(destination/'latency_raw.csv',latencies)
        (destination/'telemetry.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in telemetry_rows),encoding='utf-8')
        result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        save(destination/'run.json',result)
    print(json.dumps({k:result.get(k) for k in ('run','status','load_ms','first_call_ms','measured_images','throughput_images_per_second','error')},ensure_ascii=False))
    return 0 if result['status']=='PASS' else 1

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('run_id');raise SystemExit(main(parser.parse_args().run_id))
