"""Verify collected measurements and transfer hashes without model execution."""
from pathlib import Path
import csv
import hashlib
import json
import math
import statistics

from remote_tools import O, remote, REMOTE

def load(path):
    return json.loads(Path(path).read_text('utf-8'))

def rows(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def percentile(values, percent):
    values = sorted(values)
    index = (len(values) - 1) * percent / 100
    lower, upper = math.floor(index), math.ceil(index)
    return values[lower] + (values[upper] - values[lower]) * (index - lower)

def close(a, b):
    assert math.isclose(float(a), float(b), rel_tol=1e-10, abs_tol=1e-8), (a,b)

def main():
    protocol = load(O / 'protocol.json')
    for name, digest in protocol['code_hashes'].items():
        assert sha(O / 'code' / name) == digest, name
    assert sha(O / 'environment.json') == protocol['environment_sha256']
    assert sha(O / 'environment_effective.json') == protocol['effective_environment_sha256']
    assert sha(O / 'ground_truth.json') == protocol['ground_truth_sha256']
    latency = rows(O / 'latency_raw.csv')
    assert len(latency) == 4320
    assert len({(r['run_id'],r['iteration']) for r in latency}) == 4320
    for r in latency:
        close(r['latency_ms'], (int(r['end_monotonic_ns']) - int(r['start_monotonic_ns'])) / 1e6)
        assert float(r['latency_ms']) > 0
    for r in rows(O / 'latency_summary.csv'):
        selected = [x for x in latency if x['model']==r['model'] and x['backend']==r['backend']
                    and (r['repetition']=='ALL' or x['run_id']==r['run_id'])]
        v = [float(x['latency_ms']) for x in selected]
        assert int(r['completed_images']) == len(v)
        for name,value in [('mean_ms',statistics.mean(v)),('p50_ms',percentile(v,50)),
                           ('p95_ms',percentile(v,95)),('min_ms',min(v)),('max_ms',max(v))]:
            close(r[name],value)
        close(r['throughput_images_s'],len(v)/float(r['measured_wall_s']))
    for r in rows(O / 'memory_summary.csv'):
        close(r['rss_increase_bytes'],int(r['sampled_max_rss_bytes'])-int(r['baseline_rss_bytes']))
        close(r['system_used_increase_bytes'],int(r['sampled_max_system_used_bytes'])-int(r['baseline_system_used_bytes']))
        assert int(r['samples']) > 0
    original_by_id={r['image_id']:r for r in protocol['inputs']}
    tensor_hashes={}
    prediction_count=0
    for model in ('M1','M2'):
        for backend in ('PT','TRT'):
            run=f'{model}_{backend}_r1'
            path=O/'remote_results/results'/run
            prediction=load(path/'predictions.json')
            assert len(prediction['rows'])==72
            for r in prediction['rows']:
                assert r['image_sha256']==original_by_id[r['image_id']]['image_sha256']
                key=(model,r['image_id'])
                tensor_hashes.setdefault(key,r['input_tensor_sha256'])
                assert tensor_hashes[key]==r['input_tensor_sha256']
                for mode in ('operating','map'):
                    cutoff=.25 if mode=='operating' else .001
                    for d in r[mode]:
                        assert cutoff < d['confidence'] <= 1
                        assert 0 <= d['class_id'] < len(protocol['models'][model]['names'])
                        x1,y1,x2,y2=d['bbox']
                        assert all(math.isfinite(x) for x in d['bbox'])
                        assert 0<=x1<=x2<=1280 and 0<=y1<=y2<=720
                        if mode=='operating': assert x1<x2 and y1<y2
                prediction_count+=1
            a=load(path/'accuracy.json')
            for c in a['operating']:
                assert c['tp']+c['fn']==c['gt']
                count=sum(d['class_id']==c['class_id'] for r in prediction['rows'] for d in r['operating'])
                assert count==c['tp']+c['fp']
    # Hash on the source device, then compare the files received over SSH.
    script='''from pathlib import Path
import hashlib,json
base=Path(ROOT)
files=[]
for folder in ('results','logs'):
 for p in sorted((base/folder).rglob('*')):
  if p.is_file():files.append(p)
for name in ('suite_progress.json','suite_result.json','window_started.json','window_result.json','adapter_tests.json'):
 if (base/name).is_file():files.append(base/name)
print(json.dumps([{'relative_path':p.relative_to(base).as_posix(),'bytes':p.stat().st_size,
 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]))
'''.replace('ROOT',repr(REMOTE))
    sources=json.loads(remote(script,'collected_remote_hashes'))
    local_files={p.relative_to(O/'remote_results').as_posix() for p in (O/'remote_results').rglob('*') if p.is_file()}
    assert local_files=={x['relative_path'] for x in sources}
    for r in sources:
        path=O/'remote_results'/r['relative_path']
        assert path.stat().st_size==r['bytes'] and sha(path)==r['sha256'],r['relative_path']
    (O/'remote_results_source_hashes.json').write_text(json.dumps(sources,indent=2),encoding='utf-8')
    result={'status':'PASS','frozen_protocol_code_files':len(protocol['code_hashes']),
            'raw_latency_rows_verified':len(latency),'summary_arithmetic':'PASS',
            'memory_delta_arithmetic':'PASS','prediction_image_records':prediction_count,
            'same_input_tensor_pairs':len(tensor_hashes),'remote_copy_hashes_verified':len(sources),
            'scope':'saved records and source hashes only; no new inference or evaluation'}
    (O/'collected_evidence_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))

if __name__=='__main__':
    main()
