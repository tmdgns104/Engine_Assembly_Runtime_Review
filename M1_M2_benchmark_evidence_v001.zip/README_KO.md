# M1·M2 최적화 전후 Benchmark 증빙

같은 Jetson Orin Nano에서 원본 PT FP32와 현재 운영 TensorRT를 비교한 **E03 개발 검증 Benchmark**입니다. 독립 최종시험, 카메라 FPS, PLC 응답시간, 전체 검사 시스템 성능을 뜻하지 않습니다.

## 1. 실제 완료 범위

- 네 조건 × 새 프로세스 3회 = **12회**, 각 예열50회·본 측정360회, 총 **4,320개 지연시간**. 서로 다른 원본은 **72장**입니다.
- 각 조건의 첫 반복에서 별도로 72장 전체를 추론해 confidence0.25 고정 지표와 confidence0.001 mAP를 계산했습니다.
- 최초 중단 시도 3회(1,080개 시간 측정 포함)는 `attempt001/`에 모두 보존했습니다. 두 번째 프로토콜은 낮은 cutoff 평가 연결을 수정한 뒤 전체 12회를 사전에 고정했으며, 불리한 시간값을 제거하지 않았습니다.
- 모델·운영코드·config.py·서비스 설정·전력 모드 변경, 새 학습·변환·PLC 운전은 수행하지 않았습니다. 운영 서비스 복구 준비 확인: **PASS**.

## 2. 장치와 비교 조건

| 항목 | 실제 조건 |
|---|---|
| 장치 | jetson-07 / NVIDIA Jetson Orin Nano Engineering Reference Developer Kit Super / aarch64 |
| 릴리스 | engine-integrated-32c484ac6aeb07f1 |
| OS/L4T | Ubuntu 22.04, L4T 36.4.7; nvidia-jetpack 메타 패키지 미설치로 해당 패키지 버전은 미확인 |
| 라이브러리 | Python 3.10.12 / torch2.8.0 / CUDA12.6 / TensorRT10.3.0 / Ultralytics8.4.118 / NumPy1.26.4 / OpenCV5.0.0 |
| 호환 환경 | /home/jetson/oned_device_bench/env_candidates/numpy_compat_001/overlay (기존 운영 경로 재사용, 설치 없음) |
| 전력·클록 | 기존25W mode1 유지. 클록 고정 변경 없음; jetson_clocks --show는 비root 권한 제한. 실제 tegrastats 원문 제공 |
| 동시 작업 | 운영 service 정지 후 Python/CUDA 점유자 검사. 기존 GNOME 데스크톱 유지; 다른 ML backend 동시 적재 없음 |
| 입력 | E03 D145–D216, 72장, 1280×720, batch1 → [1,3,640,640] |
| 전처리 | 기존 letterbox, linear, padding114, BGR→RGB, /255, float32, crop/증강 없음 |
| PT | 원본가중치 eval + fuse + inference_mode, float32, AMP OFF, TF32 OFF |
| TRT | 기존 native .plan. M1 FP16+head FP32 / M2 FP16+backbone FP32. 순수 FP16 아님 |
| 후처리 | 기존 class-aware NMS0.45, max_det300, argmax 단일 클래스, 동일 역좌표 변환 |
| 시간 경계 | 메모리 원본 → 전처리 → GPU 완료 → CPU 출력·NMS 완료. 파일읽기/디코딩/그림저장 제외 |
| 동기화 | PT torch.cuda.synchronize, TRT 기존 executor stream sync와 D2H 완료. 순수 GPU 커널 시간 미측정 |
| 처리량 | 완료 건수 / 측정 루프 실제 경과시간. 개별 구간 합 기반 보조 처리량은 run.json에 별도 |
| 메모리 | 100ms /proc RSS·MemTotal-MemAvailable 및 tegrastats. 모델 로드 전 입력·라이브러리 준비 기준. 서로 합산하지 않음 |

## 3. 지연시간·처리량

| 모델 | Backend | 개수 | 평균 ms | p50 ms | p95 ms | 최소/최대 ms | 처리량 image/s |
|---|---|---|---|---|---|---|---|
| M1 | PT | 1080 | 29.313 | 29.201 | 30.301 | 28.088 / 32.221 | 34.06 |
| M1 | TRT | 1080 | 29.022 | 29.310 | 30.537 | 22.725 / 31.700 | 34.41 |
| M2 | PT | 1080 | 29.480 | 29.529 | 30.042 | 28.566 / 30.412 | 33.87 |
| M2 | TRT | 1080 | 30.266 | 30.415 | 30.683 | 26.053 / 31.445 | 33.00 |

- M1: 평균 지연 1.0% 변화(감소가 양수), 처리량 비율 TRT/PT 1.01배.

- M2: 평균 지연 -2.7% 변화(감소가 양수), 처리량 비율 TRT/PT 0.97배.

이번 전처리·후처리 포함 경로에서 **큰 속도 향상은 확인되지 않았습니다**. M1 평균은 약1% 감소했으나 p95는 증가했고, M2 평균은 약2.7% 증가했습니다. 작은 평균 차이를 통계적으로 유의한 개선이라고 주장하지 않습니다. GPU 커널 단독시간을 측정하지 않아 원인을 특정 연산이나 메모리 전송으로 단정할 수 없습니다.

각 반복과 전체 원본은 `latency_summary.csv`, `latency_raw.csv`에 있습니다. 로드·첫 호출은 CSV의 별도 열이며 정상상태 평균에 합치지 않습니다. 전체값은 세 반복 전체를 합친 값이며 평균 p95가 아닙니다.

## 4. 메모리

| 모델 | Backend | 측정구간 RSS 관측 최대 MiB | 각 실행 기준 대비 RSS 최대 증가 MiB | 시스템 사용량 추정 관측 최대 MiB |
|---|---|---|---|---|
| M1 | PT | 1250.5 | 620.0 | 3051.4 |
| M1 | TRT | 636.9 | 301.9 | 2683.6 |
| M2 | PT | 1263.8 | 629.1 | 3072.6 |
| M2 | TRT | 649.7 | 314.6 | 2683.1 |

세 반복의 관측 최대를 표시했습니다. RSS와 시스템 RAM은 다른 관측 범위이며 합산하지 않습니다. 샘플 간 순간 최대는 보증하지 않습니다. 모델 로드·첫 호출·예열·측정 단계별 수치와 기준값은 `memory_summary.csv`, 전체 샘플은 `memory_raw.csv`에 있습니다. GPU 전용 메모리와 커널 단독 시간은 미측정이며 0으로 표시하지 않았습니다.

기준값은 각 backend의 라이브러리와 동일72장 이미지를 준비한 뒤 기록했습니다. 따라서 절대 RSS에는 PyTorch와 TensorRT의 서로 다른 라이브러리 비용도 포함됩니다. 단계가100ms보다 짧아 샘플이 없는 경우 메모리0을 뜻하지 않으며, 해당 구간의 최대값은 미관측입니다.

## 5. 이번 Jetson 추론 정확도

| 모델 | Backend | TP/FP/FN | P@0.25 | R@0.25 | mAP50@0.001 | mAP50–95@0.001 |
|---|---|---|---|---|---|---|
| M1 | PT | 192/0/0 | 1.000000 | 1.000000 | 0.995000 | 0.639911 |
| M1 | TRT | 192/0/0 | 1.000000 | 1.000000 | 0.995000 | 0.640873 |
| M2 | PT | 72/0/0 | 1.000000 | 1.000000 | 0.995000 | 0.836717 |
| M2 | TRT | 72/0/0 | 1.000000 | 1.000000 | 0.995000 | 0.836629 |

정답 매칭은 Ultralytics8.4.118 `BaseValidator.match_predictions(use_scipy=False)`의 클래스 일치·IoU 내림차순·예측/정답 일대일 매칭입니다. 고정 P/R은 IoU0.50의 실제 TP/FP/FN에서 계산합니다. mAP는 동일 평가기의 `ap_per_class`와 IoU0.50:0.05:0.95를 사용합니다. max-F1 보간 P/R을 고정 cutoff P/R로 사용하지 않았습니다. 클래스별 표는 `accuracy_by_class.csv`입니다.

**낮은 cutoff의 평가 연결 차이:** 운영 native 후처리는 clip 후 면적0 박스를 오류로 거부합니다. 최초 M2 PT 실행은 이 단계에서 중단됐습니다. 평가 전용 사본은 해당 박스를 제거하지 않고 IoU0인 FP 후보로 유지합니다. NMS·점수·정렬·좌표는 동일하며 PT/TRT 모두 같은 사본을 썼습니다. 정상 박스 일치 및 면적0 처리 고정 사례 검증을 통과했습니다. 이번 native 거부 기록 144건은 `low_cutoff_native_rejections.json`, 해당 raw 출력은 각 실행 폴더의 NPZ로 보존했습니다. 이 보완은 운영 코드 또는 운영 PASS/FAIL 조건 변경이 아닙니다.

낮은 cutoff 연결 진단의 분포: M1/PT: 0장, M1/TRT: 0장, M2/PT: 72장, M2/TRT: 72장. 이 숫자는 confidence0.001 평가 연결에서의 native 거부 횟수이며, confidence0.25 본 측정 또는 현장 검사 ERROR 횟수가 아닙니다.

M1 정답은 사용자 승인 라벨, M2는 기존 AI 검토 라벨이라는 출처 차이가 있습니다. M2 AP는 엔진 전체 박스 정확도이며 자세·회전각 정확도가 아닙니다. E03의 `MISSING_ALL_TARGETS`는 필수 부품 전체 누락이며 엔진 몸체는 존재합니다. 빈 벨트 성능으로 해석하지 않습니다.

## 6. 모델 연결·사례·기존 평가와의 차이

| 모델 | PT SHA256 | ONNX SHA256 | 운영 plan SHA256 |
|---|---|---|---|
| M1 | 42db183006ad2a4f61dc9c22e7a61a5b506cdacb5099004fc7c3b73b74bf5259 | 433b16fd1e802bdf2cb0afba6bb6487a839d94b5adc286185b93fd3953b9c296 | 743ce54b4d5c7b8a36addf3dbff50fa693ec4a509b31b476f68efc69f1bf2d6c |
| M2 | cf117defe782e1ae8b355e0ed13c014fc6f1538aa2dcdbe0fb6cfa54200f7755 | 5cb024bb911f9357e46c12c3d2a7e4b5f19af20e5692013037c9235e0deca830 | c82f2658ac20d06985a647c15e551c681e394451cfa1c53baed64f639bcebf83 |

PT→ONNX→plan 해시는 원문 export/build/manifest와 대조했습니다. `provenance/`, `model_hashes.json`, `model_hash_verification.json` 참조. 현재 Jetson이 사용하는 두 plan과 일치합니다. 모델 바이너리 및 전체 학습 데이터는 중복 포함하지 않았습니다.

설명 사례 13개는 PT/TRT 좌표·개수 차이가 큰 사례와 촬영 상태 범위를 기준으로 선정했습니다. `examples.csv`와 `examples/`의 원본·두 정답 라벨·정답/PT/TRT 비교 그림·전체 좌표 JSON을 연결했습니다. PT/TRT 차이를 곧바로 정답 오류로 부르지 않으며, 정답 기준 오탐/미탐은 각 `accuracy.json`의 errors 항목입니다. 전체144 이미지/모델 비교와 동일 입력 텐서 SHA는 `prediction_comparison.csv`에 있습니다.

기존 Windows PT 개발 검증·과거 NMS0.70 parity·실물 PLC 결과를 이번 값으로 재사용하지 않았습니다. 이번 수치는 Jetson에서 공통 고정640·NMS0.45로 새로 추론한 값입니다. 초기 직접 Python 실행에서 NumPy2 ABI 문제가 났으나, 운영에 이미 존재하는 NumPy1.26.4 overlay를 재사용해 해결했습니다. 최초 실패와 프로토콜 변경 이력은 `protocol_revisions/`에 보존했습니다.

## 7. 재실행 방법과 운영 상태

1. 기존 모델·E03 72장·GT를 `model_hashes.json`과 `input_manifest.csv`의 원본 경로/해시로 준비합니다. 보호 최종시험 자료는 사용하지 않습니다.
2. 별도 새 측정 폴더에 이 코드와 원문 source_snapshot/provenance를 준비하고 protocol 경로와 SHA를 사전에 고정합니다. 기존 결과 폴더를 재사용하거나 덮어쓰지 않습니다.
3. 기존 numpy overlay와 Python을 사용해 `code/test_adapter.py`를 CPU에서 실행합니다. 서비스·카메라·PLC를 시작하는 import는 사용하지 않습니다.
4. 실제 STOP 및 요청LOW·검사/저장유휴를 확인하고 운영 영향 승인을 받은 뒤 운영 service를 정지합니다. 본 작업의 실제 명령은 `remote_results/window_result.json`과 `suite_result.json`에 보존했습니다.
5. `code/run_suite.py`는 프로토콜 순서대로 새 자식 프로세스를 실행합니다. 사용자 권한으로 GPU 추론하며 `.plan`은 native executor로 읽습니다.
6. 같은 service를 다시 시작하고 새 프레임·실제 IPC 준비 신호·모델/릴리스 해시를 확인합니다. 자동 복구가 막히면 해결 완료로 쓰지 않습니다.

작업 전: 서비스 active(MainPID1078), PLC 운전OFF·요청LOW, 운영 engine-integrated-32c484ac6aeb07f1. 최초 복구에서 CAMERA_FRAME_TIMEOUT이 발생했고, 사용자의 같은 USB 포트 재연결 후 새 영상·실제 IPC READY를 확인했습니다. 웹의 오래된 ready=false와 구분했습니다. 마지막 관측: restore_observation_174722.json; 프레임 f6c4b08097ce43e4a466dcd80e8b180a-2918 → f6c4b08097ce43e4a466dcd80e8b180a-2943 → f6c4b08097ce43e4a466dcd80e8b180a-2966; 실제 IPC READY; 운영 준비 복구 True. 전체 과정에서 운영 파일 교체·재부팅·PLC START/STOP 전송은 하지 않았습니다. 현장 검사 요청을 새로 실행한 검증은 아닙니다.

작업 후 `operating_after_verification.json`에서 운영 릴리스, 모델 패키지·재사용 소스 합계19파일, standalone 설정 해시가 작업 전과 같은 것을 확인했습니다. 동일 boot ID·25W mode1이며 벤치마크 프로세스는 모두 종료됐습니다. 두 번째 측정 후에는 추가 USB 조작 없이 서비스가 복귀했습니다.

## 8. 해석 한계와 무결성

- 72장은 이미 개발에 사용된 E03이며 독립 최종시험·다양한 현장 환경·빈 벨트·낯선 물체 성능을 보증하지 않습니다.
- 고정 전체 프레임 모델별 호출을 비교했습니다. 현재 제품의 자세 정렬·slot 판정·3장 확보·저장·PLC 처리 전체를 측정한 것이 아닙니다.
- 25W의 실제 열/동적 클록 조건이며 GNOME 등 시스템 부하는 남아 있습니다. tegrastats 원문으로 확인할 수 있습니다.
- GPU 커널 단독시간·전용 GPU 메모리·노이즈 없는 최악 지연 보증·통계적 유의성 검정은 미측정입니다.
- `verification.json`은 측정/참조/복구 검증이며, ZIP 자체 크기·SHA256·CRC·파일집합 검증은 ZIP 옆의 `*_zip_verification.json`으로 별도 제공합니다.
